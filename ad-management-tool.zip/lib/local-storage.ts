import type { AdSet } from "./ad-set-types"
import { generateAdSetId } from "./id-utils"

// ローカルストレージのキー
const STORAGE_KEYS = {
  CLIENTS: "ad_tool_clients",
  PROJECTS: "ad_tool_projects",
  CAMPAIGNS: "ad_tool_campaigns",
  AD_SETS: "ad_tool_ad_sets",
  ADS: "ad_tool_ads",
  USERS: "ad_tool_users",
  ID_MAPPINGS: "ad_tool_id_mappings",
  DRIVE_FOLDERS: "ad_tool_drive_folders", // Google Driveフォルダ用のキーを追加
  ANALYSIS: "ad_tool_analysis", // 広告検証設定用のキーを追加
  OPERATION_LOGS: "ad_tool_operation_logs", // 運用ログ用のキーを追加
}

// 型定義
export type Client = {
  client_id: string
  client_name: string
  contact_person: string
  email: string
  phone?: string
  contract_details?: string
  notes?: string
  created_at: string
  updated_at: string
}

export type Project = {
  project_id: string
  client_id: string
  project_name: string
  description?: string
  start_date: string
  end_date?: string
  budget?: string
  team_members?: string
  goals?: string
  status: "planning" | "active" | "paused" | "completed"
  created_at: string
  updated_at: string
}

export type Campaign = {
  campaign_id: string
  project_id: string
  campaign_name: string
  objective: "awareness" | "consideration" | "conversion"
  status: "draft" | "active" | "paused" | "completed"
  start_date: string
  end_date?: string
  daily_budget?: string
  total_budget?: string
  description?: string
  created_at: string
  updated_at: string
}

export type User = {
  user_id: string
  user_name: string
  email: string
  user_role: "admin" | "operator"
  department?: string
  created_at: string
  updated_at: string
}

// IDマッピングの型定義
export type IdMapping = {
  adaccount_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  created_at: string
  updated_at: string
}

// Google Driveフォルダの型定義を追加
export type DriveFolder = {
  folder_id: string
  internal_project_id: string
  folder_url: string
  created_at: string
  updated_at: string
  additional_info?: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  file_type: string
  creative_item_id: string
  creative_item_name: string
}

// 広告検証設定の型定義を追加
export type Analysis = {
  analysis_id: string
  analysis_date: string
  account_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  creative_item_id: string
  appeal_target: string
  emphasis_theme: string
  appeal_content: string
  design_structure: string
  target_date?: string
  goal_event: string
  goal_value: string
  created_at: string
  updated_at: string
}

// 運用ログの型定義を追加
export type OperationLog = {
  operation_id: string
  operation_type: string
  operation_status: string
  operation_message?: string
  executed_by?: string
  operation_timestamp: string
  error_code?: string
  error_details?: string
  additional_info?: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
}

// ローカルストレージからデータを取得する関数
export function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return []

  try {
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : []
  } catch (error) {
    console.error(`ローカルストレージからの読み込みエラー (${key}):`, error)
    return []
  }
}

// ローカルストレージにデータを保存する関数
export function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch (error) {
    console.error(`ローカルストレージへの保存エラー (${key}):`, error)
  }
}

// クライアント関連の関数
export function getClients(): Client[] {
  return getFromStorage<Client>(STORAGE_KEYS.CLIENTS)
}

export function saveClient(client: Client): void {
  const clients = getClients()
  const existingIndex = clients.findIndex((c) => c.client_id === client.client_id)

  if (existingIndex >= 0) {
    clients[existingIndex] = { ...client, updated_at: new Date().toISOString() }
  } else {
    clients.push(client)
  }

  saveToStorage(STORAGE_KEYS.CLIENTS, clients)
}

export function deleteClient(clientId: string): void {
  const clients = getClients().filter((client) => client.client_id !== clientId)
  saveToStorage(STORAGE_KEYS.CLIENTS, clients)
}

// プロジェクト関連の関数
export function getProjects(): Project[] {
  return getFromStorage<Project>(STORAGE_KEYS.PROJECTS)
}

export function getProjectsByClient(clientId: string): Project[] {
  return getProjects().filter((project) => project.client_id === clientId)
}

export function saveProject(project: Project): void {
  const projects = getProjects()
  const existingIndex = projects.findIndex((p) => p.project_id === project.project_id)

  if (existingIndex >= 0) {
    projects[existingIndex] = { ...project, updated_at: new Date().toISOString() }
  } else {
    projects.push(project)
  }

  saveToStorage(STORAGE_KEYS.PROJECTS, projects)
}

export function deleteProject(projectId: string): void {
  const projects = getProjects().filter((project) => project.project_id !== projectId)
  saveToStorage(STORAGE_KEYS.PROJECTS, projects)
}

// キャンペーン関連の関数
export function getCampaigns(): Campaign[] {
  return getFromStorage<Campaign>(STORAGE_KEYS.CAMPAIGNS)
}

export function getCampaignsByProject(projectId: string): Campaign[] {
  return getCampaigns().filter((campaign) => campaign.project_id === projectId)
}

export function saveCampaign(campaign: Campaign): void {
  const campaigns = getCampaigns()
  const existingIndex = campaigns.findIndex((c) => c.campaign_id === campaign.campaign_id)

  if (existingIndex >= 0) {
    campaigns[existingIndex] = { ...campaign, updated_at: new Date().toISOString() }
  } else {
    campaigns.push(campaign)
  }

  saveToStorage(STORAGE_KEYS.CAMPAIGNS, campaigns)
}

export function deleteCampaign(campaignId: string): void {
  const campaigns = getCampaigns().filter((campaign) => campaign.campaign_id !== campaignId)
  saveToStorage(STORAGE_KEYS.CAMPAIGNS, campaigns)
}

// 広告セット関連の関数
export function getAdSets(): AdSet[] {
  return getFromStorage<AdSet>(STORAGE_KEYS.AD_SETS)
}

export function getAdSetsByCampaign(campaignId: string): AdSet[] {
  return getAdSets().filter((adSet) => adSet.campaign_id === campaignId)
}

export function getAdSetById(adSetId: string): AdSet | undefined {
  return getAdSets().find((adSet) => adSet.adset_id === adSetId)
}

export function saveAdSet(adSet: AdSet): void {
  const adSets = getAdSets()
  const existingIndex = adSets.findIndex((as) => as.adset_id === adSet.adset_id)

  if (existingIndex >= 0) {
    adSets[existingIndex] = { ...adSet, updated_at: new Date().toISOString() }
  } else {
    adSets.push(adSet)
  }

  saveToStorage(STORAGE_KEYS.AD_SETS, adSets)
}

export function deleteAdSet(adSetId: string): void {
  const adSets = getAdSets().filter((adSet) => adSet.adset_id !== adSetId)
  saveToStorage(STORAGE_KEYS.AD_SETS, adSets)
}

// 広告セットIDの生成
export function generateNewAdSetId(campaignId: string): string {
  const adSets = getAdSets()
  const adSetIds = adSets.map((adSet) => adSet.adset_id)
  return generateAdSetId(campaignId, adSetIds)
}

// ユーザー関連の関数
export function getUsers(): User[] {
  return getFromStorage<User>(STORAGE_KEYS.USERS)
}

export function getUserById(userId: string): User | undefined {
  return getUsers().find((user) => user.user_id === userId)
}

export function saveUser(user: User): void {
  const users = getUsers()
  const existingIndex = users.findIndex((u) => u.user_id === user.user_id)

  if (existingIndex >= 0) {
    users[existingIndex] = { ...user, updated_at: new Date().toISOString() }
  } else {
    users.push(user)
  }

  saveToStorage(STORAGE_KEYS.USERS, users)
}

export function deleteUser(userId: string): void {
  const users = getUsers().filter((user) => user.user_id !== userId)
  saveToStorage(STORAGE_KEYS.USERS, users)
}

export function generateUserId(existingIds: string[] = []): string {
  const prefix = "usr"
  const nextNum =
    existingIds.length > 0 ? Math.max(...existingIds.map((id) => Number.parseInt(id.replace(prefix, "")))) + 1 : 1
  return `${prefix}${nextNum.toString().padStart(5, "0")}`
}

// IDマッピング関連の関数
export function getIdMappings(): IdMapping[] {
  return getFromStorage<IdMapping>(STORAGE_KEYS.ID_MAPPINGS)
}

export function getIdMappingByExternalId(adId: string): IdMapping | undefined {
  return getIdMappings().find((mapping) => mapping.ad_id === adId)
}

export function getOperationLogs(): OperationLog[] {
  return getFromStorage<OperationLog>(STORAGE_KEYS.OPERATION_LOGS)
}

export function getOperationLogById(operationId: string): OperationLog | undefined {
  return getOperationLogs().find((log) => log.operation_id === operationId)
}

export function saveOperationLog(log: OperationLog): void {
  const logs = getOperationLogs()
  const existingIndex = logs.findIndex((l) => l.operation_id === log.operation_id)

  if (existingIndex >= 0) {
    logs[existingIndex] = log
  } else {
    logs.push(log)
  }

  saveToStorage(STORAGE_KEYS.OPERATION_LOGS, logs)
}

export function deleteOperationLog(operationId: string): void {
  const logs = getOperationLogs().filter((log) => log.operation_id !== operationId)
  saveToStorage(STORAGE_KEYS.OPERATION_LOGS, logs)
}

export function generateOperationId(): string {
  const prefix = "op"
  const timestamp = Date.now()
  const random = Math.floor(Math.random() * 1000)
    .toString()
    .padStart(3, "0")
  return `${prefix}${timestamp}${random}`
}

// 広告検証設定関連の関数
export function getAnalyses(): Analysis[] {
  return getFromStorage<Analysis>(STORAGE_KEYS.ANALYSIS)
}

export function getAnalysisById(analysisId: string): Analysis | undefined {
  return getAnalyses().find((analysis) => analysis.analysis_id === analysisId)
}

export function saveAnalysis(analysis: Analysis): void {
  const analyses = getAnalyses()
  const existingIndex = analyses.findIndex((a) => a.analysis_id === analysis.analysis_id)

  if (existingIndex >= 0) {
    analyses[existingIndex] = { ...analysis, updated_at: new Date().toISOString() }
  } else {
    analyses.push(analysis)
  }

  saveToStorage(STORAGE_KEYS.ANALYSIS, analyses)
}

export function deleteAnalysis(analysisId: string): void {
  const analyses = getAnalyses().filter((analysis) => analysis.analysis_id !== analysisId)
  saveToStorage(STORAGE_KEYS.ANALYSIS, analyses)
}

// IDマッピング関連の関数
export function saveIdMapping(mapping: IdMapping): void {
  const mappings = getIdMappings()
  const existingIndex = mappings.findIndex((m) => m.ad_id === mapping.ad_id)

  if (existingIndex >= 0) {
    mappings[existingIndex] = { ...mapping, updated_at: new Date().toISOString() }
  } else {
    mappings.push(mapping)
  }

  saveToStorage(STORAGE_KEYS.ID_MAPPINGS, mappings)
}

export function deleteIdMapping(adId: string): void {
  const mappings = getIdMappings().filter((mapping) => mapping.ad_id !== adId)
  saveToStorage(STORAGE_KEYS.ID_MAPPINGS, mappings)
}

// プロジェクト関連の追加関数
export function getProjectById(projectId: string): Project | undefined {
  return getProjects().find((project) => project.project_id === projectId)
}

// キャンペーン関連の追加関数
export function getCampaignById(campaignId: string): Campaign | undefined {
  return getCampaigns().find((campaign) => campaign.campaign_id === campaignId)
}

// 広告関連の関数
export function getAds(): any[] {
  return getFromStorage<any>(STORAGE_KEYS.ADS)
}

export function getAdById(adId: string): any | undefined {
  return getAds().find((ad) => ad.ad_id === adId)
}

export function saveAd(ad: any): void {
  const ads = getAds()
  const existingIndex = ads.findIndex((a) => a.ad_id === ad.ad_id)

  if (existingIndex >= 0) {
    ads[existingIndex] = { ...ad, updated_at: new Date().toISOString() }
  } else {
    ads.push(ad)
  }

  saveToStorage(STORAGE_KEYS.ADS, ads)
}

export function deleteAd(adId: string): void {
  const ads = getAds().filter((ad) => ad.ad_id !== adId)
  saveToStorage(STORAGE_KEYS.ADS, ads)
}

// 広告IDの生成
export function generateAdId(adSetId: string): string {
  const ads = getAds()
  const adIds = ads.map((ad) => ad.ad_id)
  return generateAdId(adSetId, adIds)
}

// ローカルデータベースの初期化
export function initializeLocalDatabase() {
  // クライアントデータがなければ初期データを投入
  if (getClients().length === 0) {
    saveToStorage(STORAGE_KEYS.CLIENTS, [
      {
        client_id: "cl00001",
        client_name: "サンプル株式会社",
        contact_person: "山田太郎",
        email: "yamada@example.com",
        phone: "03-1234-5678",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
  }

  // プロジェクトデータがなければ初期データを投入
  if (getProjects().length === 0) {
    saveToStorage(STORAGE_KEYS.PROJECTS, [
      {
        project_id: "cl00001_pr00001",
        project_name: "2025年春キャンペーン",
        client_id: "cl00001",
        description: "新商品のプロモーション",
        start_date: new Date("2025-03-01").toISOString(),
        end_date: new Date("2025-05-31").toISOString(),
        status: "planning",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
  }

  // キャンペーンデータがなければ初期データを投入
  if (getCampaigns().length === 0) {
    saveToStorage(STORAGE_KEYS.CAMPAIGNS, [
      {
        campaign_id: "cl00001_pr00001_ca00001",
        campaign_name: "SNS認知拡大キャンペーン",
        project_id: "cl00001_pr00001",
        objective: "awareness",
        status: "draft",
        start_date: new Date("2025-03-01").toISOString(),
        end_date: new Date("2025-03-31").toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
  }

  // 広告セットデータがなければ初期データを投入
  if (getAdSets().length === 0) {
    saveToStorage(STORAGE_KEYS.AD_SETS, [
      {
        adset_id: "cl00001_pr00001_ca00001_as00001",
        adset_name: "20-30代女性向け広告セット",
        campaign_id: "cl00001_pr00001_ca00001",
        campaign_name: "SNS認知拡大キャンペーン",
        daily_budget: "5000",
        start_time: new Date("2025-03-01").toISOString(),
        end_time: new Date("2025-03-31").toISOString(),
        billing_event: "IMPRESSIONS",
        optimization_goal: "REACH",
        bid_strategy: "LOWEST_COST_WITHOUT_CAP",
        status: "ACTIVE",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      },
    ])
  }
}
