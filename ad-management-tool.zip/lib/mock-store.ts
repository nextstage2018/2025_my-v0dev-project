// モックAPIのデータを保持するためのインメモリストア
// 注: このデータはサーバー再起動時にリセットされます

// クライアントデータ
export const mockClients: any[] = [
  {
    client_id: "cl00001",
    client_name: "サンプル株式会社",
    contact_person: "山田太郎",
    email: "yamada@example.com",
    phone: "03-1234-5678",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// プロジェクトデータ
export const mockProjects: any[] = [
  {
    project_id: "cl00001_pr00001",
    project_name: "2025年春キャンペーン",
    client_id: "cl00001",
    client_name: "サンプル株式会社",
    description: "新商品のプロモーション",
    start_date: new Date("2025-03-01").toISOString(),
    end_date: new Date("2025-05-31").toISOString(),
    status: "planning",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// キャンペーンデータ
export const mockCampaigns: any[] = [
  {
    campaign_id: "cl00001_pr00001_ca00001",
    campaign_name: "SNS認知拡大キャンペーン",
    project_id: "cl00001_pr00001",
    project_name: "2025年春キャンペーン",
    client_id: "cl00001",
    client_name: "サンプル株式会社",
    objective: "awareness",
    status: "draft",
    start_date: new Date("2025-03-01").toISOString(),
    end_date: new Date("2025-03-31").toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// 広告セットデータ
export const mockAdSets: any[] = [
  {
    adset_id: "cl00001_pr00001_ca00001_as00001",
    adset_name: "20-30代女性向け広告セット",
    campaign_id: "cl00001_pr00001_ca00001",
    campaign_name: "SNS認知拡大キャンペーン",
    daily_budget: "5000",
    start_time: new Date("2025-03-01").toISOString(),
    end_time: new Date("2025-03-31").toISOString(),
    billing_event: "IMPRESSIONS",
    optimization_goal: "REACH",
    bid_strategy: "LOWEST_COST_WITHOUT_CAP",
    status: "ACTIVE",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// クリエイティブデータ
export const mockCreatives: any[] = [
  {
    creative_id: "cr00001",
    creative_name: "春の新商品バナー",
    creative_type: "image",
    creative_url: "https://example.com/images/spring_product.jpg",
    creative_text: "春の新商品が登場！期間限定20%オフ",
    width: 1200,
    height: 628,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    creative_id: "cr00002",
    creative_name: "商品紹介動画",
    creative_type: "video",
    creative_url: "https://example.com/videos/product_intro.mp4",
    creative_text: "新商品の魅力を動画でチェック",
    duration: 30,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// 広告データ
export const mockAds: any[] = [
  {
    ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
    ad_name: "春の新商品バナー広告",
    campaign_id: "cl00001_pr00001_ca00001",
    campaign_name: "SNS認知拡大キャンペーン",
    adset_id: "cl00001_pr00001_ca00001_as00001",
    adset_name: "20-30代女性向け広告セット",
    creative_id: "cr00001",
    status: "ACTIVE",
    status_reason: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    ad_id: "cl00001_pr00001_ca00001_as00001_ad00002",
    ad_name: "商品紹介動画広告",
    campaign_id: "cl00001_pr00001_ca00001",
    campaign_name: "SNS認知拡大キャンペーン",
    adset_id: "cl00001_pr00001_ca00001_as00001",
    adset_name: "20-30代女性向け広告セット",
    creative_id: "cr00002",
    status: "PAUSED",
    status_reason: "予算調整のため一時停止",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// ターゲティングデータ
export const mockTargeting: any[] = [
  {
    targeting_id: "tg00001",
    ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
    age_min: 20,
    age_max: 39,
    genders: [2], // 女性
    geo_locations: {
      countries: ["JP"],
      regions: [
        { key: "JP-13" }, // 東京
      ],
    },
    interests: [
      { id: "6003139266461", name: "ファッション" },
      { id: "6003139266462", name: "美容" },
    ],
    device_platforms: ["mobile", "desktop"],
    publisher_platforms: ["facebook", "instagram"],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    targeting_id: "tg00002",
    ad_id: "cl00001_pr00001_ca00001_as00001_ad00002",
    age_min: 20,
    age_max: 39,
    genders: [2], // 女性
    geo_locations: {
      countries: ["JP"],
      regions: [
        { key: "JP-13" }, // 東京
        { key: "JP-27" }, // 大阪
      ],
    },
    interests: [
      { id: "6003139266461", name: "ファッション" },
      { id: "6003139266462", name: "美容" },
    ],
    device_platforms: ["mobile"],
    publisher_platforms: ["instagram"],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// 広告パフォーマンスデータ
export const mockAdPerformance: any[] = generateMockPerformanceData()

// パフォーマンスデータ生成関数
function generateMockPerformanceData() {
  const data: any[] = []
  const ads = ["cl00001_pr00001_ca00001_as00001_ad00001", "cl00001_pr00001_ca00001_as00001_ad00002"]
  const today = new Date()

  // 過去30日分のデータを生成
  for (let i = 0; i < 30; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const dateStr = date.toISOString().split("T")[0]

    ads.forEach((adId) => {
      // 基本値
      const baseImpressions = Math.floor(Math.random() * 1000) + 500
      const baseClicks = Math.floor(baseImpressions * (Math.random() * 0.05 + 0.01)) // 1-6% CTR
      const baseConversions = Math.floor(baseClicks * (Math.random() * 0.1 + 0.05)) // 5-15% CVR
      const baseSpend = Math.floor(baseImpressions * (Math.random() * 0.5 + 0.5)) // 0.5-1円/imp

      // トレンドを付ける（日付が新しいほど数値が良くなる）
      const dayFactor = 1 + (30 - i) * 0.01 // 最大30%増加

      data.push({
        performance_id: `perf_${adId}_${dateStr}`,
        ad_id: adId,
        date: dateStr,
        impressions: Math.floor(baseImpressions * dayFactor),
        clicks: Math.floor(baseClicks * dayFactor),
        conversions: Math.floor(baseConversions * dayFactor),
        spend: Math.floor(baseSpend * dayFactor),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
    })
  }

  return data
}

// ユーザーデータ
export const mockUsers: any[] = [
  {
    user_id: "usr00001",
    user_name: "管理者ユーザー",
    email: "admin@example.com",
    user_role: "admin",
    department: "マーケティング部",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    user_id: "usr00002",
    user_name: "運用者ユーザー",
    email: "operator@example.com",
    user_role: "operator",
    department: "広告運用部",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// IDマッピングデータ
export const mockIdMappings: any[] = [
  {
    adaccount_id: "act_123456789",
    campaign_id: "23456789012345678",
    adset_id: "34567890123456789",
    ad_id: "45678901234567890",
    internal_campaign_id: "cl00001_pr00001_ca00001",
    internal_adset_id: "cl00001_pr00001_ca00001_as00001",
    internal_ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// Google Driveフォルダデータ
export const mockDriveFolders: any[] = [
  {
    folder_id: "1Abc2DefGhiJkLmNoPqRsTuVwXyZ",
    internal_project_id: "cl00001_pr00001",
    folder_url: "https://drive.google.com/drive/folders/1Abc2DefGhiJkLmNoPqRsTuVwXyZ",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    additional_info: JSON.stringify({ description: "サンプル広告画像フォルダ" }),
    internal_campaign_id: "cl00001_pr00001_ca00001",
    internal_adset_id: "cl00001_pr00001_ca00001_as00001",
    internal_ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
    account_id: "act_123456789",
    campaign_id: "23456789012345678",
    adset_id: "34567890123456789",
    ad_id: "45678901234567890",
    file_type: "image",
    creative_item_id: "cr00001",
    creative_item_name: "サンプル広告画像1",
  },
]

// 広告検証設定データ
export const mockAnalyses: any[] = [
  {
    analysis_id: "an00001",
    analysis_date: new Date().toISOString().split("T")[0],
    account_id: "act_123456789",
    internal_project_id: "cl00001_pr00001",
    internal_campaign_id: "cl00001_pr00001_ca00001",
    internal_adset_id: "cl00001_pr00001_ca00001_as00001",
    internal_ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
    creative_item_id: "cr00001",
    appeal_target: "20代〜30代の女性",
    emphasis_theme: "ブランド価値の強調",
    appeal_content: "商品の特徴と利点",
    design_structure: "シンプルなレイアウトと明るい色調",
    target_date: new Date().toISOString().split("T")[0],
    goal_event: "商品購入",
    goal_value: 5.0,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
]

// 運用ログデータ
export const mockOperationLogs: any[] = [
  {
    operation_id: "op1617283940123001",
    operation_type: "予算変更",
    operation_status: "完了",
    operation_message: "日予算を5,000円から10,000円に増額しました",
    executed_by: "usr00001",
    operation_timestamp: new Date().toISOString(),
    account_id: "act_123456789",
    campaign_id: "23456789012345678",
    adset_id: "34567890123456789",
    ad_id: "45678901234567890",
    internal_project_id: "cl00001_pr00001",
    internal_campaign_id: "cl00001_pr00001_ca00001",
    internal_adset_id: "cl00001_pr00001_ca00001_as00001",
    internal_ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
  },
]
