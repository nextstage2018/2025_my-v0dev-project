import type { IndustryCategory, MediaType } from "./master-data-types"

// ローカルストレージのキー
const STORAGE_KEYS = {
  INDUSTRY_CATEGORIES: "ad_tool_industry_categories",
  MEDIA_TYPES: "ad_tool_media_types",
}

// 業界カテゴリの取得
export function getIndustryCategories(): IndustryCategory[] {
  if (typeof window === "undefined") return []

  try {
    const data = localStorage.getItem(STORAGE_KEYS.INDUSTRY_CATEGORIES)
    return data ? JSON.parse(data) : []
  } catch (error) {
    console.error("業界カテゴリの取得エラー:", error)
    return []
  }
}

// 業界カテゴリの保存
export function saveIndustryCategories(categories: IndustryCategory[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(STORAGE_KEYS.INDUSTRY_CATEGORIES, JSON.stringify(categories))
  } catch (error) {
    console.error("業界カテゴリの保存エラー:", error)
  }
}

// メディアタイプの取得
export function getMediaTypes(): MediaType[] {
  if (typeof window === "undefined") return []

  try {
    const data = localStorage.getItem(STORAGE_KEYS.MEDIA_TYPES)
    return data ? JSON.parse(data) : []
  } catch (error) {
    console.error("メディアタイプの取得エラー:", error)
    return []
  }
}

// メディアタイプの保存
export function saveMediaTypes(mediaTypes: MediaType[]): void {
  if (typeof window === "undefined") return

  try {
    localStorage.setItem(STORAGE_KEYS.MEDIA_TYPES, JSON.stringify(mediaTypes))
  } catch (error) {
    console.error("メディアタイプの保存エラー:", error)
  }
}

// マスタデータの初期化
export function initializeMasterData(industryCategories: IndustryCategory[], mediaTypes: MediaType[]): void {
  if (typeof window === "undefined") return

  // 業界カテゴリの初期化
  if (!localStorage.getItem(STORAGE_KEYS.INDUSTRY_CATEGORIES)) {
    saveIndustryCategories(industryCategories)
  }

  // メディアタイプの初期化
  if (!localStorage.getItem(STORAGE_KEYS.MEDIA_TYPES)) {
    saveMediaTypes(mediaTypes)
  }
}
