// ID生成ユーティリティ関数

/**
 * 次の連番を生成する関数
 * @param lastId 最後のID（例: "00001"）
 * @returns 次の連番（例: "00002"）
 */
export function getNextSequence(lastId: string | null | undefined): string {
  if (!lastId) return "00001"

  const numericPart = Number.parseInt(lastId, 10)
  return String(numericPart + 1).padStart(5, "0")
}

/**
 * クライアントIDを生成する関数
 * @param existingIds 既存のクライアントID配列
 * @returns 新しいクライアントID（例: "cl00001"）
 */
export function generateClientId(existingIds: string[] = []): string {
  if (existingIds.length === 0) return "cl00001"

  // 最後のIDから数値部分を抽出
  const lastId = existingIds
    .map((id) => id.substring(2)) // "cl"を除去
    .sort((a, b) => Number.parseInt(b, 10) - Number.parseInt(a, 10))[0] // 降順ソートして最大値を取得

  return `cl${getNextSequence(lastId)}`
}

/**
 * プロジェクトIDを生成する関数
 * @param clientId クライアントID（例: "cl00001"）
 * @param existingIds 既存のプロジェクトID配列
 * @returns 新しいプロジェクトID（例: "cl00001_pr00001"）
 */
export function generateProjectId(clientId: string, existingIds: string[] = []): string {
  if (existingIds.length === 0) return `${clientId}_pr00001`

  // クライアントに関連する既存のプロジェクトIDをフィルタリング
  const clientProjects = existingIds.filter((id) => id.startsWith(clientId))

  if (clientProjects.length === 0) return `${clientId}_pr00001`

  // 最後のIDから数値部分を抽出
  const lastId = clientProjects
    .map((id) => id.split("_pr")[1]) // "pr"以降の部分を取得
    .sort((a, b) => Number.parseInt(b, 10) - Number.parseInt(a, 10))[0] // 降順ソートして最大値を取得

  return `${clientId}_pr${getNextSequence(lastId)}`
}

/**
 * キャンペーンIDを生成する関数
 * @param projectId プロジェクトID（例: "cl00001_pr00001"）
 * @param existingIds 既存のキャンペーンID配列
 * @returns 新しいキャンペーンID（例: "cl00001_pr00001_ca00001"）
 */
export function generateCampaignId(projectId: string, existingIds: string[] = []): string {
  if (existingIds.length === 0) return `${projectId}_ca00001`

  // プロジェクトに関連する既存のキャンペーンIDをフィルタリング
  const projectCampaigns = existingIds.filter((id) => id.startsWith(projectId))

  if (projectCampaigns.length === 0) return `${projectId}_ca00001`

  // 最後のIDから数値部分を抽出
  const lastId = projectCampaigns
    .map((id) => id.split("_ca")[1]) // "ca"以降の部分を取得
    .sort((a, b) => Number.parseInt(b, 10) - Number.parseInt(a, 10))[0] // 降順ソートして最大値を取得

  return `${projectId}_ca${getNextSequence(lastId)}`
}

/**
 * 広告セットIDを生成する関数
 * @param campaignId キャンペーンID（例: "cl00001_pr00001_ca00001"）
 * @param existingIds 既存の広告セットID配列
 * @returns 新しい広告セットID（例: "cl00001_pr00001_ca00001_as00001"）
 */
export function generateAdSetId(campaignId: string, existingIds: string[] = []): string {
  if (existingIds.length === 0) return `${campaignId}_as00001`

  // キャンペーンに関連する既存の広告セットIDをフィルタリング
  const campaignAdSets = existingIds.filter((id) => id.startsWith(campaignId))

  if (campaignAdSets.length === 0) return `${campaignId}_as00001`

  // 最後のIDから数値部分を抽出
  const lastId = campaignAdSets
    .map((id) => id.split("_as")[1]) // "as"以降の部分を取得
    .sort((a, b) => Number.parseInt(b, 10) - Number.parseInt(a, 10))[0] // 降順ソートして最大値を取得

  return `${campaignId}_as${getNextSequence(lastId)}`
}

/**
 * 広告IDを生成する関数
 * @param adSetId 広告セットID（例: "cl00001_pr00001_ca00001_as00001"）
 * @param existingIds 既存の広告ID配列
 * @returns 新しい広告ID（例: "cl00001_pr00001_ca00001_as00001_ad00001"）
 */
export function generateAdId(adSetId: string, existingIds: string[] = []): string {
  if (existingIds.length === 0) return `${adSetId}_ad00001`

  // 広告セットに関連する既存の広告IDをフィルタリング
  const adSetAds = existingIds.filter((id) => id.startsWith(adSetId))

  if (adSetAds.length === 0) return `${adSetId}_ad00001`

  // 最後のIDから数値部分を抽出
  const lastId = adSetAds
    .map((id) => id.split("_ad")[1]) // "ad"以降の部分を取得
    .sort((a, b) => Number.parseInt(b, 10) - Number.parseInt(a, 10))[0] // 降順ソートして最大値を取得

  return `${adSetId}_ad${getNextSequence(lastId)}`
}
