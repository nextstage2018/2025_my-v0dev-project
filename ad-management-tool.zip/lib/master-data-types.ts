// 業界マスタのデータ型
export type IndustryCategory = {
  id: string
  main_category: string
  sub_categories: IndustrySubCategory[]
}

export type IndustrySubCategory = {
  id: string
  name: string
}

// メディアマスタのデータ型
export type MediaType = {
  media_id: string
  media_type: string
  media_name: string
  description?: string
}

// 報酬形態の選択肢
export const COMMISSION_TYPES = [
  { id: "fixed", name: "固定報酬" },
  { id: "percentage", name: "手数料型（%）" },
  { id: "performance", name: "成果報酬型" },
  { id: "hybrid", name: "ハイブリッド型" },
  { id: "other", name: "その他" },
]

// 配信ステータスの選択肢
export const DELIVERY_STATUSES = [
  { id: "inactive", name: "配信停止" },
  { id: "active", name: "配信中" },
  { id: "pending", name: "未配信" },
]

// サンプルの業界カテゴリデータ
export const INDUSTRY_CATEGORIES: IndustryCategory[] = [
  {
    id: "retail",
    main_category: "小売業",
    sub_categories: [
      { id: "retail_fashion", name: "ファッション" },
      { id: "retail_food", name: "食品" },
      { id: "retail_electronics", name: "家電" },
      { id: "retail_furniture", name: "家具・インテリア" },
    ],
  },
  {
    id: "finance",
    main_category: "金融業",
    sub_categories: [
      { id: "finance_banking", name: "銀行" },
      { id: "finance_insurance", name: "保険" },
      { id: "finance_securities", name: "証券" },
      { id: "finance_credit", name: "クレジットカード・ローン" },
    ],
  },
  {
    id: "it",
    main_category: "IT・通信",
    sub_categories: [
      { id: "it_software", name: "ソフトウェア" },
      { id: "it_hardware", name: "ハードウェア" },
      { id: "it_service", name: "ITサービス" },
      { id: "it_telecom", name: "通信" },
    ],
  },
  {
    id: "manufacturing",
    main_category: "製造業",
    sub_categories: [
      { id: "manufacturing_auto", name: "自動車" },
      { id: "manufacturing_electronics", name: "電子機器" },
      { id: "manufacturing_chemical", name: "化学" },
      { id: "manufacturing_food", name: "食品製造" },
    ],
  },
  {
    id: "service",
    main_category: "サービス業",
    sub_categories: [
      { id: "service_restaurant", name: "飲食" },
      { id: "service_hotel", name: "宿泊" },
      { id: "service_entertainment", name: "エンターテイメント" },
      { id: "service_education", name: "教育" },
    ],
  },
]

// サンプルのメディアタイプデータ
export const MEDIA_TYPES: MediaType[] = [
  {
    media_id: "fb",
    media_type: "SNS",
    media_name: "Facebook",
    description: "Facebookの広告配信",
  },
  {
    media_id: "ig",
    media_type: "SNS",
    media_name: "Instagram",
    description: "Instagramの広告配信",
  },
  {
    media_id: "tw",
    media_type: "SNS",
    media_name: "Twitter",
    description: "Twitterの広告配信",
  },
  {
    media_id: "li",
    media_type: "SNS",
    media_name: "LinkedIn",
    description: "LinkedInの広告配信",
  },
  {
    media_id: "yt",
    media_type: "動画",
    media_name: "YouTube",
    description: "YouTubeの広告配信",
  },
  {
    media_id: "ggl",
    media_type: "検索",
    media_name: "Google検索",
    description: "Google検索広告",
  },
  {
    media_id: "gdn",
    media_type: "ディスプレイ",
    media_name: "Google Display Network",
    description: "Googleディスプレイネットワーク",
  },
  {
    media_id: "ydn",
    media_type: "ディスプレイ",
    media_name: "Yahoo!ディスプレイ広告",
    description: "Yahoo!ディスプレイ広告",
  },
  {
    media_id: "line",
    media_type: "SNS",
    media_name: "LINE",
    description: "LINE広告",
  },
  {
    media_id: "tiktok",
    media_type: "SNS",
    media_name: "TikTok",
    description: "TikTok広告",
  },
]
