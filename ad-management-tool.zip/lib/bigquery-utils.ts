import { BigQuery } from "@google-cloud/bigquery"

// BigQueryクライアントの初期化
export const getBigQueryClient = () => {
  try {
    // 環境変数からBigQuery接続情報を取得
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const keyFilename = process.env.GOOGLE_APPLICATION_CREDENTIALS

    if (!projectId || !keyFilename) {
      throw new Error("BigQuery接続情報が設定されていません")
    }

    return new BigQuery({
      projectId,
      keyFilename,
    })
  } catch (error) {
    console.error("BigQueryクライアント初期化エラー:", error)
    throw error
  }
}

// テーブル作成関数
export const createTableIfNotExists = async (datasetId: string, tableId: string, schema: any[]) => {
  const bigquery = getBigQueryClient()
  const dataset = bigquery.dataset(datasetId)
  const table = dataset.table(tableId)

  try {
    // テーブルが存在するか確認
    const [exists] = await table.exists()

    if (!exists) {
      // テーブルが存在しない場合は作成
      const options = {
        schema: schema,
        location: process.env.BIGQUERY_REGION || "asia-northeast1",
      }

      await dataset.createTable(tableId, options)
      console.log(`テーブル ${tableId} を作成しました`)
    } else {
      console.log(`テーブル ${tableId} は既に存在します`)
    }

    return table
  } catch (error) {
    console.error(`テーブル ${tableId} の作成中にエラーが発生しました:`, error)
    throw error
  }
}

// クエリ実行関数
export const executeQuery = async (query: string) => {
  try {
    const bigquery = getBigQueryClient()
    const [rows] = await bigquery.query({ query })
    return rows
  } catch (error) {
    console.error("クエリ実行エラー:", error)
    throw error
  }
}

// データ挿入関数
export const insertData = async (datasetId: string, tableId: string, data: any[]) => {
  try {
    const bigquery = getBigQueryClient()
    const dataset = bigquery.dataset(datasetId)
    const table = dataset.table(tableId)

    await table.insert(data)
    return true
  } catch (error) {
    console.error("データ挿入エラー:", error)
    throw error
  }
}
