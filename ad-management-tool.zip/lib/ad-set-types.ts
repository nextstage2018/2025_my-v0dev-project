// 広告セットの課金イベント種別
export const BILLING_EVENTS = [
  { id: "IMPRESSIONS", name: "インプレッション課金" },
  { id: "LINK_CLICKS", name: "リンククリック課金" },
  { id: "CONVERSIONS", name: "コンバージョン課金" },
  { id: "APP_INSTALLS", name: "アプリインストール課金" },
  { id: "PAGE_LIKES", name: "ページいいね課金" },
  { id: "OFFER_CLAIMS", name: "オファー獲得課金" },
  { id: "THRUPLAY", name: "動画視聴課金" },
] as const

// 最適化目標
export const OPTIMIZATION_GOALS = [
  { id: "REACH", name: "リーチ" },
  { id: "IMPRESSIONS", name: "インプレッション" },
  { id: "LINK_CLICKS", name: "リンククリック" },
  { id: "CONVERSIONS", name: "コンバージョン" },
  { id: "LEAD_GENERATION", name: "リード獲得" },
  { id: "APP_INSTALLS", name: "アプリインストール" },
  { id: "VALUE", name: "購入価値" },
  { id: "ENGAGEMENT", name: "エンゲージメント" },
  { id: "VIDEO_VIEWS", name: "動画視聴" },
] as const

// 入札戦略
export const BID_STRATEGIES = [
  { id: "LOWEST_COST_WITHOUT_CAP", name: "最低コスト（上限なし）" },
  { id: "LOWEST_COST_WITH_BID_CAP", name: "最低コスト（上限あり）" },
  { id: "COST_CAP", name: "コスト上限" },
  { id: "TARGET_COST", name: "目標コスト" },
  { id: "HIGHEST_VALUE", name: "最高価値" },
] as const

// ペーシングタイプ
export const PACING_TYPES = [
  { id: "STANDARD", name: "標準（均等配信）" },
  { id: "ACCELERATED", name: "加速（早期配信）" },
] as const

// 広告セットのターゲティング設定
export type AdSetTargeting = {
  geo_locations?: {
    countries?: string[]
    regions?: { key: string }[]
    cities?: { key: string }[]
    zips?: { key: string }[]
  }
  age_min?: number
  age_max?: number
  genders?: number[] // 1: 男性, 2: 女性
  interests?: { id: string; name: string }[]
  behaviors?: { id: string; name: string }[]
  device_platforms?: string[] // mobile, desktop
  publisher_platforms?: string[] // facebook, instagram, audience_network, messenger
  facebook_positions?: string[] // feed, right_hand_column, instant_article, etc.
  instagram_positions?: string[] // stream, story, explore, etc.
  excluded_publisher_platforms?: string[]
  excluded_facebook_positions?: string[]
  excluded_instagram_positions?: string[]
}

// 広告セットのスケジュール設定
export type AdSetSchedule = {
  start_minute: number // 0-1439 (0 = 午前0時, 1439 = 午後11時59分)
  end_minute: number // 0-1439
  days: number[] // 1-7 (1 = 月曜日, 7 = 日曜日)
}

// 頻度制御設定
export type FrequencyControlSpec = {
  event: string // IMPRESSIONS, VIDEO_VIEWS
  max_frequency: number
  time_window: number // 日数
}

// アトリビューション設定
export type AttributionSpec = {
  event_type: string // CLICK, VIEW
  window_days: number
}

// プロモートオブジェクト
export type PromotedObject = {
  pixel_id?: string
  page_id?: string
  application_id?: string
  object_store_url?: string
  conversion_event?: string
  product_set_id?: string
  custom_event_type?: string
}

// 広告セットのデータ型
export type AdSet = {
  adset_id: string
  adset_name: string
  campaign_id: string
  campaign_name?: string
  daily_budget?: string
  lifetime_budget?: string
  start_time: string
  end_time?: string
  billing_event: string
  optimization_goal: string
  bid_strategy: string
  bid_amount?: string
  promoted_object?: PromotedObject
  targeting?: AdSetTargeting
  attribution_spec?: AttributionSpec[]
  optimization_sub_event?: string
  pacing_type?: string[]
  frequency_control_specs?: FrequencyControlSpec[]
  adset_schedule?: AdSetSchedule[]
  daily_min_spend_target?: string
  daily_spend_cap?: string
  adLabels?: string[]
  source_adset_id?: string
  status?: string
  created_at: string
  updated_at: string
}
