"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Database, Layers, Home } from "lucide-react"

export function MasterNav() {
  const pathname = usePathname()

  return (
    <nav className="flex space-x-2 lg:flex-col lg:space-x-0 lg:space-y-1">
      <Link href="/master">
        <Button variant={pathname === "/master" ? "default" : "ghost"} className="w-full justify-start">
          <Home className="mr-2 h-4 w-4" />
          マスタ管理トップ
        </Button>
      </Link>
      <Link href="/master/industry">
        <Button variant={pathname === "/master/industry" ? "default" : "ghost"} className="w-full justify-start">
          <Layers className="mr-2 h-4 w-4" />
          業界マスタ管理
        </Button>
      </Link>
      <Link href="/master/media">
        <Button variant={pathname === "/master/media" ? "default" : "ghost"} className="w-full justify-start">
          <Database className="mr-2 h-4 w-4" />
          メディアマスタ管理
        </Button>
      </Link>
      <Link href="/">
        <Button variant="ghost" className="w-full justify-start">
          <Home className="mr-2 h-4 w-4" />
          ホームに戻る
        </Button>
      </Link>
    </nav>
  )
}
