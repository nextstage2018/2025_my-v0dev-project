"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import DatabaseModeSelector from "./database-mode-selector"

// IDマッピングのバリデーションスキーマ
const idMappingSchema = z.object({
  adaccount_id: z.string().min(1, "アカウントIDは必須です"),
  campaign_id: z.string().min(1, "外部キャンペーンIDは必須です"),
  adset_id: z.string().min(1, "外部広告セットIDは必須です"),
  ad_id: z.string().min(1, "外部広告IDは必須です"),
  internal_campaign_id: z.string().min(1, "内部キャンペーンIDは必須です"),
  internal_adset_id: z.string().min(1, "内部広告セットIDは必須です"),
  internal_ad_id: z.string().min(1, "内部広告IDは必須です"),
})

type IdMappingFormValues = z.infer<typeof idMappingSchema>

export default function IdMappingForm() {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const form = useForm<IdMappingFormValues>({
    resolver: zodResolver(idMappingSchema),
    defaultValues: {
      adaccount_id: "",
      campaign_id: "",
      adset_id: "",
      ad_id: "",
      internal_campaign_id: "",
      internal_adset_id: "",
      internal_ad_id: "",
    },
  })

  const onSubmit = async (data: IdMappingFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      if (mode === "local") {
        // ローカルストレージに保存
        const mappingData = {
          ...data,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        // 既存のマッピングを確認（広告IDで検索）
        const existingMapping = LocalStorage.getIdMappingByExternalId(data.ad_id)
        if (existingMapping) {
          // 既存のマッピングを更新
          const updatedMapping = {
            ...existingMapping,
            ...data,
            updated_at: new Date().toISOString(),
          }
          LocalStorage.saveIdMapping(updatedMapping)
          setSuccess("IDマッピングを更新しました")
        } else {
          // 新しいマッピングを追加
          LocalStorage.saveIdMapping(mappingData)
          setSuccess("IDマッピングを登録しました")
        }
      } else if (mode === "mock-api") {
        // モックAPIに保存
        const response = await fetch(`/api/mock/id-mapping/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ...data,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "IDマッピングの登録に失敗しました")
        }

        setSuccess("IDマッピングを登録しました (Mock API)")
      } else {
        throw new Error("無効なモードです")
      }
    } catch (error: any) {
      setError(error.message || "IDマッピングの登録に失敗しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>IDマッピング</CardTitle>
        <CardDescription>広告プラットフォームのIDと内部IDをマッピングします。</CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="adaccount_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>アカウントID</FormLabel>
                  <FormControl>
                    <Input placeholder="アカウントID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="campaign_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>外部キャンペーンID</FormLabel>
                  <FormControl>
                    <Input placeholder="外部キャンペーンID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="adset_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>外部広告セットID</FormLabel>
                  <FormControl>
                    <Input placeholder="外部広告セットID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="ad_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>外部広告ID</FormLabel>
                  <FormControl>
                    <Input placeholder="外部広告ID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="internal_campaign_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>内部キャンペーンID</FormLabel>
                  <FormControl>
                    <Input placeholder="内部キャンペーンID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="internal_adset_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>内部広告セットID</FormLabel>
                  <FormControl>
                    <Input placeholder="内部広告セットID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="internal_ad_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>内部広告ID</FormLabel>
                  <FormControl>
                    <Input placeholder="内部広告ID" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              登録
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter>
        <DatabaseModeSelector />
      </CardFooter>
    </Card>
  )
}
