"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Plus, ExternalLink, FileImage, FileVideo } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"

type DriveFolder = {
  folder_id: string
  internal_project_id: string
  folder_url: string
  created_at: string
  updated_at: string
  additional_info?: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  file_type: string
  creative_item_id: string
  creative_item_name: string
}

type DriveFolderListProps = {
  projectId?: string
  campaignId?: string
  adsetId?: string
  adId?: string
}

export default function DriveFolderList({ projectId, campaignId, adsetId, adId }: DriveFolderListProps) {
  const { mode } = useDatabase()
  const [folders, setFolders] = useState<DriveFolder[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchFolders = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージからフォルダ一覧を取得
        let localFolders = LocalStorage.getDriveFolders()

        // フィルタリング
        if (projectId) {
          localFolders = localFolders.filter((folder) => folder.internal_project_id === projectId)
        }
        if (campaignId) {
          localFolders = localFolders.filter((folder) => folder.internal_campaign_id === campaignId)
        }
        if (adsetId) {
          localFolders = localFolders.filter((folder) => folder.internal_adset_id === adsetId)
        }
        if (adId) {
          localFolders = localFolders.filter((folder) => folder.internal_ad_id === adId)
        }

        setFolders(localFolders)
      } else if (mode === "mock-api") {
        // モックAPIからフォルダ一覧を取得
        let url = `/api/mock/drive-folders/list`
        const params = new URLSearchParams()
        if (projectId) params.append("project_id", projectId)
        if (campaignId) params.append("campaign_id", campaignId)
        if (adsetId) params.append("adset_id", adsetId)
        if (adId) params.append("ad_id", adId)

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("Google Driveフォルダ情報の取得に失敗しました")
        }

        const data = await response.json()
        setFolders(data.folders || [])
      } else {
        // 実際のBigQuery APIからフォルダ一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        let url = `${apiBaseUrl}/api/drive-folders/list`
        const params = new URLSearchParams()
        if (projectId) params.append("project_id", projectId)
        if (campaignId) params.append("campaign_id", campaignId)
        if (adsetId) params.append("adset_id", adsetId)
        if (adId) params.append("ad_id", adId)

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("Google Driveフォルダ情報の取得に失敗しました")
        }

        const data = await response.json()
        setFolders(data.folders || [])
      }
    } catch (err: any) {
      console.error("Google Driveフォルダ取得エラー:", err)
      setError(err instanceof Error ? err.message : "Google Driveフォルダ情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchFolders()
  }, [mode, projectId, campaignId, adsetId, adId])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getFileTypeIcon = (fileType: string) => {
    switch (fileType.toLowerCase()) {
      case "image":
        return <FileImage className="h-4 w-4" />
      case "video":
        return <FileVideo className="h-4 w-4" />
      default:
        return <FileImage className="h-4 w-4" />
    }
  }

  const getFileTypeBadge = (fileType: string) => {
    switch (fileType.toLowerCase()) {
      case "image":
        return <Badge variant="outline">画像</Badge>
      case "video":
        return <Badge variant="secondary">動画</Badge>
      default:
        return <Badge variant="outline">{fileType}</Badge>
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>広告画像一覧</CardTitle>
          <CardDescription>登録されている広告画像の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/creative/new">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchFolders} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : folders.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            広告画像情報がありません。新しい広告画像を登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>画像名</TableHead>
                  <TableHead>タイプ</TableHead>
                  <TableHead>キャンペーン</TableHead>
                  <TableHead>広告セット</TableHead>
                  <TableHead>広告</TableHead>
                  <TableHead>登録日時</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {folders.map((folder) => (
                  <TableRow key={folder.folder_id}>
                    <TableCell className="font-medium flex items-center gap-2">
                      {getFileTypeIcon(folder.file_type)}
                      {folder.creative_item_name}
                    </TableCell>
                    <TableCell>{getFileTypeBadge(folder.file_type)}</TableCell>
                    <TableCell>{folder.internal_campaign_id}</TableCell>
                    <TableCell>{folder.internal_adset_id}</TableCell>
                    <TableCell>{folder.internal_ad_id}</TableCell>
                    <TableCell>{formatDate(folder.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <a href={folder.folder_url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                            <span className="sr-only">フォルダを開く</span>
                          </a>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
