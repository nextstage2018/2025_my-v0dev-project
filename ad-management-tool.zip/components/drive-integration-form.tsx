"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, ExternalLink } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useDatabase } from "@/contexts/database-context"

// Google Drive連携のバリデーションスキーマ
const driveIntegrationSchema = z.object({
  client_id: z.string().min(1, "クライアントIDは必須です"),
  client_secret: z.string().min(1, "クライアントシークレットは必須です"),
  redirect_uri: z.string().url("有効なURLを入力してください"),
  scope: z.string().min(1, "スコープは必須です"),
  folder_id: z.string().optional(),
  description: z.string().optional(),
})

type DriveIntegrationFormValues = z.infer<typeof driveIntegrationSchema>

export default function DriveIntegrationForm() {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [authUrl, setAuthUrl] = useState<string | null>(null)

  const form = useForm<DriveIntegrationFormValues>({
    resolver: zodResolver(driveIntegrationSchema),
    defaultValues: {
      client_id: "",
      client_secret: "",
      redirect_uri: `${window.location.origin}/integrations/drive/callback`,
      scope: "https://www.googleapis.com/auth/drive.file",
      folder_id: "",
      description: "",
    },
  })

  const onSubmit = async (data: DriveIntegrationFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)
    setAuthUrl(null)

    try {
      // APIエンドポイントの準備
      let url: string
      if (mode === "local" || mode === "mock-api") {
        url = `/api/mock/integrations/drive/auth`
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        url = `${apiBaseUrl}/api/integrations/drive/auth`
      }

      // 認証URLを取得するリクエスト
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Google Drive連携の設定に失敗しました")
      }

      const result = await response.json()
      setAuthUrl(result.authUrl)
      setSuccess("Google Drive連携の設定が完了しました。認証URLをクリックして連携を完了してください。")
    } catch (err) {
      console.error("Google Drive連携エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Google Drive連携設定</CardTitle>
        <CardDescription>広告クリエイティブを保存するためのGoogle Drive連携を設定します。</CardDescription>
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            {authUrl && (
              <Alert className="bg-blue-50 border-blue-500 text-blue-700">
                <div className="flex flex-col space-y-2">
                  <p>以下のURLをクリックしてGoogle Driveとの連携を完了してください：</p>
                  <a
                    href={authUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline flex items-center gap-1"
                  >
                    Google認証ページへ移動
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="client_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Google APIクライアントID</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="例: 123456789012-abcdefghijklmnopqrstuvwxyz.apps.googleusercontent.com"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="client_secret"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Google APIクライアントシークレット</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="クライアントシークレット" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="redirect_uri"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>リダイレクトURI</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="scope"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>スコープ</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="folder_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>フォルダID（任意）</FormLabel>
                  <FormControl>
                    <Input placeholder="例: 1aBcDeFgHiJkLmNoPqRsTuVwXyZ" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>説明（任意）</FormLabel>
                  <FormControl>
                    <Textarea placeholder="連携の目的や用途など" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  連携設定中...
                </>
              ) : (
                "連携を設定"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
