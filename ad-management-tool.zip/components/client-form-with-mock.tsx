"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { generateClientId } from "@/lib/id-utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DELIVERY_STATUSES } from "@/lib/master-data-types"
import DatabaseModeSelector from "./database-mode-selector"

// クライアント情報のバリデーションスキーマを修正
const clientSchema = z.object({
  client_name: z.string().min(1, "企業名は必須です"),
  contact_person: z.string().min(1, "担当者名は必須です"),
  email: z.string().email("有効なメールアドレスを入力してください"),
  phone: z.string().optional(),
  delivery_status: z.string().min(1, "配信ステータスは必須です"),
})

type ClientFormValues = z.infer<typeof clientSchema>

export default function ClientFormWithMock() {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [clientId, setClientId] = useState<string | null>(null)

  // フォームの初期値を修正
  const form = useForm<ClientFormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      client_name: "",
      contact_person: "",
      email: "",
      phone: "",
      delivery_status: "pending",
    },
  })

  // onSubmit関数内のデータ送信部分を修正
  const onSubmit = async (data: ClientFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // 新しいクライアントIDを生成
      let newClientId: string

      if (mode === "local") {
        // ローカルストレージモード
        const clients = LocalStorage.getClients()
        const clientIds = clients.map((client) => client.client_id)
        newClientId = generateClientId(clientIds)

        const clientData = {
          client_id: newClientId,
          client_name: data.client_name,
          contact_person: data.contact_person,
          email: data.email,
          phone: data.phone,
          delivery_status: data.delivery_status,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        LocalStorage.saveClient(clientData)
        setClientId(newClientId)
        setSuccess(`${data.client_name}のデータ登録が完了しました。`)
      } else if (mode === "mock-api") {
        // モックAPIモード
        const response = await fetch(`/api/mock/clients/list`)
        const clientsData = await response.json()
        const clientIds = clientsData.clients.map((client: any) => client.client_id)
        newClientId = generateClientId(clientIds)

        const response2 = await fetch(`/api/mock/clients/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            client_id: newClientId,
            client_name: data.client_name,
            contact_person: data.contact_person,
            email: data.email,
            phone: data.phone,
            delivery_status: data.delivery_status,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "クライアント情報の登録に失敗しました")
        }

        const result = await response2.json()
        setClientId(newClientId)
        setSuccess(`${data.client_name}のデータ登録が完了しました。`)
      } else {
        // 実際のBigQuery APIモード
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/clients/list`)
        const clientsData = await response.json()
        const clientIds = clientsData.clients.map((client: any) => client.client_id)
        newClientId = generateClientId(clientIds)

        const response2 = await fetch(`${apiBaseUrl}/api/clients/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            client_id: newClientId,
            client_name: data.client_name,
            contact_person: data.contact_person,
            email: data.email,
            phone: data.phone,
            delivery_status: data.delivery_status,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "クライアント情報の登録に失敗しました")
        }

        const result = await response2.json()
        setClientId(newClientId)
        setSuccess(`${data.client_name}のデータ登録が完了しました。`)
      }

      form.reset()
    } catch (err: any) {
      console.error("クライアント登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>クライアント登録</CardTitle>
          <CardDescription>広告主（クライアント）の基本情報を登録します。</CardDescription>
        </div>
        <DatabaseModeSelector />
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="client_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>企業名</FormLabel>
                  <FormControl>
                    <Input placeholder="株式会社〇〇" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="contact_person"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>担当者名</FormLabel>
                  <FormControl>
                    <Input placeholder="山田 太郎" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>メールアドレス</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="example@company.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>電話番号</FormLabel>
                  <FormControl>
                    <Input placeholder="03-1234-5678" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="delivery_status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>配信ステータス</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="配信ステータスを選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {DELIVERY_STATUSES.map((status) => (
                        <SelectItem key={status.id} value={status.id}>
                          {status.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  登録中...
                </>
              ) : (
                "クライアントを登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
