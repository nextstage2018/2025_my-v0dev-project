"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar } from "lucide-react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import * as LocalStorage from "@/lib/local-storage"
import type { AdSet } from "@/lib/ad-set-types"

type AdSetDetailProps = {
  adSetId: string
}

export default function AdSetDetail({ adSetId }: AdSetDetailProps) {
  const [adSet, setAdSet] = useState<AdSet | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchAdSet = async () => {
      setIsLoading(true)
      setError(null)

      try {
        const adSetData = LocalStorage.getAdSetById(adSetId)
        console.log("AdSetDetail - adSetData from LocalStorage:", adSetData) // デバッグログ

        if (!adSetData) {
          setError("広告セットが見つかりません")
          setAdSet(null)
        } else {
          setAdSet(adSetData)
        }
      } catch (err: any) {
        console.error("広告セット取得エラー:", err)
        setError(err instanceof Error ? err.message : "広告セット情報の取得中にエラーが発生しました")
        setAdSet(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAdSet()
  }, [adSetId])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const formatDateTime = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm", { locale: ja })
    } catch (e) {
      return "日時不明"
    }
  }

  // 分を時間:分形式に変換
  const minutesToTimeString = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours.toString().padStart(2, "0")}:${mins.toString().padStart(2, "0")}`
  }

  // 曜日の表示
  const getDayName = (day: number) => {
    const days = ["", "月", "火", "水", "木", "金", "土", "日"]
    return days[day] || ""
  }

  // 課金イベントの表示
  const getBillingEventBadge = (billingEvent: string | undefined) => {
    switch (billingEvent) {
      case "IMPRESSIONS":
        return "インプレッション"
      case "CLICKS":
        return "クリック"
      case "APP_INSTALLS":
        return "アプリのインストール"
      default:
        return "不明"
    }
  }

  // 最適化目標の表示
  const getOptimizationGoalBadge = (optimizationGoal: string | undefined) => {
    switch (optimizationGoal) {
      case "REACH":
        return "リーチ"
      case "OFFSITE_CONVERSIONS":
        return "ウェブサイトコンバージョン"
      case "APP_INSTALLS":
        return "アプリのインストール"
      default:
        return "不明"
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !adSet) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error || "広告セット情報の取得に失敗しました"}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>基本情報</CardTitle>
          <CardDescription>広告セットの基本情報</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告セットID</h3>
              <p className="font-mono">{adSet.adset_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告セット名</h3>
              <p className="font-medium">{adSet.adset_name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">キャンペーンID</h3>
              <p className="font-mono">{adSet.campaign_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">キャンペーン名</h3>
              <p>{adSet.campaign_name || "不明"}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">ステータス</h3>
              <Badge variant={adSet.status === "ACTIVE" ? "default" : "secondary"}>
                {adSet.status === "ACTIVE" ? "アクティブ" : adSet.status}
              </Badge>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">作成日時</h3>
              <p>{formatDateTime(adSet.created_at)}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>予算と期間</CardTitle>
          <CardDescription>広告セットの予算と配信期間</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {adSet.daily_budget && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">日予算</h3>
                <p>{adSet.daily_budget}円</p>
              </div>
            )}
            {adSet.lifetime_budget && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">総予算</h3>
                <p>{adSet.lifetime_budget}円</p>
              </div>
            )}
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">開始日</h3>
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span>{formatDate(adSet.start_time)}</span>
              </div>
            </div>
            {adSet.end_time && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">終了日</h3>
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  <span>{formatDate(adSet.end_time)}</span>
                </div>
              </div>
            )}
            {adSet.daily_min_spend_target && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">1日あたりの最低消化金額</h3>
                <p>{adSet.daily_min_spend_target}円</p>
              </div>
            )}
            {adSet.daily_spend_cap && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">1日あたりの上限消化金額</h3>
                <p>{adSet.daily_spend_cap}円</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>入札設定</CardTitle>
          <CardDescription>広告セットの入札と最適化設定</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">課金イベント</h3>
              <Badge variant="outline">{getBillingEventBadge(adSet.billing_event)}</Badge>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">最適化目標</h3>
              <Badge variant="outline">{getOptimizationGoalBadge(adSet.optimization_goal)}</Badge>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">入札戦略</h3>
              <p>{adSet.bid_strategy}</p>
            </div>
            {adSet.bid_amount && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">入札額</h3>
                <p>{adSet.bid_amount}円</p>
              </div>
            )}
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">ペーシングタイプ</h3>
              <p>{adSet.pacing_type?.join(", ") || "STANDARD"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ターゲティング</CardTitle>
          <CardDescription>広告セットのターゲティング設定</CardDescription>
        </CardHeader>
        <CardContent>
          {adSet.targeting ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {adSet.targeting.age_min && adSet.targeting.age_max && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">年齢</h3>
                  <p>
                    {adSet.targeting.age_min} - {adSet.targeting.age_max}
                  </p>
                </div>
              )}
              {adSet.targeting.genders && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">性別</h3>
                  <p>
                    {adSet.targeting.genders.includes(1) && adSet.targeting.genders.includes(2)
                      ? "すべて"
                      : adSet.targeting.genders.includes(1)
                        ? "男性"
                        : adSet.targeting.genders.includes(2)
                          ? "女性"
                          : "指定なし"}
                  </p>
                </div>
              )}
              {adSet.targeting.geo_locations?.countries && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">国</h3>
                  <p>{adSet.targeting.geo_locations.countries.join(", ")}</p>
                </div>
              )}
              {adSet.targeting.device_platforms && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">デバイス</h3>
                  <p>{adSet.targeting.device_platforms.join(", ")}</p>
                </div>
              )}
              {adSet.targeting.publisher_platforms && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">配信先プラットフォーム</h3>
                  <p>{adSet.targeting.publisher_platforms.join(", ")}</p>
                </div>
              )}
            </div>
          ) : (
            <p className="text-muted-foreground">ターゲティング情報がありません</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
