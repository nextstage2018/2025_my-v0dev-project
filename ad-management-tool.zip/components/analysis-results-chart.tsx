"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { format, subDays } from "date-fns"
import * as LocalStorage from "@/lib/local-storage"

type ChartData = {
  date: string
  impressions?: number
  clicks?: number
  conversions?: number
  ctr?: number
  cpc?: number
  cpa?: number
}

export default function AnalysisResultsChart({ analysisId }: { analysisId: string }) {
  const { mode } = useDatabase()
  const [chartData, setChartData] = useState<ChartData[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [period, setPeriod] = useState("30d")
  const [metric, setMetric] = useState("impressions")
  const [analysis, setAnalysis] = useState<any>(null)
  const [goalProgress, setGoalProgress] = useState<number>(0)

  useEffect(() => {
    // 広告検証設定を取得
    const fetchAnalysis = async () => {
      try {
        if (mode === "local") {
          const analysisData = LocalStorage.getAnalysisById(analysisId)
          setAnalysis(analysisData)
        } else if (mode === "mock-api") {
          const response = await fetch(`/api/mock/analysis/get?analysis_id=${analysisId}`)
          if (response.ok) {
            const data = await response.json()
            setAnalysis(data.analysis)
          }
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/analysis/get?analysis_id=${analysisId}`)
          if (response.ok) {
            const data = await response.json()
            setAnalysis(data.analysis)
          }
        }
      } catch (err) {
        console.error("広告検証設定取得エラー:", err)
      }
    }

    fetchAnalysis()
  }, [analysisId, mode])

  useEffect(() => {
    const fetchPerformanceData = async () => {
      if (!analysis || !analysis.internal_ad_id) return

      setIsLoading(true)
      setError(null)

      try {
        // 期間の計算
        const endDate = new Date()
        let startDate: Date
        switch (period) {
          case "7d":
            startDate = subDays(endDate, 7)
            break
          case "14d":
            startDate = subDays(endDate, 14)
            break
          case "90d":
            startDate = subDays(endDate, 90)
            break
          case "30d":
          default:
            startDate = subDays(endDate, 30)
            break
        }

        // 日付フォーマット
        const startDateStr = format(startDate, "yyyy-MM-dd")
        const endDateStr = format(endDate, "yyyy-MM-dd")

        // APIリクエスト
        let url: string
        if (mode === "local" || mode === "mock-api") {
          url = `/api/mock/ads/performance?ad_id=${analysis.internal_ad_id}&start_date=${startDateStr}&end_date=${endDateStr}&metrics=${metric}`
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          url = `${apiBaseUrl}/api/ads/performance?ad_id=${analysis.internal_ad_id}&start_date=${startDateStr}&end_date=${endDateStr}&metrics=${metric}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("パフォーマンスデータの取得に失敗しました")
        }

        const data = await response.json()
        setChartData(data.performance || [])

        // 目標の進捗状況を計算
        if (analysis && analysis.goal_event && analysis.goal_value) {
          calculateGoalProgress(data.performance || [], analysis)
        }
      } catch (err: any) {
        console.error("パフォーマンスデータ取得エラー:", err)
        setError(err instanceof Error ? err.message : "パフォーマンスデータの取得中にエラーが発生しました")
      } finally {
        setIsLoading(false)
      }
    }

    fetchPerformanceData()
  }, [analysis, period, metric, mode])

  const calculateGoalProgress = (performanceData: ChartData[], analysisData: any) => {
    if (!performanceData || performanceData.length === 0) {
      setGoalProgress(0)
      return
    }

    // 目標イベントに基づいて適切な指標を選択
    let metricKey: keyof ChartData
    switch (analysisData.goal_event) {
      case "商品購入":
      case "資料請求":
      case "会員登録":
      case "アプリインストール":
        metricKey = "conversions"
        break
      case "サイト訪問":
        metricKey = "clicks"
        break
      case "動画視聴":
      case "エンゲージメント":
        metricKey = "impressions"
        break
      default:
        metricKey = "conversions"
    }

    // 合計値を計算
    const totalValue = performanceData.reduce((sum, day) => {
      return sum + ((day[metricKey] as number) || 0)
    }, 0)

    // 目標値に対する進捗率を計算（最大100%）
    const progress = Math.min((totalValue / analysisData.goal_value) * 100, 100)
    setGoalProgress(progress)
  }

  const getMetricLabel = (metricKey: string) => {
    switch (metricKey) {
      case "impressions":
        return "インプレッション"
      case "clicks":
        return "クリック"
      case "conversions":
        return "コンバージョン"
      case "ctr":
        return "クリック率 (CTR)"
      case "cpc":
        return "クリック単価 (CPC)"
      case "cpa":
        return "獲得単価 (CPA)"
      default:
        return metricKey
    }
  }

  const formatValue = (value: number | undefined, metricKey: string) => {
    if (value === undefined) return "-"
    switch (metricKey) {
      case "ctr":
        return `${(value * 100).toFixed(2)}%`
      case "cpc":
      case "cpa":
        return `${value.toFixed(2)}円`
      default:
        return value.toLocaleString()
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!analysis) {
    return (
      <Alert variant="destructive">
        <AlertDescription>広告検証設定が見つかりません</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <h3 className="text-sm font-medium mb-2">目標イベント</h3>
          <p className="text-lg font-semibold">{analysis.goal_event}</p>
        </div>
        <div>
          <h3 className="text-sm font-medium mb-2">目標値</h3>
          <p className="text-lg font-semibold">{analysis.goal_value}</p>
        </div>
        <div>
          <h3 className="text-sm font-medium mb-2">進捗状況</h3>
          <div className="flex items-center gap-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${goalProgress}%` }}></div>
            </div>
            <span className="text-sm font-medium">{Math.round(goalProgress)}%</span>
          </div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="w-full sm:w-48">
          <label className="block text-sm font-medium mb-1">期間</label>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger>
              <SelectValue placeholder="期間を選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">過去7日間</SelectItem>
              <SelectItem value="14d">過去14日間</SelectItem>
              <SelectItem value="30d">過去30日間</SelectItem>
              <SelectItem value="90d">過去90日間</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="w-full sm:w-48">
          <label className="block text-sm font-medium mb-1">指標</label>
          <Select value={metric} onValueChange={setMetric}>
            <SelectTrigger>
              <SelectValue placeholder="指標を選択" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="impressions">インプレッション</SelectItem>
              <SelectItem value="clicks">クリック</SelectItem>
              <SelectItem value="conversions">コンバージョン</SelectItem>
              <SelectItem value="ctr">クリック率 (CTR)</SelectItem>
              <SelectItem value="cpc">クリック単価 (CPC)</SelectItem>
              <SelectItem value="cpa">獲得単価 (CPA)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {chartData.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">選択した期間のパフォーマンスデータがありません。</div>
      ) : (
        <Card>
          <CardContent className="pt-6">
            <div className="h-[300px] relative">
              {/* チャートの実装 */}
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-muted-foreground">
                  チャートライブラリが必要です。実際の実装では、Chart.js や Recharts
                  などのライブラリを使用してください。
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {chartData.length > 0 && (
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2 px-4">日付</th>
                <th className="text-right py-2 px-4">{getMetricLabel(metric)}</th>
              </tr>
            </thead>
            <tbody>
              {chartData.map((day) => (
                <tr key={day.date} className="border-b hover:bg-gray-50">
                  <td className="py-2 px-4">{format(new Date(day.date), "yyyy/MM/dd")}</td>
                  <td className="text-right py-2 px-4">
                    {formatValue(day[metric as keyof ChartData] as number, metric)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
