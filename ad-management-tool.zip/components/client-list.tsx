"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import DatabaseModeSelector from "./database-mode-selector"

type Client = {
  client_id: string
  client_name: string
  contact_person: string
  email: string
  phone?: string
  created_at: string
  updated_at: string
}

export default function ClientList() {
  const { mode } = useDatabase()
  const [clients, setClients] = useState<Client[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchClients = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージからクライアント一覧を取得
        const localClients = LocalStorage.getClients()
        setClients(localClients)
      } else if (mode === "mock-api") {
        // モックAPIからクライアント一覧を取得
        const response = await fetch(`/api/mock/clients/list`)

        if (!response.ok) {
          throw new Error("クライアント情報の取得に失敗しました")
        }

        const data = await response.json()
        setClients(data.clients || [])
      } else {
        // 実際のBigQuery APIからクライアント一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/clients/list`)

        if (!response.ok) {
          throw new Error("クライアント情報の取得に失敗しました")
        }

        const data = await response.json()
        setClients(data.clients || [])
      }
    } catch (err: any) {
      console.error("クライアント取得エラー:", err)
      setError(err instanceof Error ? err.message : "クライアント情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchClients()
  }, [mode])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const handleDelete = async (clientId: string) => {
    if (confirm("本当に削除しますか？")) {
      LocalStorage.deleteClient(clientId)
      fetchClients() // リストを更新
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>クライアント一覧</CardTitle>
          <CardDescription>登録されているクライアント情報の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/database">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchClients} variant="outline" size="icon">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : clients.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            クライアント情報がありません。新しいクライアントを登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>クライアントID</TableHead>
                  <TableHead>企業名</TableHead>
                  <TableHead>担当者名</TableHead>
                  <TableHead>メールアドレス</TableHead>
                  <TableHead>登録日</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((client) => (
                  <TableRow key={client.client_id}>
                    <TableCell className="font-mono">{client.client_id}</TableCell>
                    <TableCell className="font-medium">{client.client_name}</TableCell>
                    <TableCell>{client.contact_person}</TableCell>
                    <TableCell>{client.email}</TableCell>
                    <TableCell>{client.created_at ? formatDate(client.created_at) : "日付不明"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/database/clients/${client.client_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/database/clients/${client.client_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(client.client_id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                          <span className="sr-only">削除</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
