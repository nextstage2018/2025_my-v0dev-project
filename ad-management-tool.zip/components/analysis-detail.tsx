"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar, Target, Lightbulb, MessageSquare, Layout, Goal } from "lucide-react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import * as LocalStorage from "@/lib/local-storage"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useDatabase } from "@/contexts/database-context"
import AnalysisResultsChart from "./analysis-results-chart"

export default function AnalysisDetail({ analysisId }: { analysisId: string }) {
  const { mode } = useDatabase()
  const [analysis, setAnalysis] = useState<LocalStorage.Analysis | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [project, setProject] = useState<LocalStorage.Project | null>(null)
  const [campaign, setCampaign] = useState<LocalStorage.Campaign | null>(null)
  const [adSet, setAdSet] = useState<LocalStorage.AdSet | null>(null)

  // 広告検証設定が見つからない場合のエラーハンドリングを修正
  useEffect(() => {
    const fetchAnalysis = async () => {
      setIsLoading(true)
      setError(null)

      try {
        let analysisData

        if (mode === "local") {
          analysisData = LocalStorage.getAnalysisById(analysisId)
        } else if (mode === "mock-api") {
          const response = await fetch(`/api/mock/analysis/get?analysis_id=${analysisId}`)
          if (response.ok) {
            const data = await response.json()
            analysisData = data.analysis
          }
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/analysis/get?analysis_id=${analysisId}`)
          if (response.ok) {
            const data = await response.json()
            analysisData = data.analysis
          }
        }

        if (!analysisData) {
          setError("広告検証設定が見つかりません")
          setAnalysis(null)
        } else {
          setAnalysis(analysisData)

          // 関連データの取得
          if (mode === "local") {
            const projectData = LocalStorage.getProjectById(analysisData.internal_project_id)
            setProject(projectData || null)

            const campaignData = LocalStorage.getCampaignById(analysisData.internal_campaign_id)
            setCampaign(campaignData || null)

            const adSetData = LocalStorage.getAdSetById(analysisData.internal_adset_id)
            setAdSet(adSetData || null)
          }
        }
      } catch (err: any) {
        console.error("広告検証設定取得エラー:", err)
        setError(err instanceof Error ? err.message : "広告検証設定情報の取得中にエラーが発生しました")
        setAnalysis(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAnalysis()
  }, [analysisId, mode])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const formatDateTime = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm", { locale: ja })
    } catch (e) {
      return "日時不明"
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !analysis) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error || "広告検証設定情報の取得に失敗しました"}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="details">
        <TabsList className="mb-4">
          <TabsTrigger value="details">基本情報</TabsTrigger>
          <TabsTrigger value="creative">クリエイティブ分析</TabsTrigger>
          <TabsTrigger value="results">検証結果</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>基本情報</CardTitle>
              <CardDescription>広告検証設定の基本情報</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">検証ID</h3>
                  <p className="font-mono">{analysis.analysis_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">アカウントID</h3>
                  <p className="font-mono">{analysis.account_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">プロジェクト</h3>
                  <p>{project?.project_name || analysis.internal_project_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">キャンペーン</h3>
                  <p>{campaign?.campaign_name || analysis.internal_campaign_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">広告セット</h3>
                  <p>{adSet?.adset_name || analysis.internal_adset_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">広告ID</h3>
                  <p className="font-mono">{analysis.internal_ad_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">クリエイティブアイテムID</h3>
                  <p className="font-mono">{analysis.creative_item_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">分析日</h3>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3 text-muted-foreground" />
                    <span>{formatDate(analysis.analysis_date)}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">作成日時</h3>
                  <p>{formatDateTime(analysis.created_at)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">更新日時</h3>
                  <p>{formatDateTime(analysis.updated_at)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>検証設定</CardTitle>
              <CardDescription>広告検証の設定内容</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4">
                <div className="flex items-start gap-3">
                  <Target className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium">訴求対象者</h3>
                    <p className="mt-1">{analysis.appeal_target}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Lightbulb className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium">強調テーマ</h3>
                    <p className="mt-1">{analysis.emphasis_theme}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MessageSquare className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium">訴求コンテンツ</h3>
                    <p className="mt-1">{analysis.appeal_content}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Layout className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium">デザイン構成</h3>
                    <p className="mt-1">{analysis.design_structure}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>目標設定</CardTitle>
              <CardDescription>広告検証の目標</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-start gap-3">
                  <Goal className="h-5 w-5 text-muted-foreground mt-0.5" />
                  <div>
                    <h3 className="text-sm font-medium">目標イベント</h3>
                    <p className="mt-1">{analysis.goal_event}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium">目標値</h3>
                  <p className="text-xl font-bold mt-1">{analysis.goal_value}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium">ターゲット日付</h3>
                  <div className="flex items-center gap-1 mt-1">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{formatDate(analysis.target_date)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="creative" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>クリエイティブ分析</CardTitle>
              <CardDescription>広告クリエイティブの分析情報</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-3">訴求ポイント分析</h3>
                  <div className="grid grid-cols-1 gap-6">{/* Add your content here */}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>検証結果</CardTitle>
              <CardDescription>広告検証の結果</CardDescription>
            </CardHeader>
            <CardContent>
              <AnalysisResultsChart analysisId={analysisId} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
