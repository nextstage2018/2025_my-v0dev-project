"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import { Button } from "@/components/ui/button"
import { Check, ChevronDown, User } from "lucide-react"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

type AdAccount = {
  id: string
  name: string
  businessName: string
  accessLevel: "ADMIN" | "OPERATOR" | "VIEWER"
}

type AdAccountSelectorProps = {
  onAccountSelect: (accountId: string | null) => void
}

export default function AdAccountSelector({ onAccountSelect }: AdAccountSelectorProps) {
  const { mode } = useDatabase()
  const [open, setOpen] = useState(false)
  const [accounts, setAccounts] = useState<AdAccount[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [selectedAccount, setSelectedAccount] = useState<AdAccount | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  // アカウント一覧を取得
  useEffect(() => {
    const fetchAccounts = async () => {
      setIsLoading(true)
      try {
        // 実際の実装ではAPIから取得する
        // モックデータを使用
        const mockAccounts: AdAccount[] = [
          { id: "act_123456789", name: "メインアカウント", businessName: "株式会社サンプル", accessLevel: "ADMIN" },
          { id: "act_234567890", name: "テストアカウント", businessName: "株式会社サンプル", accessLevel: "ADMIN" },
          { id: "act_345678901", name: "クライアントA", businessName: "株式会社A", accessLevel: "OPERATOR" },
          { id: "act_456789012", name: "クライアントB", businessName: "株式会社B", accessLevel: "VIEWER" },
          { id: "act_567890123", name: "クライアントC", businessName: "株式会社C", accessLevel: "OPERATOR" },
        ]
        setAccounts(mockAccounts)

        // 最初のアカウントを自動選択
        if (mockAccounts.length > 0) {
          setSelectedAccount(mockAccounts[0])
          onAccountSelect(mockAccounts[0].id)
        }
      } catch (error) {
        console.error("アカウント取得エラー:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAccounts()
  }, [mode, onAccountSelect])

  // 検索フィルタリング
  const filteredAccounts = accounts.filter(
    (account) =>
      account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      account.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // アカウント選択時の処理
  const handleSelectAccount = (account: AdAccount) => {
    setSelectedAccount(account)
    onAccountSelect(account.id)
    setOpen(false)
  }

  // アクセスレベルに応じたバッジを表示
  const getAccessLevelBadge = (level: string) => {
    switch (level) {
      case "ADMIN":
        return <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">管理者</span>
      case "OPERATOR":
        return <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">運用者</span>
      case "VIEWER":
        return <span className="text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded">閲覧者</span>
      default:
        return null
    }
  }

  return (
    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <User className="h-5 w-5 text-muted-foreground" />
        <span className="text-sm font-medium">広告アカウント:</span>
      </div>

      <div className="flex-1 max-w-md">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" role="combobox" aria-expanded={open} className="w-full justify-between">
              {selectedAccount ? (
                <div className="flex flex-col items-start">
                  <span className="font-medium">{selectedAccount.name}</span>
                  <span className="text-xs text-muted-foreground">
                    {selectedAccount.id} • {selectedAccount.businessName}
                  </span>
                </div>
              ) : (
                "アカウントを選択"
              )}
              <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[400px] p-0">
            <Command>
              <CommandInput
                placeholder="アカウント名、ID、企業名で検索..."
                value={searchTerm}
                onValueChange={setSearchTerm}
              />
              <CommandList>
                <CommandEmpty>アカウントが見つかりません</CommandEmpty>
                <CommandGroup>
                  {filteredAccounts.map((account) => (
                    <CommandItem
                      key={account.id}
                      value={account.id}
                      onSelect={() => handleSelectAccount(account)}
                      className="flex flex-col items-start py-3"
                    >
                      <div className="flex w-full justify-between items-center">
                        <span className="font-medium">{account.name}</span>
                        {getAccessLevelBadge(account.accessLevel)}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {account.id} • {account.businessName}
                      </span>
                      {selectedAccount?.id === account.id && <Check className="ml-auto h-4 w-4" />}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </CommandList>
            </Command>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )
}
