"use client"

import { useState } from "react"
import { useDatabase } from "@/contexts/database-context"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"
import { Textarea } from "@/components/ui/textarea"

export default function AdStatusUpdate({ adId, currentStatus }: { adId: string; currentStatus: string }) {
  const { mode } = useDatabase()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [reason, setReason] = useState("")
  const [showReason, setShowReason] = useState(false)
  const [targetStatus, setTargetStatus] = useState<string | null>(null)

  const updateStatus = async (status: string) => {
    if (status === currentStatus) {
      setError(`広告は既に${getStatusLabel(status)}状態です`)
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      let url: string
      if (mode === "local" || mode === "mock-api") {
        url = `/api/mock/ads/update-status`
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        url = `${apiBaseUrl}/api/ads/update-status`
      }

      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ad_id: adId,
          status,
          reason: reason || undefined,
          user_id: "usr00001", // 実際の実装では認証済みユーザーIDを使用
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "ステータス更新に失敗しました")
      }

      const result = await response.json()
      setSuccess(`広告のステータスを${getStatusLabel(status)}に変更しました`)
      setReason("")
      setShowReason(false)
      setTargetStatus(null)

      // 少し待ってからページを更新
      setTimeout(() => {
        router.refresh()
      }, 1500)
    } catch (err: any) {
      console.error("ステータス更新エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  const handleStatusChange = (status: string) => {
    setTargetStatus(status)
    // 一時停止または削除の場合は理由入力を表示
    if (status === "PAUSED" || status === "DELETED") {
      setShowReason(true)
    } else {
      setShowReason(false)
      updateStatus(status)
    }
  }

  const handleReasonSubmit = () => {
    if (targetStatus) {
      updateStatus(targetStatus)
    }
  }

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "アクティブ"
      case "PAUSED":
        return "一時停止"
      case "COMPLETED":
        return "完了"
      case "DELETED":
        return "削除済み"
      default:
        return status
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>ステータス変更</CardTitle>
        <CardDescription>広告のステータスを変更します</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <XCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 border-green-500 text-green-700 mb-4">
            <CheckCircle className="h-4 w-4 mr-2" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {showReason ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">
                {targetStatus === "PAUSED" ? "一時停止" : "削除"}の理由
              </label>
              <Textarea
                placeholder={`${targetStatus === "PAUSED" ? "一時停止" : "削除"}の理由を入力してください`}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="min-h-[100px]"
              />
            </div>
            <div className="flex gap-2">
              <Button variant="default" onClick={handleReasonSubmit} disabled={isLoading}>
                {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                確定
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowReason(false)
                  setTargetStatus(null)
                }}
                disabled={isLoading}
              >
                キャンセル
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {currentStatus !== "ACTIVE" && (
              <Button variant="default" onClick={() => handleStatusChange("ACTIVE")} disabled={isLoading}>
                {isLoading && targetStatus === "ACTIVE" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                アクティブにする
              </Button>
            )}
            {currentStatus !== "PAUSED" && (
              <Button variant="secondary" onClick={() => handleStatusChange("PAUSED")} disabled={isLoading}>
                {isLoading && targetStatus === "PAUSED" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                一時停止する
              </Button>
            )}
            {currentStatus !== "COMPLETED" && (
              <Button variant="outline" onClick={() => handleStatusChange("COMPLETED")} disabled={isLoading}>
                {isLoading && targetStatus === "COMPLETED" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                完了にする
              </Button>
            )}
            {currentStatus !== "DELETED" && (
              <Button variant="destructive" onClick={() => handleStatusChange("DELETED")} disabled={isLoading}>
                {isLoading && targetStatus === "DELETED" && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                削除する
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
