"\"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import * as LocalStorage from "@/lib/local-storage"
import AdStatusUpdate from "@/components/ad-status-update"
import AdPerformanceChart from "@/components/ad-performance-chart"

type Ad = {
  ad_id: string
  ad_name: string
  campaign_id: string
  adset_id: string
  creative_id: string
  status: string
  created_at: string
  updated_at: string
}

type Targeting = {
  targeting_id: string
  ad_id: string
  age_min: number
  age_max: number
  genders: number[]
  geo_locations: {
    countries: string[]
  }
}

type Creative = {
  creative_id: string
  creative_name: string
  creative_type: string
  creative_url: string
  creative_text: string
}

export default function AdDetail({ adId }: { adId: string }) {
  const { mode } = useDatabase()
  const [ad, setAd] = useState<Ad | null>(null)
  const [targeting, setTargeting] = useState<Targeting | null>(null)
  const [creative, setCreative] = useState<Creative | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchAd = async () => {
      setIsLoading(true)
      setError(null)

      try {
        let adData: any = null
        let targetingData: any = null
        let creativeData: any = null

        if (mode === "local") {
          const localAd = LocalStorage.getAdById(adId)
          if (localAd) {
            adData = localAd
          }
        } else if (mode === "mock-api") {
          const response = await fetch(`/api/mock/ads/get?ad_id=${adId}`)
          if (response.ok) {
            const data = await response.json()
            adData = data.ad
            targetingData = data.targeting
          }
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/ads/get?ad_id=${adId}`)
          if (response.ok) {
            const data = await response.json()
            adData = data.ad
            targetingData = data.targeting
            creativeData = data.creative
          }
        }

        if (!adData) {
          setError("広告が見つかりません")
          setAd(null)
        } else {
          setAd(adData)
          setTargeting(targetingData)
          setCreative(creativeData)
        }
      } catch (err: any) {
        console.error("広告取得エラー:", err)
        setError(err instanceof Error ? err.message : "広告情報の取得中にエラーが発生しました")
        setAd(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchAd()
  }, [adId, mode])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !ad) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error || "広告情報の取得に失敗しました"}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>広告基本情報</CardTitle>
          <CardDescription>広告の基本情報</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告ID</h3>
              <p className="font-mono">{ad.ad_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告名</h3>
              <p className="font-medium">{ad.ad_name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">キャンペーンID</h3>
              <p className="font-mono">{ad.campaign_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告セットID</h3>
              <p className="font-mono">{ad.adset_id}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {creative && (
        <Card>
          <CardHeader>
            <CardTitle>クリエイティブ情報</CardTitle>
            <CardDescription>広告のクリエイティブ情報</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">クリエイティブ名</h3>
                <p>{creative.creative_name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">クリエイティブタイプ</h3>
                <p>{creative.creative_type}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">クリエイティブURL</h3>
                <p>{creative.creative_url}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">クリエイティブテキスト</h3>
                <p>{creative.creative_text}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {targeting && (
        <Card>
          <CardHeader>
            <CardTitle>ターゲティング情報</CardTitle>
            <CardDescription>広告のターゲティング情報</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">年齢</h3>
                <p>
                  {targeting.age_min} - {targeting.age_max}
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">性別</h3>
                <p>{targeting.genders?.join(", ") || "指定なし"}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">国</h3>
                <p>{targeting.geo_locations?.countries?.join(", ") || "指定なし"}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <AdStatusUpdate adId={adId} currentStatus={ad.status} />
      <AdPerformanceChart adId={adId} />
    </div>
  )
}
