"use client"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"

type CreateHierarchyButtonProps = {
  accountId: string | null
}

export default function CreateHierarchyButton({ accountId }: CreateHierarchyButtonProps) {
  const router = useRouter()

  const handleCreate = (type: "campaign" | "adset" | "ad") => {
    // アカウントIDが選択されていない場合は処理しない
    if (!accountId) {
      alert("広告アカウントを選択してください")
      return
    }

    // 選択した階層に応じて遷移先を変更
    switch (type) {
      case "campaign":
        router.push(`/ads/campaigns/new?account_id=${accountId}`)
        break
      case "adset":
        router.push(`/ads/ad-sets/new?account_id=${accountId}`)
        break
      case "ad":
        router.push(`/ads/ads/new?account_id=${accountId}`)
        break
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          新規作成
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start">
        <DropdownMenuItem onClick={() => handleCreate("campaign")}>キャンペーン作成</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleCreate("adset")}>広告セット作成</DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleCreate("ad")}>広告作成</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
