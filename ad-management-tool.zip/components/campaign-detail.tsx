"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar } from "lucide-react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import * as LocalStorage from "@/lib/local-storage"

type Campaign = {
  campaign_id: string
  project_id: string
  campaign_name: string
  objective: "awareness" | "consideration" | "conversion"
  status: "draft" | "active" | "paused" | "completed"
  start_date: string
  end_date?: string
  daily_budget?: string
  total_budget?: string
  description?: string
  created_at: string
  updated_at: string
}

export default function CampaignDetail({ campaignId }: { campaignId: string }) {
  const [campaign, setCampaign] = useState<Campaign | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchCampaign = async () => {
      setIsLoading(true)
      setError(null)

      try {
        const campaignData = LocalStorage.getCampaignById(campaignId)
        if (!campaignData) {
          setError("キャンペーンが見つかりません")
          setCampaign(null)
        } else {
          setCampaign(campaignData)
        }
      } catch (err: any) {
        console.error("キャンペーン取得エラー:", err)
        setError(err instanceof Error ? err.message : "キャンペーン情報の取得中にエラーが発生しました")
        setCampaign(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchCampaign()
  }, [campaignId])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !campaign) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error || "キャンペーン情報の取得に失敗しました"}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>キャンペーン基本情報</CardTitle>
          <CardDescription>キャンペーンの基本情報</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">キャンペーンID</h3>
              <p className="font-mono">{campaign.campaign_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">キャンペーン名</h3>
              <p className="font-medium">{campaign.campaign_name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">プロジェクトID</h3>
              <p className="font-mono">{campaign.project_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">広告目的</h3>
              <p>{campaign.objective}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">ステータス</h3>
              <p>{campaign.status}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">開始日</h3>
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span>{formatDate(campaign.start_date)}</span>
              </div>
            </div>
            {campaign.end_date && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">終了日</h3>
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  <span>{formatDate(campaign.end_date)}</span>
                </div>
              </div>
            )}
            {campaign.daily_budget && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">日予算</h3>
                <p>{campaign.daily_budget}</p>
              </div>
            )}
            {campaign.total_budget && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">総予算</h3>
                <p>{campaign.total_budget}</p>
              </div>
            )}
            {campaign.description && (
              <div className="col-span-2">
                <h3 className="text-sm font-medium text-muted-foreground">説明</h3>
                <p>{campaign.description}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
