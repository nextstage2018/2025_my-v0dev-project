"use client"

import { useEffect } from "react"
import { INDUSTRY_CATEGORIES, MEDIA_TYPES } from "@/lib/master-data-types"
import { initializeMasterData } from "@/lib/master-storage"

export function MasterDataInitializer() {
  useEffect(() => {
    // マスタデータの初期化
    initializeMasterData(INDUSTRY_CATEGORIES, MEDIA_TYPES)
  }, [])

  return null
}
