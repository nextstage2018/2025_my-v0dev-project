"use client"

import { useDatabase } from "@/contexts/database-context"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Database, HardDrive, Server } from "lucide-react"

export default function DatabaseModeSelector() {
  const { mode, setMode } = useDatabase()

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          {mode === "local" && <HardDrive className="h-4 w-4" />}
          {mode === "api" && <Server className="h-4 w-4" />}
          {mode === "mock-api" && <Database className="h-4 w-4" />}
          <span>
            {mode === "local" && "ローカルストレージ"}
            {mode === "api" && "BigQuery API"}
            {mode === "mock-api" && "モックAPI"}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => setMode("local")} className="flex items-center gap-2">
          <HardDrive className="h-4 w-4" />
          <span>ローカルストレージ</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setMode("api")} className="flex items-center gap-2">
          <Server className="h-4 w-4" />
          <span>BigQuery API</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setMode("mock-api")} className="flex items-center gap-2">
          <Database className="h-4 w-4" />
          <span>モックAPI</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
