"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/ui/date-picker"

// プロジェクト情報のバリデーションスキーマ
const projectSchema = z.object({
  client_id: z.string().min(1, "クライアントの選択は必須です"),
  project_name: z.string().min(1, "プロジェクト名は必須です"),
  description: z.string().optional(),
  start_date: z.date({
    required_error: "開始日は必須です",
  }),
  end_date: z
    .date({
      required_error: "終了日は必須です",
    })
    .optional(),
  budget: z.string().optional(),
  team_members: z.string().optional(),
  goals: z.string().optional(),
  status: z.enum(["planning", "active", "paused", "completed"]),
})

type ProjectFormValues = z.infer<typeof projectSchema>

type Client = {
  client_id: string
  client_name: string
}

export default function ProjectForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [projectId, setProjectId] = useState<string | null>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [isLoadingClients, setIsLoadingClients] = useState(false)

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      client_id: "",
      project_name: "",
      description: "",
      budget: "",
      team_members: "",
      goals: "",
      status: "planning",
    },
  })

  // クライアント一覧を取得
  useEffect(() => {
    const fetchClients = async () => {
      setIsLoadingClients(true)
      try {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/clients/list`)

        if (!response.ok) {
          throw new Error("クライアント情報の取得に失敗しました")
        }

        const data = await response.json()
        setClients(data.clients || [])
      } catch (err) {
        console.error("クライアント取得エラー:", err)
        setError(err instanceof Error ? err.message : "クライアント情報の取得中にエラーが発生しました")
      } finally {
        setIsLoadingClients(false)
      }
    }

    fetchClients()
  }, [])

  const onSubmit = async (data: ProjectFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const selectedClient = clients.find((client) => client.client_id === data.client_id)
      if (!selectedClient) {
        throw new Error("選択されたクライアントが見つかりません")
      }

      // 新しいプロジェクトIDを生成（実際の実装ではサーバーサイドで行うべき）
      const projectNumber = String(Math.floor(Math.random() * 100000)).padStart(5, "0")
      const newProjectId = `${data.client_id}_pr${projectNumber}`

      // APIリクエストの準備
      const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""

      // BigQueryにデータを登録するリクエスト
      const response = await fetch(`${apiBaseUrl}/api/projects/create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          project_id: newProjectId,
          ...data,
          start_date: data.start_date.toISOString(),
          end_date: data.end_date ? data.end_date.toISOString() : null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "プロジェクト情報の登録に失敗しました")
      }

      const result = await response.json()
      setProjectId(newProjectId)
      setSuccess(`プロジェクト「${data.project_name}」を登録しました。プロジェクトID: ${newProjectId}`)
      form.reset()
    } catch (err) {
      console.error("プロジェクト登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>プロジェクト登録</CardTitle>
        <CardDescription>広告運用プロジェクトの基本情報を登録します。</CardDescription>
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert>
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="client_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>クライアント</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isLoadingClients}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="クライアントを選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {clients.map((client) => (
                        <SelectItem key={client.client_id} value={client.client_id}>
                          {client.client_name} ({client.client_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="project_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>プロジェクト名</FormLabel>
                  <FormControl>
                    <Input placeholder="2025年春キャンペーン" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>プロジェクト概要</FormLabel>
                  <FormControl>
                    <Textarea placeholder="プロジェクトの目的や概要" className="min-h-[100px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="start_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>開始日</FormLabel>
                    <DatePicker date={field.value} setDate={field.onChange} />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="end_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>終了日（任意）</FormLabel>
                    <DatePicker date={field.value} setDate={field.onChange} />
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>予算</FormLabel>
                  <FormControl>
                    <Input placeholder="1,000,000円" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="team_members"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>チームメンバー</FormLabel>
                  <FormControl>
                    <Textarea placeholder="担当者名、役割など" className="min-h-[80px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="goals"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>目標</FormLabel>
                  <FormControl>
                    <Textarea placeholder="KPI、達成目標など" className="min-h-[80px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ステータス</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="ステータスを選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="planning">計画中</SelectItem>
                      <SelectItem value="active">実行中</SelectItem>
                      <SelectItem value="paused">一時停止</SelectItem>
                      <SelectItem value="completed">完了</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  登録中...
                </>
              ) : (
                "プロジェクトを登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
