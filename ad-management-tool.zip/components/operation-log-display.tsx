"use client"

import { Table, TableBody, TableHead, TableRow, TableCell, TableHeader } from "@/components/ui/table"
import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar } from "lucide-react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import * as LocalStorage from "@/lib/local-storage"

type OperationLog = {
  operation_id: string
  operation_type: string
  operation_status: string
  operation_message?: string
  executed_by?: string
  operation_timestamp: string
  error_code?: string
  error_details?: string
  additional_info?: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
}

type OperationLogDisplayProps = {
  adId: string
}

export default function OperationLogDisplay({ adId }: OperationLogDisplayProps) {
  const { mode } = useDatabase()
  const [logs, setLogs] = useState<OperationLog[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchLogs = async () => {
      setIsLoading(true)
      setError(null)

      try {
        let filteredLogs: OperationLog[] = []
        if (mode === "local") {
          // ローカルストレージから運用ログ一覧を取得
          const localLogs = LocalStorage.getOperationLogs()
          filteredLogs = localLogs.filter((log) => log.ad_id === adId)
        } else if (mode === "mock-api") {
          // モックAPIから運用ログ一覧を取得
          const response = await fetch(`/api/mock/operation-logs/list`)

          if (!response.ok) {
            throw new Error("運用ログ情報の取得に失敗しました")
          }

          const data = await response.json()
          filteredLogs = data.logs ? data.logs.filter((log: OperationLog) => log.ad_id === adId) : []
        } else {
          // 実際のBigQuery APIから運用ログ一覧を取得
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/operation-logs/list`)

          if (!response.ok) {
            throw new Error("運用ログ情報の取得に失敗しました")
          }

          const data = await response.json()
          filteredLogs = data.logs ? data.logs.filter((log: OperationLog) => log.ad_id === adId) : []
        }

        setLogs(filteredLogs)
      } catch (err: any) {
        console.error("運用ログ取得エラー:", err)
        setError(err instanceof Error ? err.message : "運用ログ情報の取得中にエラーが発生しました")
      } finally {
        setIsLoading(false)
      }
    }

    fetchLogs()
  }, [adId, mode])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm:ss", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "success":
      case "completed":
        return (
          <Badge variant="default" className="bg-green-500">
            成功
          </Badge>
        )
      case "failed":
      case "error":
        return <Badge variant="destructive">失敗</Badge>
      case "pending":
        return <Badge variant="secondary">処理中</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-700">
            警告
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>運用ログ</CardTitle>
        <CardDescription>広告の操作履歴</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">運用ログはありません。</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>操作日時</TableHead>
                  <TableHead>操作タイプ</TableHead>
                  <TableHead>ステータス</TableHead>
                  <TableHead>メッセージ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.operation_id}>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(log.operation_timestamp)}</span>
                      </div>
                    </TableCell>
                    <TableCell>{log.operation_type}</TableCell>
                    <TableCell>{getStatusBadge(log.operation_status)}</TableCell>
                    <TableCell className="max-w-xs truncate">{log.operation_message || "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
