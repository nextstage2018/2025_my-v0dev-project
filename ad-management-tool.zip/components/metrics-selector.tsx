"use client"
import { Button } from "@/components/ui/button"
import { BarChart3 } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

type MetricOption = {
  id: string
  name: string
}

type MetricsSelectorProps = {
  selectedMetrics: string[]
  onMetricsChange: (metrics: string[]) => void
}

export default function MetricsSelector({ selectedMetrics, onMetricsChange }: MetricsSelectorProps) {
  // 利用可能な指標一覧
  const availableMetrics: MetricOption[] = [
    { id: "impressions", name: "インプレッション" },
    { id: "clicks", name: "クリック" },
    { id: "conversions", name: "コンバージョン" },
    { id: "ctr", name: "クリック率 (CTR)" },
    { id: "cpc", name: "クリック単価 (CPC)" },
    { id: "cpa", name: "獲得単価 (CPA)" },
    { id: "spend", name: "支出" },
    { id: "reach", name: "リーチ" },
    { id: "frequency", name: "頻度" },
  ]

  // 指標の選択状態を切り替える
  const toggleMetric = (metricId: string) => {
    if (selectedMetrics.includes(metricId)) {
      // 最低1つは選択されている必要がある
      if (selectedMetrics.length > 1) {
        onMetricsChange(selectedMetrics.filter((id) => id !== metricId))
      }
    } else {
      onMetricsChange([...selectedMetrics, metricId])
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline">
          <BarChart3 className="h-4 w-4 mr-2" />
          パフォーマンス指標
          <span className="ml-1 text-xs bg-gray-100 text-gray-800 px-1.5 py-0.5 rounded-full">
            {selectedMetrics.length}
          </span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>表示する指標を選択</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {availableMetrics.map((metric) => (
          <DropdownMenuCheckboxItem
            key={metric.id}
            checked={selectedMetrics.includes(metric.id)}
            onCheckedChange={() => toggleMetric(metric.id)}
          >
            {metric.name}
          </DropdownMenuCheckboxItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
