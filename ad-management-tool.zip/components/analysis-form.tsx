"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/ui/date-picker"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import DatabaseModeSelector from "./database-mode-selector"

// 広告検証設定のバリデーションスキーマ
const analysisSchema = z.object({
  account_id: z.string().min(1, "アカウントIDは必須です"),
  internal_project_id: z.string().min(1, "プロジェクトIDは必須です"),
  internal_campaign_id: z.string().min(1, "キャンペーンIDは必須です"),
  internal_adset_id: z.string().min(1, "広告セットIDは必須です"),
  internal_ad_id: z.string().min(1, "広告IDは必須です"),
  creative_item_id: z.string().min(1, "クリエイティブIDは必須です"),
  appeal_target: z.string().min(1, "訴求対象者は必須です"),
  emphasis_theme: z.string().min(1, "強調テーマは必須です"),
  appeal_content: z.string().min(1, "訴求コンテンツは必須です"),
  design_structure: z.string().min(1, "デザイン構成は必須です"),
  target_date: z.date({
    required_error: "目標日は必須です",
  }),
  goal_event: z.string().min(1, "目標イベントは必須です"),
  goal_value: z.string().min(1, "目標値は必須です"),
})

type AnalysisFormValues = z.infer<typeof analysisSchema>

type Project = {
  project_id: string
  project_name: string
}

type Campaign = {
  campaign_id: string
  campaign_name: string
  project_id: string
}

type AdSet = {
  adset_id: string
  adset_name: string
  campaign_id: string
}

export default function AnalysisForm({ analysisId }: { analysisId?: string }) {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [adSets, setAdSets] = useState<AdSet[]>([])
  const [ads, setAds] = useState<any[]>([])
  const [creatives, setCreatives] = useState<any[]>([])
  const [isEditing, setIsEditing] = useState(false)

  const form = useForm<AnalysisFormValues>({
    resolver: zodResolver(analysisSchema),
    defaultValues: {
      account_id: "",
      internal_project_id: "",
      internal_campaign_id: "",
      internal_adset_id: "",
      internal_ad_id: "",
      creative_item_id: "",
      appeal_target: "",
      emphasis_theme: "",
      appeal_content: "",
      design_structure: "",
      goal_event: "",
      goal_value: "",
    },
  })

  // 既存の広告検証設定を編集する場合、データを読み込む
  useEffect(() => {
    if (analysisId) {
      const analysis = LocalStorage.getAnalysisById(analysisId)
      if (analysis) {
        setIsEditing(true)

        // 日付をDate型に変換
        const targetDate = new Date(analysis.target_date)

        // フォームの初期値を設定
        form.reset({
          account_id: analysis.account_id,
          internal_project_id: analysis.internal_project_id,
          internal_campaign_id: analysis.internal_campaign_id,
          internal_adset_id: analysis.internal_adset_id,
          internal_ad_id: analysis.internal_ad_id,
          creative_item_id: analysis.creative_item_id,
          appeal_target: analysis.appeal_target,
          emphasis_theme: analysis.emphasis_theme,
          appeal_content: analysis.appeal_content,
          design_structure: analysis.design_structure,
          target_date: targetDate,
          goal_event: analysis.goal_event,
          goal_value: analysis.goal_value.toString(),
        })

        // 関連データを読み込む
        loadCampaigns(analysis.internal_project_id)
        loadAdSets(analysis.internal_campaign_id)
        loadAds(analysis.internal_adset_id)
      }
    }
  }, [analysisId, form])

  // プロジェクト一覧を取得
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        if (mode === "local") {
          const localProjects = LocalStorage.getProjects()
          setProjects(localProjects)
        } else if (mode === "mock-api") {
          const response = await fetch(`/api/mock/projects/list`)
          if (response.ok) {
            const data = await response.json()
            setProjects(data.projects || [])
          }
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/projects/list`)
          if (response.ok) {
            const data = await response.json()
            setProjects(data.projects || [])
          }
        }
      } catch (err) {
        console.error("プロジェクト取得エラー:", err)
      }
    }

    fetchProjects()
  }, [mode])

  // プロジェクトが選択されたらキャンペーン一覧を取得
  const loadCampaigns = async (projectId: string) => {
    try {
      if (mode === "local") {
        const localCampaigns = LocalStorage.getCampaignsByProject(projectId)
        setCampaigns(localCampaigns)
      } else if (mode === "mock-api") {
        const response = await fetch(`/api/mock/campaigns/list?project_id=${projectId}`)
        if (response.ok) {
          const data = await response.json()
          setCampaigns(data.campaigns || [])
        }
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/campaigns/list?project_id=${projectId}`)
        if (response.ok) {
          const data = await response.json()
          setCampaigns(data.campaigns || [])
        }
      }
    } catch (err) {
      console.error("キャンペーン取得エラー:", err)
    }
  }

  // キャンペーンが選択されたら広告セット一覧を取得
  const loadAdSets = async (campaignId: string) => {
    try {
      if (mode === "local") {
        const localAdSets = LocalStorage.getAdSetsByCampaign(campaignId)
        setAdSets(localAdSets)
      } else if (mode === "mock-api") {
        const response = await fetch(`/api/mock/ad-sets/list?campaign_id=${campaignId}`)
        if (response.ok) {
          const data = await response.json()
          setAdSets(data.adSets || [])
        }
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/ad-sets/list?campaign_id=${campaignId}`)
        if (response.ok) {
          const data = await response.json()
          setAdSets(data.adSets || [])
        }
      }
    } catch (err) {
      console.error("広告セット取得エラー:", err)
    }
  }

  // 広告セットが選択されたら広告一覧を取得
  const loadAds = async (adSetId: string) => {
    try {
      if (mode === "local") {
        // ローカルストレージから広告一覧を取得する関数が必要
        // 現在は実装されていないため、空の配列を返す
        setAds([])
      } else if (mode === "mock-api") {
        const response = await fetch(`/api/mock/ads/list?adset_id=${adSetId}`)
        if (response.ok) {
          const data = await response.json()
          setAds(data.ads || [])
        }
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/ads/list?adset_id=${adSetId}`)
        if (response.ok) {
          const data = await response.json()
          setAds(data.ads || [])
        }
      }
    } catch (err) {
      console.error("広告取得エラー:", err)
    }
  }

  // 広告が選択されたらクリエイティブ情報を取得
  const loadCreatives = async (adId: string) => {
    try {
      if (mode === "local") {
        // ローカルストレージからクリエイティブ一覧を取得する関数が必要
        // 現在は実装されていないため、空の配列を返す
        setCreatives([])
      } else if (mode === "mock-api") {
        const response = await fetch(`/api/mock/ads/get?ad_id=${adId}`)
        if (response.ok) {
          const data = await response.json()
          if (data.ad && data.ad.creative) {
            setCreatives([data.ad.creative])
          }
        }
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/ads/get?ad_id=${adId}`)
        if (response.ok) {
          const data = await response.json()
          if (data.ad && data.ad.creative) {
            setCreatives([data.ad.creative])
          }
        }
      }
    } catch (err) {
      console.error("クリエイティブ取得エラー:", err)
    }
  }

  const onSubmit = async (data: AnalysisFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // 分析IDの生成または既存IDの使用
      const newAnalysisId = isEditing ? analysisId! : `an${Date.now().toString().slice(-8)}`

      // 分析日を現在の日付に設定
      const analysisDate = new Date().toISOString().split("T")[0]

      // 広告検証設定データの構築
      const analysisData = {
        analysis_id: newAnalysisId,
        analysis_date: analysisDate,
        account_id: data.account_id,
        internal_project_id: data.internal_project_id,
        internal_campaign_id: data.internal_campaign_id,
        internal_adset_id: data.internal_adset_id,
        internal_ad_id: data.internal_ad_id,
        creative_item_id: data.creative_item_id,
        appeal_target: data.appeal_target,
        emphasis_theme: data.emphasis_theme,
        appeal_content: data.appeal_content,
        design_structure: data.design_structure,
        target_date: data.target_date.toISOString(),
        goal_event: data.goal_event,
        goal_value: Number.parseFloat(data.goal_value),
        created_at: isEditing
          ? LocalStorage.getAnalysisById(analysisId!)?.created_at || new Date().toISOString()
          : new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      if (mode === "local") {
        // ローカルストレージに保存
        LocalStorage.saveAnalysis(analysisData)
        setSuccess(`広告検証設定を${isEditing ? "更新" : "登録"}しました`)
      } else if (mode === "mock-api") {
        // モックAPIに保存
        const response = await fetch(`/api/mock/analysis/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(analysisData),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "広告検証設定の登録に失敗しました")
        }

        setSuccess(`広告検証設定を${isEditing ? "更新" : "登録"}しました`)
      } else {
        // 実際のAPIに保存
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/analysis/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(analysisData),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "広告検証設定の登録に失敗しました")
        }

        setSuccess(`広告検証設定を${isEditing ? "更新" : "登録"}しました`)
      }

      if (!isEditing) {
        // 新規作成の場合はフォームをリセット
        form.reset()
      }
    } catch (err: any) {
      console.error("広告検証設定登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>{isEditing ? "広告検証設定編集" : "広告検証設定作成"}</CardTitle>
          <CardDescription>広告の検証設定を{isEditing ? "編集" : "作成"}します。</CardDescription>
        </div>
        <DatabaseModeSelector />
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="account_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>アカウントID</FormLabel>
                    <FormControl>
                      <Input placeholder="例: act_123456789" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="internal_project_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>プロジェクト</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        loadCampaigns(value)
                        form.setValue("internal_campaign_id", "")
                        form.setValue("internal_adset_id", "")
                        form.setValue("internal_ad_id", "")
                        form.setValue("creative_item_id", "")
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="プロジェクトを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {projects.map((project) => (
                          <SelectItem key={project.project_id} value={project.project_id}>
                            {project.project_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="internal_campaign_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>キャンペーン</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        loadAdSets(value)
                        form.setValue("internal_adset_id", "")
                        form.setValue("internal_ad_id", "")
                        form.setValue("creative_item_id", "")
                      }}
                      defaultValue={field.value}
                      disabled={!form.getValues("internal_project_id")}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="キャンペーンを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {campaigns.map((campaign) => (
                          <SelectItem key={campaign.campaign_id} value={campaign.campaign_id}>
                            {campaign.campaign_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="internal_adset_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告セット</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        loadAds(value)
                        form.setValue("internal_ad_id", "")
                        form.setValue("creative_item_id", "")
                      }}
                      defaultValue={field.value}
                      disabled={!form.getValues("internal_campaign_id")}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="広告セットを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {adSets.map((adSet) => (
                          <SelectItem key={adSet.adset_id} value={adSet.adset_id}>
                            {adSet.adset_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="internal_ad_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        loadCreatives(value)
                        form.setValue("creative_item_id", "")
                      }}
                      defaultValue={field.value}
                      disabled={!form.getValues("internal_adset_id")}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="広告を選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {ads.map((ad) => (
                          <SelectItem key={ad.ad_id} value={ad.ad_id}>
                            {ad.ad_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="creative_item_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>クリエイティブ</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                      disabled={!form.getValues("internal_ad_id") || creatives.length === 0}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="クリエイティブを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {creatives.map((creative) => (
                          <SelectItem key={creative.creative_id} value={creative.creative_id}>
                            {creative.creative_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="border-t pt-4">
              <h3 className="text-lg font-medium mb-4">検証設定</h3>
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="appeal_target"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>訴求対象者</FormLabel>
                      <FormControl>
                        <Input placeholder="例: 20代〜30代の女性" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="emphasis_theme"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>強調テーマ</FormLabel>
                      <FormControl>
                        <Input placeholder="例: ブランド価値の強調" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="appeal_content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>訴求コンテンツ</FormLabel>
                      <FormControl>
                        <Textarea placeholder="例: 商品の特徴と利点" className="min-h-[100px]" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="design_structure"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>デザイン構成</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="例: シンプルなレイアウトと明るい色調"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <div className="border-t pt-4">
              <h3 className="text-lg font-medium mb-4">目標設定</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="target_date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>目標日</FormLabel>
                      <DatePicker date={field.value} setDate={field.onChange} />
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="goal_event"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>目標イベント</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="目標イベントを選択" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="商品購入">商品購入</SelectItem>
                          <SelectItem value="資料請求">資料請求</SelectItem>
                          <SelectItem value="会員登録">会員登録</SelectItem>
                          <SelectItem value="アプリインストール">アプリインストール</SelectItem>
                          <SelectItem value="サイト訪問">サイト訪問</SelectItem>
                          <SelectItem value="動画視聴">動画視聴</SelectItem>
                          <SelectItem value="エンゲージメント">エンゲージメント</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="goal_value"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>目標値</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="例: 5.0" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {isEditing ? "更新中..." : "登録中..."}
                </>
              ) : isEditing ? (
                "広告検証設定を更新"
              ) : (
                "広告検証設定を登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
