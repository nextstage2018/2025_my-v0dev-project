"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Plus, Calendar, BarChart } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import DatabaseModeSelector from "./database-mode-selector"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Analysis = {
  analysis_id: string
  analysis_date: string
  account_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  creative_item_id: string
  appeal_target: string
  emphasis_theme: string
  appeal_content: string
  design_structure: string
  target_date: string
  goal_event: string
  goal_value: number
  created_at: string
  updated_at: string
}

export default function AnalysisList() {
  const { mode } = useDatabase()
  const [analyses, setAnalyses] = useState<Analysis[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterProject, setFilterProject] = useState<string>("")
  const [projects, setProjects] = useState<LocalStorage.Project[]>([])

  // プロジェクト一覧を取得
  useEffect(() => {
    const fetchProjects = async () => {
      if (mode === "local") {
        setProjects(LocalStorage.getProjects())
      } else if (mode === "mock-api") {
        const response = await fetch(`/api/mock/projects/list`)
        if (response.ok) {
          const data = await response.json()
          setProjects(data.projects || [])
        }
      } else {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/projects/list`)
        if (response.ok) {
          const data = await response.json()
          setProjects(data.projects || [])
        }
      }
    }

    fetchProjects()
  }, [mode])

  const fetchAnalyses = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージから広告検証設定一覧を取得
        let localAnalyses = LocalStorage.getAnalyses()

        // プロジェクトでフィルタリング
        if (filterProject) {
          localAnalyses = localAnalyses.filter((analysis) => analysis.internal_project_id === filterProject)
        }

        // 検索語でフィルタリング
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          localAnalyses = localAnalyses.filter(
            (analysis) =>
              analysis.appeal_target.toLowerCase().includes(term) ||
              analysis.emphasis_theme.toLowerCase().includes(term) ||
              analysis.appeal_content.toLowerCase().includes(term) ||
              analysis.goal_event.toLowerCase().includes(term),
          )
        }

        setAnalyses(localAnalyses)
      } else if (mode === "mock-api") {
        // モックAPIから広告検証設定一覧を取得
        let url = `/api/mock/analysis/list`
        const params = new URLSearchParams()

        if (filterProject) {
          params.append("project_id", filterProject)
        }

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("広告検証設定情報の取得に失敗しました")
        }

        const data = await response.json()
        let analysesData = data.analyses || []

        // 検索語でフィルタリング
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          analysesData = analysesData.filter(
            (analysis: Analysis) =>
              analysis.appeal_target.toLowerCase().includes(term) ||
              analysis.emphasis_theme.toLowerCase().includes(term) ||
              analysis.appeal_content.toLowerCase().includes(term) ||
              analysis.goal_event.toLowerCase().includes(term),
          )
        }

        setAnalyses(analysesData)
      } else {
        // 実際のAPIから広告検証設定一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        let url = `${apiBaseUrl}/api/analysis/list`
        const params = new URLSearchParams()

        if (filterProject) {
          params.append("project_id", filterProject)
        }

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("広告検証設定情報の取得に失敗しました")
        }

        const data = await response.json()
        let analysesData = data.analyses || []

        // 検索語でフィルタリング
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          analysesData = analysesData.filter(
            (analysis: Analysis) =>
              analysis.appeal_target.toLowerCase().includes(term) ||
              analysis.emphasis_theme.toLowerCase().includes(term) ||
              analysis.appeal_content.toLowerCase().includes(term) ||
              analysis.goal_event.toLowerCase().includes(term),
          )
        }

        setAnalyses(analysesData)
      }
    } catch (err: any) {
      console.error("広告検証設定取得エラー:", err)
      setError(err instanceof Error ? err.message : "広告検証設定情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchAnalyses()
  }, [mode, filterProject, searchTerm])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getProjectName = (projectId: string) => {
    const project = projects.find((p) => p.project_id === projectId)
    return project ? project.project_name : projectId
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>広告検証設定一覧</CardTitle>
          <CardDescription>登録されている広告検証設定の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/ads/analysis/new">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchAnalyses} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <Input
              placeholder="検索（訴求対象、強調テーマ、訴求コンテンツ、目標イベント）"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="w-full md:w-64">
            <Select value={filterProject} onValueChange={setFilterProject}>
              <SelectTrigger>
                <SelectValue placeholder="プロジェクトで絞り込み" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">すべてのプロジェクト</SelectItem>
                {projects.map((project) => (
                  <SelectItem key={project.project_id} value={project.project_id}>
                    {project.project_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : analyses.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            広告検証設定情報がありません。新しい広告検証設定を登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>検証ID</TableHead>
                  <TableHead>プロジェクト</TableHead>
                  <TableHead>訴求対象</TableHead>
                  <TableHead>強調テーマ</TableHead>
                  <TableHead>目標イベント</TableHead>
                  <TableHead>目標値</TableHead>
                  <TableHead>ターゲット日付</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {analyses.map((analysis) => (
                  <TableRow key={analysis.analysis_id}>
                    <TableCell className="font-mono">{analysis.analysis_id}</TableCell>
                    <TableCell>{getProjectName(analysis.internal_project_id)}</TableCell>
                    <TableCell>{analysis.appeal_target}</TableCell>
                    <TableCell>{analysis.emphasis_theme}</TableCell>
                    <TableCell>{analysis.goal_event}</TableCell>
                    <TableCell>{analysis.goal_value}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(analysis.target_date)}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/analysis/${analysis.analysis_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/analysis/${analysis.analysis_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/analysis/${analysis.analysis_id}/results`}>
                            <BarChart className="h-4 w-4" />
                            <span className="sr-only">結果</span>
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
