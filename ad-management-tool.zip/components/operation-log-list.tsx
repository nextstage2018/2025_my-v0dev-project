"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Calendar, Filter } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { DatePicker } from "@/components/ui/date-picker"

type OperationLog = {
  operation_id: string
  operation_type: string
  operation_status: string
  operation_message?: string
  executed_by?: string
  operation_timestamp: string
  error_code?: string
  error_details?: string
  additional_info?: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
}

export default function OperationLogList() {
  const { mode } = useDatabase()
  const [logs, setLogs] = useState<OperationLog[]>([])
  const [filteredLogs, setFilteredLogs] = useState<OperationLog[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // フィルター用の状態
  const [filterType, setFilterType] = useState<string>("")
  const [filterStatus, setFilterStatus] = useState<string>("")
  const [filterDateFrom, setFilterDateFrom] = useState<Date | undefined>(undefined)
  const [filterDateTo, setFilterDateTo] = useState<Date | undefined>(undefined)
  const [filterAdId, setFilterAdId] = useState<string>("")
  const [filterCampaignId, setFilterCampaignId] = useState<string>("")
  const [showFilters, setShowFilters] = useState(false)

  const fetchLogs = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージから運用ログ一覧を取得
        const localLogs = LocalStorage.getOperationLogs()
        setLogs(localLogs)
        setFilteredLogs(localLogs)
      } else if (mode === "mock-api") {
        // モックAPIから運用ログ一覧を取得
        const response = await fetch(`/api/mock/operation-logs/list`)

        if (!response.ok) {
          throw new Error("運用ログ情報の取得に失敗しました")
        }

        const data = await response.json()
        setLogs(data.logs || [])
        setFilteredLogs(data.logs || [])
      } else {
        // 実際のBigQuery APIから運用ログ一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/operation-logs/list`)

        if (!response.ok) {
          throw new Error("運用ログ情報の取得に失敗しました")
        }

        const data = await response.json()
        setLogs(data.logs || [])
        setFilteredLogs(data.logs || [])
      }
    } catch (err: any) {
      console.error("運用ログ取得エラー:", err)
      setError(err instanceof Error ? err.message : "運用ログ情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchLogs()
  }, [mode])

  // フィルター適用
  useEffect(() => {
    let filtered = [...logs]

    if (filterType) {
      filtered = filtered.filter((log) => log.operation_type === filterType)
    }

    if (filterStatus) {
      filtered = filtered.filter((log) => log.operation_status === filterStatus)
    }

    if (filterDateFrom) {
      filtered = filtered.filter((log) => new Date(log.operation_timestamp) >= filterDateFrom)
    }

    if (filterDateTo) {
      const endOfDay = new Date(filterDateTo)
      endOfDay.setHours(23, 59, 59, 999)
      filtered = filtered.filter((log) => new Date(log.operation_timestamp) <= endOfDay)
    }

    if (filterAdId) {
      filtered = filtered.filter((log) => log.ad_id.includes(filterAdId) || log.internal_ad_id.includes(filterAdId))
    }

    if (filterCampaignId) {
      filtered = filtered.filter(
        (log) => log.campaign_id.includes(filterCampaignId) || log.internal_campaign_id.includes(filterCampaignId),
      )
    }

    setFilteredLogs(filtered)
  }, [logs, filterType, filterStatus, filterDateFrom, filterDateTo, filterAdId, filterCampaignId])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm:ss", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "success":
      case "completed":
        return (
          <Badge variant="default" className="bg-green-500">
            成功
          </Badge>
        )
      case "failed":
      case "error":
        return <Badge variant="destructive">失敗</Badge>
      case "pending":
        return <Badge variant="secondary">処理中</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-700">
            警告
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getOperationTypes = () => {
    const types = new Set(logs.map((log) => log.operation_type))
    return Array.from(types)
  }

  const getOperationStatuses = () => {
    const statuses = new Set(logs.map((log) => log.operation_status))
    return Array.from(statuses)
  }

  const resetFilters = () => {
    setFilterType("")
    setFilterStatus("")
    setFilterDateFrom(undefined)
    setFilterDateTo(undefined)
    setFilterAdId("")
    setFilterCampaignId("")
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>運用ログ一覧</CardTitle>
          <CardDescription>広告運用の操作履歴一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1"
          >
            <Filter className="h-4 w-4" />
            {showFilters ? "フィルターを隠す" : "フィルター"}
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchLogs} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {showFilters && (
          <div className="mb-6 p-4 border rounded-md">
            <h3 className="font-medium mb-4">フィルター設定</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">操作タイプ</label>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger>
                    <SelectValue placeholder="すべて" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">すべて</SelectItem>
                    {getOperationTypes().map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">ステータス</label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="すべて" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">すべて</SelectItem>
                    {getOperationStatuses().map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">広告ID</label>
                <Input placeholder="広告IDで検索" value={filterAdId} onChange={(e) => setFilterAdId(e.target.value)} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">キャンペーンID</label>
                <Input
                  placeholder="キャンペーンIDで検索"
                  value={filterCampaignId}
                  onChange={(e) => setFilterCampaignId(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">開始日</label>
                <DatePicker date={filterDateFrom} setDate={setFilterDateFrom} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">終了日</label>
                <DatePicker date={filterDateTo} setDate={setFilterDateTo} />
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button variant="outline" size="sm" onClick={resetFilters}>
                フィルターをリセット
              </Button>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">運用ログ情報がありません。</div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>操作日時</TableHead>
                  <TableHead>操作タイプ</TableHead>
                  <TableHead>ステータス</TableHead>
                  <TableHead>メッセージ</TableHead>
                  <TableHead>広告ID</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredLogs.map((log) => (
                  <TableRow key={log.operation_id}>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(log.operation_timestamp)}</span>
                      </div>
                    </TableCell>
                    <TableCell>{log.operation_type}</TableCell>
                    <TableCell>{getStatusBadge(log.operation_status)}</TableCell>
                    <TableCell className="max-w-xs truncate">{log.operation_message || "-"}</TableCell>
                    <TableCell className="font-mono text-xs">{log.internal_ad_id}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <Link href={`/ads/operation-logs/${log.operation_id}`}>
                          <Eye className="h-4 w-4" />
                          <span className="sr-only">詳細</span>
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
