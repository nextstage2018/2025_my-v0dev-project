"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/ui/date-picker"

// キャンペーン情報のバリデーションスキーマ
const campaignSchema = z.object({
  project_id: z.string().min(1, "プロジェクトの選択は必須です"),
  campaign_name: z.string().min(1, "キャンペーン名は必須です"),
  objective: z.enum(["awareness", "consideration", "conversion"]),
  status: z.enum(["draft", "active", "paused", "completed"]),
  start_date: z.date({
    required_error: "開始日は必須です",
  }),
  end_date: z
    .date({
      required_error: "終了日は必須です",
    })
    .optional(),
  daily_budget: z.string().optional(),
  total_budget: z.string().optional(),
  description: z.string().optional(),
})

type CampaignFormValues = z.infer<typeof campaignSchema>

type Project = {
  project_id: string
  project_name: string
  client_id: string
  client_name?: string
}

export default function CampaignForm() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [campaignId, setCampaignId] = useState<string | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoadingProjects, setIsLoadingProjects] = useState(false)

  const form = useForm<CampaignFormValues>({
    resolver: zodResolver(campaignSchema),
    defaultValues: {
      project_id: "",
      campaign_name: "",
      objective: "awareness",
      status: "draft",
      daily_budget: "",
      total_budget: "",
      description: "",
    },
  })

  // プロジェクト一覧を取得
  useEffect(() => {
    const fetchProjects = async () => {
      setIsLoadingProjects(true)
      try {
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/projects/list`)

        if (!response.ok) {
          throw new Error("プロジェクト情報の取得に失敗しました")
        }

        const data = await response.json()
        setProjects(data.projects || [])
      } catch (err) {
        console.error("プロジェクト取得エラー:", err)
        setError(err instanceof Error ? err.message : "プロジェクト情報の取得中にエラーが発生しました")
      } finally {
        setIsLoadingProjects(false)
      }
    }

    fetchProjects()
  }, [])

  const onSubmit = async (data: CampaignFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const selectedProject = projects.find((project) => project.project_id === data.project_id)
      if (!selectedProject) {
        throw new Error("選択されたプロジェクトが見つかりません")
      }

      // 新しいキャンペーンIDを生成（実際の実装ではサーバーサイドで行うべき）
      const campaignNumber = String(Math.floor(Math.random() * 100000)).padStart(5, "0")
      const newCampaignId = `${data.project_id}_ca${campaignNumber}`

      // APIリクエストの準備
      const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""

      // BigQueryにデータを登録するリクエスト
      const response = await fetch(`${apiBaseUrl}/api/campaigns/create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          campaign_id: newCampaignId,
          ...data,
          start_date: data.start_date.toISOString(),
          end_date: data.end_date ? data.end_date.toISOString() : null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "キャンペーン情報の登録に失敗しました")
      }

      const result = await response.json()
      setCampaignId(newCampaignId)
      setSuccess(`キャンペーン「${data.campaign_name}」を登録しました。キャンペーンID: ${newCampaignId}`)
      form.reset()
    } catch (err) {
      console.error("キャンペーン登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>キャンペーン登録</CardTitle>
        <CardDescription>広告キャンペーンの基本情報を登録します。</CardDescription>
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert>
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="project_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>プロジェクト</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isLoadingProjects}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="プロジェクトを選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project.project_id} value={project.project_id}>
                          {project.project_name} ({project.project_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="campaign_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>キャンペーン名</FormLabel>
                  <FormControl>
                    <Input placeholder="2025年春キャンペーン" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="objective"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>広告目的</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="広告目的を選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="awareness">認知拡大</SelectItem>
                      <SelectItem value="consideration">興味・関心</SelectItem>
                      <SelectItem value="conversion">コンバージョン</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="start_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>開始日</FormLabel>
                    <DatePicker date={field.value} setDate={field.onChange} />
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="end_date"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>終了日（任意）</FormLabel>
                    <DatePicker date={field.value} setDate={field.onChange} />
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="daily_budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>日予算</FormLabel>
                    <FormControl>
                      <Input placeholder="10,000円/日" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="total_budget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>総予算</FormLabel>
                    <FormControl>
                      <Input placeholder="300,000円" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ステータス</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="ステータスを選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="draft">下書き</SelectItem>
                      <SelectItem value="active">アクティブ</SelectItem>
                      <SelectItem value="paused">一時停止</SelectItem>
                      <SelectItem value="completed">完了</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>キャンペーン詳細</FormLabel>
                  <FormControl>
                    <Textarea placeholder="キャンペーンの目的や詳細情報" className="min-h-[100px]" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  登録中...
                </>
              ) : (
                "キャンペーンを登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
