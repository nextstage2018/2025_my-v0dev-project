"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { generateProjectId } from "@/lib/id-utils"
import {
  INDUSTRY_CATEGORIES,
  MEDIA_TYPES,
  COMMISSION_TYPES,
  DELIVERY_STATUSES,
  type IndustryCategory,
  type MediaType,
} from "@/lib/master-data-types"
import { getIndustryCategories, getMediaTypes } from "@/lib/master-storage"
import DatabaseModeSelector from "./database-mode-selector"

// プロジェクト情報のバリデーションスキーマ
const projectSchema = z.object({
  company_id: z.string().min(1, "クライアントの選択は必須です"),
  delivery_status: z.string().min(1, "配信ステータスは必須です"),
  industry_main_category: z.string().min(1, "業界カテゴリ（大）は必須です"),
  industry_sub_category: z.string().min(1, "業界カテゴリ（中）は必須です"),
  industry_detail_tag: z.string().optional(),
  internal_project_name: z.string().min(1, "プロジェクト名は必須です"),
  admanage_name: z.string().min(1, "広告ビジネスアカウント名は必須です"),
  admanage_id: z.string().min(1, "広告ビジネスアカウントIDは必須です"),
  adaccount_id: z.string().min(1, "広告アカウントIDは必須です"),
  adaccount_name: z.string().min(1, "広告アカウント名は必須です"),
  commission_type: z.string().min(1, "報酬形態は必須です"),
  commission_feerate: z.string().optional(),
  chatwork_room_id: z.string().optional(),
  chatwork_member: z.string().optional(),
  client_member: z.string().optional(),
  client_member_email: z.string().optional(),
  media_type: z.string().min(1, "メディアタイプは必須です"),
  media_id: z.string().min(1, "メディアIDは必須です"),
})

type ProjectFormValues = z.infer<typeof projectSchema>

type Client = {
  client_id: string
  client_name: string
}

export default function ProjectFormWithMock() {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [projectId, setProjectId] = useState<string | null>(null)
  const [clients, setClients] = useState<Client[]>([])
  const [isLoadingClients, setIsLoadingClients] = useState(false)
  const [selectedMainCategory, setSelectedMainCategory] = useState<string>("")
  const [subCategories, setSubCategories] = useState<{ id: string; name: string }[]>([])
  const [selectedMediaType, setSelectedMediaType] = useState<string>("")
  const [filteredMedia, setFilteredMedia] = useState<MediaType[]>([])
  const [industryCategories, setIndustryCategories] = useState<IndustryCategory[]>([])
  const [mediaTypes, setMediaTypes] = useState<MediaType[]>([])

  const form = useForm<ProjectFormValues>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      company_id: "",
      delivery_status: "pending",
      industry_main_category: "",
      industry_sub_category: "",
      industry_detail_tag: "",
      internal_project_name: "",
      admanage_name: "",
      admanage_id: "",
      adaccount_id: "",
      adaccount_name: "",
      commission_type: "",
      commission_feerate: "",
      chatwork_room_id: "",
      chatwork_member: "",
      client_member: "",
      client_member_email: "",
      media_type: "",
      media_id: "",
    },
  })

  // マスタデータの読み込み
  useEffect(() => {
    // 業界カテゴリの読み込み
    const storedCategories = getIndustryCategories()
    if (storedCategories.length > 0) {
      setIndustryCategories(storedCategories)
    } else {
      setIndustryCategories(INDUSTRY_CATEGORIES)
    }

    // メディアタイプの読み込み
    const storedMedia = getMediaTypes()
    if (storedMedia.length > 0) {
      setMediaTypes(storedMedia)
    } else {
      setMediaTypes(MEDIA_TYPES)
    }
  }, [])

  // 業界カテゴリ（大）が変更されたときのハンドラ
  const handleMainCategoryChange = (value: string) => {
    setSelectedMainCategory(value)
    const category = industryCategories.find((cat) => cat.id === value)
    if (category) {
      setSubCategories(category.sub_categories)
      form.setValue("industry_sub_category", "")
    } else {
      setSubCategories([])
    }
  }

  // メディアタイプが変更されたときのハンドラ
  const handleMediaTypeChange = (value: string) => {
    setSelectedMediaType(value)
    const filtered = mediaTypes.filter((media) => media.media_type === value)
    setFilteredMedia(filtered)
    form.setValue("media_id", "")
  }

  // クライアント一覧を取得
  useEffect(() => {
    const fetchClients = async () => {
      setIsLoadingClients(true)
      setError(null)

      try {
        if (mode === "local") {
          // ローカルストレージからクライアント一覧を取得
          const localClients = LocalStorage.getClients()
          setClients(
            localClients.map((client) => ({
              client_id: client.client_id,
              client_name: client.client_name,
            })),
          )
        } else if (mode === "mock-api") {
          // モックAPIからクライアント一覧を取得
          const response = await fetch(`/api/mock/clients/list`)

          if (!response.ok) {
            throw new Error("クライアント情報の取得に失敗しました")
          }

          const data = await response.json()
          setClients(data.clients || [])
        } else {
          // 実際のBigQuery APIからクライアント一覧を取得
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          const response = await fetch(`${apiBaseUrl}/api/clients/list`)

          if (!response.ok) {
            throw new Error("クライアント情報の取得に失敗しました")
          }

          const data = await response.json()
          setClients(data.clients || [])
        }
      } catch (err: any) {
        console.error("クライアント取得エラー:", err)
        setError(err instanceof Error ? err.message : "クライアント情報の取得中にエラーが発生しました")
      } finally {
        setIsLoadingClients(false)
      }
    }

    fetchClients()
  }, [mode])

  // 利用可能なメディアタイプの一覧を取得
  const uniqueMediaTypes = [...new Set(mediaTypes.map((media) => media.media_type))].map((type) => ({
    id: type,
    name: type,
  }))

  const onSubmit = async (data: ProjectFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const selectedClient = clients.find((client) => client.client_id === data.company_id)
      if (!selectedClient) {
        throw new Error("選択されたクライアントが見つかりません")
      }

      // メディア名を取得
      const selectedMedia = mediaTypes.find((media) => media.media_id === data.media_id)
      if (!selectedMedia) {
        throw new Error("選択されたメディアが見つかりません")
      }

      let newProjectId: string

      if (mode === "local") {
        // ローカルストレージモード
        const projects = LocalStorage.getProjects()
        const projectIds = projects.map((project) => project.project_id)
        newProjectId = generateProjectId(data.company_id, projectIds)

        // プロジェクトデータを作成
        const projectData = {
          project_id: newProjectId,
          client_id: data.company_id,
          project_name: data.internal_project_name,
          description: "プロジェクト詳細",
          start_date: new Date().toISOString(),
          end_date: undefined,
          budget: "",
          team_members: "",
          goals: "",
          status: "planning" as const,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        // LocalStorage.saveProjectを使用してプロジェクトを保存
        LocalStorage.saveProject(projectData)

        setProjectId(newProjectId)
        setSuccess(`${data.internal_project_name}のデータ登録が完了しました。`)
      } else if (mode === "mock-api") {
        // モックAPIモード
        const response = await fetch(`/api/mock/projects/list`)
        const projectsData = await response.json()
        const projectIds = projectsData.projects.map((project: any) => project.project_id)
        newProjectId = generateProjectId(data.company_id, projectIds)

        const response2 = await fetch(`/api/mock/projects/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            project_id: newProjectId,
            client_id: data.company_id,
            project_name: data.internal_project_name,
            description: "プロジェクト詳細",
            start_date: new Date().toISOString(),
            status: "planning",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "プロジェクト情報の登録に失敗しました")
        }

        const result = await response2.json()
        setProjectId(newProjectId)
        setSuccess(`${data.internal_project_name}のデータ登録が完了しました。`)
      } else {
        // 実際のBigQuery APIモード
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/projects/list`)
        const projectsData = await response.json()
        const projectIds = projectsData.projects.map((project: any) => project.project_id)
        newProjectId = generateProjectId(data.company_id, projectIds)

        const response2 = await fetch(`${apiBaseUrl}/api/projects/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            project_id: newProjectId,
            client_id: data.company_id,
            project_name: data.internal_project_name,
            description: "プロジェクト詳細",
            start_date: new Date().toISOString(),
            status: "planning",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "プロジェクト情報の登録に失敗しました")
        }

        const result = await response2.json()
        setProjectId(newProjectId)
        setSuccess(`${data.internal_project_name}のデータ登録が完了しました。`)
      }

      form.reset()
    } catch (err: any) {
      console.error("プロジェクト登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>プロジェクト登録</CardTitle>
          <CardDescription>広告運用プロジェクトの基本情報を登録します。</CardDescription>
        </div>
        <DatabaseModeSelector />
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="company_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>クライアント</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value} disabled={isLoadingClients}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="クライアントを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {clients.map((client) => (
                          <SelectItem key={client.client_id} value={client.client_id}>
                            {client.client_name} ({client.client_id})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="delivery_status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>配信ステータス</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="配信ステータスを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {DELIVERY_STATUSES.map((status) => (
                          <SelectItem key={status.id} value={status.id}>
                            {status.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="internal_project_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>プロジェクト名（内部管理用）</FormLabel>
                  <FormControl>
                    <Input placeholder="2025年春キャンペーン" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="industry_main_category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>業界カテゴリ（大）</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        handleMainCategoryChange(value)
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="業界カテゴリを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {industryCategories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.main_category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="industry_sub_category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>業界カテゴリ（中）</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!selectedMainCategory}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="サブカテゴリを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {subCategories.map((subCategory) => (
                          <SelectItem key={subCategory.id} value={subCategory.id}>
                            {subCategory.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="industry_detail_tag"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>業界カテゴリ（小）</FormLabel>
                  <FormControl>
                    <Input placeholder="詳細なカテゴリを入力（任意）" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="admanage_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告ビジネスアカウント名</FormLabel>
                    <FormControl>
                      <Input placeholder="ビジネスアカウント名" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="admanage_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告ビジネスアカウントID</FormLabel>
                    <FormControl>
                      <Input placeholder="ビジネスアカウントID" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="adaccount_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告アカウント名</FormLabel>
                    <FormControl>
                      <Input placeholder="広告アカウント名" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="adaccount_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>広告アカウントID</FormLabel>
                    <FormControl>
                      <Input placeholder="広告アカウントID" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="commission_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>報酬形態</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="報酬形態を選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {COMMISSION_TYPES.map((type) => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="commission_feerate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>手数料率（%）</FormLabel>
                    <FormControl>
                      <Input placeholder="例: 10%, 20%, 30%" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="chatwork_room_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ChatworkルームID</FormLabel>
                    <FormControl>
                      <Input placeholder="ChatworkルームID" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="chatwork_member"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>ChatworkメンバーID</FormLabel>
                    <FormControl>
                      <Input placeholder="ChatworkメンバーID" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="client_member"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>クライアント担当者</FormLabel>
                    <FormControl>
                      <Input placeholder="担当者名" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="client_member_email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>クライアント担当者メール</FormLabel>
                    <FormControl>
                      <Input placeholder="example@company.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="media_type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>メディアタイプ</FormLabel>
                    <Select
                      onValueChange={(value) => {
                        field.onChange(value)
                        handleMediaTypeChange(value)
                      }}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="メディアタイプを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {uniqueMediaTypes.map((type) => (
                          <SelectItem key={type.id} value={type.id}>
                            {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="media_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>メディア</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value} disabled={!selectedMediaType}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="メディアを選択" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {filteredMedia.map((media) => (
                          <SelectItem key={media.media_id} value={media.media_id}>
                            {media.media_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  登録中...
                </>
              ) : (
                "プロジェクトを登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
