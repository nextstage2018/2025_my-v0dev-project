"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Calendar, AlertCircle } from "lucide-react"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import * as LocalStorage from "@/lib/local-storage"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

type OperationLog = {
  operation_id: string
  operation_type: string
  operation_status: string
  operation_message?: string
  executed_by?: string
  operation_timestamp: string
  error_code?: string
  error_details?: string
  additional_info?: string
  account_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_project_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
}

export default function OperationLogDetail({ operationId }: { operationId: string }) {
  const [log, setLog] = useState<OperationLog | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const fetchLog = async () => {
      setIsLoading(true)
      setError(null)

      try {
        // ローカルストレージから運用ログを取得
        const operationLog = LocalStorage.getOperationLogById(operationId)
        if (!operationLog) {
          setError("運用ログが見つかりません")
          setLog(null)
        } else {
          setLog(operationLog)

          // 実行者情報を取得
          if (operationLog.executed_by) {
            const userInfo = LocalStorage.getUserById(operationLog.executed_by)
            setUser(userInfo)
          }
        }
      } catch (err: any) {
        console.error("運用ログ取得エラー:", err)
        setError(err instanceof Error ? err.message : "運用ログ情報の取得中にエラーが発生しました")
        setLog(null)
      } finally {
        setIsLoading(false)
      }
    }

    fetchLog()
  }, [operationId])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm:ss", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case "success":
      case "completed":
        return (
          <Badge variant="default" className="bg-green-500">
            成功
          </Badge>
        )
      case "failed":
      case "error":
        return <Badge variant="destructive">失敗</Badge>
      case "pending":
        return <Badge variant="secondary">処理中</Badge>
      case "warning":
        return (
          <Badge variant="outline" className="border-yellow-500 text-yellow-700">
            警告
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  if (error || !log) {
    return (
      <Alert variant="destructive">
        <AlertDescription>{error || "運用ログ情報の取得に失敗しました"}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>運用ログ基本情報</CardTitle>
          <CardDescription>運用ログの基本情報</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">操作ID</h3>
              <p className="font-mono">{log.operation_id}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">操作タイプ</h3>
              <p>{log.operation_type}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">ステータス</h3>
              {getStatusBadge(log.operation_status)}
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground">操作日時</h3>
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span>{formatDate(log.operation_timestamp)}</span>
              </div>
            </div>
            {log.executed_by && (
              <div>
                <h3 className="text-sm font-medium text-muted-foreground">実行者</h3>
                <p>{user ? user.user_name : log.executed_by}</p>
              </div>
            )}
            {log.operation_message && (
              <div className="col-span-2">
                <h3 className="text-sm font-medium text-muted-foreground">メッセージ</h3>
                <p>{log.operation_message}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="target">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="target">対象情報</TabsTrigger>
          <TabsTrigger value="details">詳細情報</TabsTrigger>
        </TabsList>
        <TabsContent value="target">
          <Card>
            <CardHeader>
              <CardTitle>対象情報</CardTitle>
              <CardDescription>操作対象の広告情報</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">アカウントID</h3>
                  <p className="font-mono">{log.account_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">キャンペーンID</h3>
                  <p className="font-mono">{log.campaign_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">広告セットID</h3>
                  <p className="font-mono">{log.adset_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">広告ID</h3>
                  <p className="font-mono">{log.ad_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">内部プロジェクトID</h3>
                  <p className="font-mono">{log.internal_project_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">内部キャンペーンID</h3>
                  <p className="font-mono">{log.internal_campaign_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">内部広告セットID</h3>
                  <p className="font-mono">{log.internal_adset_id}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">内部広告ID</h3>
                  <p className="font-mono">{log.internal_ad_id}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>詳細情報</CardTitle>
              <CardDescription>操作の詳細情報</CardDescription>
            </CardHeader>
            <CardContent>
              {log.error_code && (
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-muted-foreground">エラーコード</h3>
                  <div className="mt-1 p-2 bg-red-50 border border-red-200 rounded-md text-red-700 font-mono">
                    {log.error_code}
                  </div>
                </div>
              )}

              {log.error_details && (
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-muted-foreground">エラー詳細</h3>
                  <div className="mt-1 p-3 bg-red-50 border border-red-200 rounded-md text-red-700 whitespace-pre-wrap">
                    {log.error_details}
                  </div>
                </div>
              )}

              {log.additional_info && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">追加情報</h3>
                  <div className="mt-1 p-3 bg-gray-50 border border-gray-200 rounded-md whitespace-pre-wrap">
                    {typeof log.additional_info === "string" ? (
                      log.additional_info
                    ) : (
                      <pre className="text-xs overflow-auto">{JSON.stringify(log.additional_info, null, 2)}</pre>
                    )}
                  </div>
                </div>
              )}

              {!log.error_code && !log.error_details && !log.additional_info && (
                <div className="flex items-center justify-center py-8 text-muted-foreground">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  詳細情報はありません
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
