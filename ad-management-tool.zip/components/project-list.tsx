"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Calendar, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"

type Project = {
  project_id: string
  client_id: string
  client_name?: string
  project_name: string
  status: string
  start_date: string
  end_date?: string
  created_at: string
}

export default function ProjectList() {
  const { mode } = useDatabase()
  const [projects, setProjects] = useState<Project[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchProjects = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージからプロジェクト一覧を取得
        const localProjects = LocalStorage.getProjects()
        const localClients = LocalStorage.getClients()

        const projectsWithClientName = localProjects.map((project) => {
          const client = localClients.find((c) => c.client_id === project.client_id)
          return {
            ...project,
            client_name: client?.client_name || "不明なクライアント",
          }
        })

        setProjects(projectsWithClientName)
      } else if (mode === "mock-api") {
        // モックAPIからプロジェクト一覧を取得
        const response = await fetch(`/api/mock/projects/list`)

        if (!response.ok) {
          throw new Error("プロジェクト情報の取得に失敗しました")
        }

        const data = await response.json()
        setProjects(data.projects || [])
      } else {
        // 実際のBigQuery APIからプロジェクト一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/projects/list`)

        if (!response.ok) {
          throw new Error("プロジェクト情報の取得に失敗しました")
        }

        const data = await response.json()
        setProjects(data.projects || [])
      }
    } catch (err: any) {
      console.error("プロジェクト取得エラー:", err)
      setError(err instanceof Error ? err.message : "プロジェクト情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchProjects()
  }, [mode])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "planning":
        return <Badge variant="outline">計画中</Badge>
      case "active":
        return (
          <Badge variant="default" className="bg-green-500">
            実行中
          </Badge>
        )
      case "paused":
        return <Badge variant="secondary">一時停止</Badge>
      case "completed":
        return (
          <Badge variant="default" className="bg-blue-500">
            完了
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const handleDelete = async (projectId: string) => {
    if (confirm("本当に削除しますか？")) {
      LocalStorage.deleteProject(projectId)
      fetchProjects() // リストを更新
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>プロジェクト一覧</CardTitle>
          <CardDescription>登録されているプロジェクト情報の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/database/projects">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchProjects} variant="outline" size="icon">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            プロジェクト情報がありません。新しいプロジェクトを登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>プロジェクト名</TableHead>
                  <TableHead>クライアント</TableHead>
                  <TableHead>ステータス</TableHead>
                  <TableHead>期間</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {projects.map((project) => (
                  <TableRow key={project.project_id}>
                    <TableCell className="font-medium">{project.project_name}</TableCell>
                    <TableCell>{project.client_name}</TableCell>
                    <TableCell>{getStatusBadge(project.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(project.start_date)}</span>
                        {project.end_date && (
                          <>
                            <span className="mx-1">〜</span>
                            <span>{formatDate(project.end_date)}</span>
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/database/projects/${project.project_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/database/projects/${project.project_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(project.project_id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                          <span className="sr-only">削除</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
