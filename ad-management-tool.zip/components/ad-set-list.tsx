"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Plus, Calendar } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"
import type { AdSet } from "@/lib/ad-set-types"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type AdSetListProps = {
  accountId?: string | null
  showFilters?: boolean
  metrics?: string[]
}

export default function AdSetList({
  accountId,
  showFilters = false,
  metrics = ["impressions", "clicks", "conversions"],
}: AdSetListProps) {
  const { mode } = useDatabase()
  const [adSets, setAdSets] = useState<AdSet[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // フィルター状態
  const [campaignId, setCampaignId] = useState<string>("")
  const [status, setStatus] = useState<string>("")
  const [searchTerm, setSearchTerm] = useState("")

  // キャンペーンとアドセットのリスト
  const [campaigns, setCampaigns] = useState<{ id: string; name: string }[]>([])

  // ソートとページネーションの状態
  const [sortField, setSortField] = useState("created_at")
  const [sortOrder, setSortOrder] = useState("desc")
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)

  const fetchAdSets = async () => {
    setIsLoading(true)
    setError(null)

    try {
      let localAdSets: AdSet[] = []
      if (mode === "local") {
        // ローカルストレージから広告セット一覧を取得
        localAdSets = LocalStorage.getAdSets()
        console.log("AdSetList - LocalStorage AdSets:", localAdSets) // デバッグログ

        // フィルタリング
        if (campaignId && campaignId !== "all") {
          localAdSets = localAdSets.filter((adSet) => adSet.campaign_id === campaignId)
        }
        if (status && status !== "all") {
          localAdSets = localAdSets.filter((adSet) => adSet.status === status)
        }
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          localAdSets = localAdSets.filter((adSet) => adSet.adset_name.toLowerCase().includes(term))
        }

        setAdSets(localAdSets)

        // キャンペーンリストを更新
        const uniqueCampaigns = Array.from(new Set(localAdSets.map((adSet) => adSet.campaign_id))).map((id) => {
          const adSet = localAdSets.find((adSet) => adSet.campaign_id === id)
          return { id: adSet.campaign_id, name: adSet.campaign_name }
        })
        setCampaigns(uniqueCampaigns)
      } else if (mode === "mock-api") {
        // モックAPIから広告セット一覧を取得
        const response = await fetch(`/api/mock/ad-sets/list`)

        if (!response.ok) {
          throw new Error("広告セット情報の取得に失敗しました")
        }

        const data = await response.json()
        setAdSets(data.adSets || [])
      } else {
        // 実際のBigQuery APIから広告セット一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/ad-sets/list`)

        if (!response.ok) {
          throw new Error("広告セット情報の取得に失敗しました")
        }

        const data = await response.json()
        setAdSets(data.adSets || [])
      }
    } catch (err: any) {
      console.error("広告セット取得エラー:", err)
      setError(err instanceof Error ? err.message : "広告セット情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchAdSets()
  }, [mode, accountId, campaignId, status, searchTerm, metrics])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getBillingEventBadge = (billingEvent: string) => {
    switch (billingEvent) {
      case "IMPRESSIONS":
        return <Badge variant="outline">インプレッション課金</Badge>
      case "LINK_CLICKS":
        return <Badge variant="secondary">クリック課金</Badge>
      case "CONVERSIONS":
        return (
          <Badge variant="default" className="bg-green-500">
            コンバージョン課金
          </Badge>
        )
      default:
        return <Badge variant="outline">{billingEvent}</Badge>
    }
  }

  const getOptimizationGoalBadge = (goal: string) => {
    switch (goal) {
      case "REACH":
        return <Badge variant="outline">リーチ</Badge>
      case "IMPRESSIONS":
        return <Badge variant="secondary">インプレッション</Badge>
      case "LINK_CLICKS":
        return (
          <Badge variant="default" className="bg-blue-500">
            リンククリック
          </Badge>
        )
      case "CONVERSIONS":
        return (
          <Badge variant="default" className="bg-green-500">
            コンバージョン課金
          </Badge>
        )
      case "LEAD_GENERATION":
        return (
          <Badge variant="default" className="bg-purple-500">
            リード獲得
          </Badge>
        )
      default:
        return <Badge variant="outline">{goal}</Badge>
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>広告セット一覧</CardTitle>
          <CardDescription>登録されている広告セット情報の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/ads/ad-sets/new">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchAdSets} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* フィルターエリア - 常に表示 */}
        <div className="bg-muted/30 p-4 rounded-md mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">キャンペーン</label>
              <Select value={campaignId} onValueChange={setCampaignId}>
                <SelectTrigger>
                  <SelectValue placeholder="すべてのキャンペーン" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">すべてのキャンペーン</SelectItem>
                  {campaigns.map((campaign) => (
                    <SelectItem key={campaign.id} value={campaign.id}>
                      {campaign.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">ステータス</label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="すべてのステータス" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">すべてのステータス</SelectItem>
                  <SelectItem value="ACTIVE">アクティブ</SelectItem>
                  <SelectItem value="PAUSED">一時停止</SelectItem>
                  <SelectItem value="COMPLETED">完了</SelectItem>
                  <SelectItem value="DELETED">削除済み</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">検索</label>
              <Input placeholder="広告名で検索" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : adSets.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            広告セット情報がありません。新しい広告セットを登録するか、フィルター条件を変更してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead
                    onClick={() => {
                      setSortField("adset_name")
                      setSortOrder(sortField === "adset_name" && sortOrder === "asc" ? "desc" : "asc")
                    }}
                  >
                    広告セット名
                  </TableHead>
                  <TableHead>キャンペーン</TableHead>
                  <TableHead>課金イベント</TableHead>
                  <TableHead>最適化目標</TableHead>
                  <TableHead>期間</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {adSets.map((adSet) => (
                  <TableRow key={adSet.adset_id}>
                    <TableCell className="font-medium">{adSet.adset_name}</TableCell>
                    <TableCell>{adSet.campaign_name}</TableCell>
                    <TableCell>{getBillingEventBadge(adSet.billing_event)}</TableCell>
                    <TableCell>{getOptimizationGoalBadge(adSet.optimization_goal)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(adSet.start_time)}</span>
                        {adSet.end_time && (
                          <>
                            <span className="mx-1">〜</span>
                            <span>{formatDate(adSet.end_time)}</span>
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/ad-sets/${adSet.adset_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/ad-sets/${adSet.adset_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
