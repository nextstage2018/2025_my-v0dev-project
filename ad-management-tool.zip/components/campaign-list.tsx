"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Calendar, Plus, Trash2 } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"

type Campaign = {
  campaign_id: string
  project_id: string
  project_name?: string
  client_id?: string
  client_name?: string
  campaign_name: string
  objective: string
  status: string
  start_date: string
  end_date?: string
  created_at: string
}

export default function CampaignList() {
  const { mode } = useDatabase()
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchCampaigns = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージからキャンペーン一覧を取得
        const localCampaigns = LocalStorage.getCampaigns()
        const localProjects = LocalStorage.getProjects()
        const localClients = LocalStorage.getClients()

        const campaignsWithDetails = localCampaigns.map((campaign) => {
          const project = localProjects.find((p) => p.project_id === campaign.project_id)
          const client = project ? localClients.find((c) => c.client_id === project.client_id) : undefined

          return {
            ...campaign,
            project_name: project?.project_name || "不明なプロジェクト",
            client_id: project?.client_id,
            client_name: client?.client_name || "不明なクライアント",
          }
        })

        setCampaigns(campaignsWithDetails)
      } else if (mode === "mock-api") {
        // モックAPIからキャンペーン一覧を取得
        const response = await fetch(`/api/mock/campaigns/list`)

        if (!response.ok) {
          throw new Error("キャンペーン情報の取得に失敗しました")
        }

        const data = await response.json()
        setCampaigns(data.campaigns || [])
      } else {
        // 実際のBigQuery APIからキャンペーン一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/campaigns/list`)

        if (!response.ok) {
          throw new Error("キャンペーン情報の取得に失敗しました")
        }

        const data = await response.json()
        setCampaigns(data.campaigns || [])
      }
    } catch (err: any) {
      console.error("キャンペーン取得エラー:", err)
      setError(err instanceof Error ? err.message : "キャンペーン情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchCampaigns()
  }, [mode])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "draft":
        return <Badge variant="outline">下書き</Badge>
      case "active":
        return (
          <Badge variant="default" className="bg-green-500">
            アクティブ
          </Badge>
        )
      case "paused":
        return <Badge variant="secondary">一時停止</Badge>
      case "completed":
        return (
          <Badge variant="default" className="bg-blue-500">
            完了
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getObjectiveBadge = (objective: string) => {
    switch (objective) {
      case "awareness":
        return (
          <Badge variant="default" className="bg-purple-500">
            認知拡大
          </Badge>
        )
      case "consideration":
        return (
          <Badge variant="default" className="bg-orange-500">
            興味・関心
          </Badge>
        )
      case "conversion":
        return (
          <Badge variant="default" className="bg-red-500">
            コンバージョン
          </Badge>
        )
      default:
        return <Badge variant="outline">{objective}</Badge>
    }
  }

  const handleDelete = async (campaignId: string) => {
    if (confirm("本当に削除しますか？")) {
      LocalStorage.deleteCampaign(campaignId)
      fetchCampaigns() // リストを更新
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>キャンペーン一覧</CardTitle>
          <CardDescription>登録されているキャンペーン情報の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href="/database/campaigns">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchCampaigns} variant="outline" size="icon">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : campaigns.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            キャンペーン情報がありません。新しいキャンペーンを登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>キャンペーン名</TableHead>
                  <TableHead>プロジェクト</TableHead>
                  <TableHead>広告目的</TableHead>
                  <TableHead>ステータス</TableHead>
                  <TableHead>期間</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {campaigns.map((campaign) => (
                  <TableRow key={campaign.campaign_id}>
                    <TableCell className="font-medium">{campaign.campaign_name}</TableCell>
                    <TableCell>{campaign.project_name}</TableCell>
                    <TableCell>{getObjectiveBadge(campaign.objective)}</TableCell>
                    <TableCell>{getStatusBadge(campaign.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(campaign.start_date)}</span>
                        {campaign.end_date && (
                          <>
                            <span className="mx-1">〜</span>
                            <span>{formatDate(campaign.end_date)}</span>
                          </>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/campaigns/${campaign.campaign_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/campaigns/${campaign.campaign_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(campaign.campaign_id)}>
                          <Trash2 className="h-4 w-4 text-red-500" />
                          <span className="sr-only">削除</span>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
