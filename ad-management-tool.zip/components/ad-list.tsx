"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Eye, Pencil, Plus, Calendar } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import { Badge } from "@/components/ui/badge"
import DatabaseModeSelector from "./database-mode-selector"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type AdListProps = {
  accountId?: string | null
  showFilters?: boolean
  metrics?: string[]
}

export default function AdList({
  accountId,
  showFilters = false,
  metrics = ["impressions", "clicks", "conversions"],
}: AdListProps) {
  const { mode } = useDatabase()
  const [ads, setAds] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // フィルター状態
  const [campaignId, setCampaignId] = useState<string>("")
  const [adSetId, setAdSetId] = useState<string>("")
  const [status, setStatus] = useState<string>("")
  const [searchTerm, setSearchTerm] = useState("")

  // キャンペーンとアドセットのリスト
  const [campaigns, setCampaigns] = useState<{ id: string; name: string }[]>([])
  const [adSets, setAdSets] = useState<{ id: string; name: string }[]>([])

  const fetchAds = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージから広告一覧を取得
        // 実際の実装では、LocalStorage.getAds() のような関数を使用する
        // 現在はモックデータを使用
        const mockAds = [
          {
            ad_id: "cl00001_pr00001_ca00001_as00001_ad00001",
            ad_name: "春の新商品バナー広告",
            campaign_id: "cl00001_pr00001_ca00001",
            campaign_name: "SNS認知拡大キャンペーン",
            adset_id: "cl00001_pr00001_ca00001_as00001",
            adset_name: "20-30代女性向け広告セット",
            creative_id: "cr00001",
            status: "ACTIVE",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
          {
            ad_id: "cl00001_pr00001_ca00001_as00001_ad00002",
            ad_name: "商品紹介動画広告",
            campaign_id: "cl00001_pr00001_ca00001",
            campaign_name: "SNS認知拡大キャンペーン",
            adset_id: "cl00001_pr00001_ca00001_as00001",
            adset_name: "20-30代女性向け広告セット",
            creative_id: "cr00002",
            status: "PAUSED",
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        ]

        // フィルタリング
        let filteredAds = [...mockAds]
        if (campaignId && campaignId !== "all") {
          filteredAds = filteredAds.filter((ad) => ad.campaign_id === campaignId)
        }
        if (adSetId && adSetId !== "all") {
          filteredAds = filteredAds.filter((ad) => ad.adset_id === adSetId)
        }
        if (status && status !== "all") {
          filteredAds = filteredAds.filter((ad) => ad.status === status)
        }
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          filteredAds = filteredAds.filter((ad) => ad.ad_name.toLowerCase().includes(term))
        }

        setAds(filteredAds)

        // キャンペーンリストを更新
        const uniqueCampaigns = Array.from(new Set(mockAds.map((ad) => ad.campaign_id))).map((id) => {
          const ad = mockAds.find((ad) => ad.campaign_id === id)
          return { id: ad.campaign_id, name: ad.campaign_name }
        })
        setCampaigns(uniqueCampaigns)

        // 広告セットリストを更新
        const uniqueAdSets = Array.from(new Set(mockAds.map((ad) => ad.adset_id))).map((id) => {
          const ad = mockAds.find((ad) => ad.adset_id === id)
          return { id: ad.adset_id, name: ad.adset_name }
        })
        setAdSets(uniqueAdSets)
      } else if (mode === "mock-api") {
        // モックAPIから広告一覧を取得
        let url = `/api/mock/ads/list`
        const params = new URLSearchParams()

        if (accountId) {
          params.append("account_id", accountId)
        }
        if (campaignId && campaignId !== "all") {
          params.append("campaign_id", campaignId)
        }
        if (adSetId && adSetId !== "all") {
          params.append("adset_id", adSetId)
        }
        if (status && status !== "all") {
          params.append("status", status)
        }

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("広告情報の取得に失敗しました")
        }

        const data = await response.json()
        let adsData = data.ads || []

        // 検索語でフィルタリング
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          adsData = adsData.filter((ad: any) => ad.ad_name.toLowerCase().includes(term))
        }

        setAds(adsData)

        // キャンペーンとアドセットのリストを更新
        const uniqueCampaigns = Array.from(new Set(adsData.map((ad: any) => ad.campaign_id))).map((id) => {
          const ad = adsData.find((ad: any) => ad.campaign_id === id)
          return { id: ad.campaign_id, name: ad.campaign_name }
        })
        setCampaigns(uniqueCampaigns)

        const uniqueAdSets = Array.from(new Set(adsData.map((ad: any) => ad.adset_id))).map((id) => {
          const ad = adsData.find((ad: any) => ad.adset_id === id)
          return { id: ad.adset_id, name: ad.adset_name }
        })
        setAdSets(uniqueAdSets)
      } else {
        // 実際のAPIから広告一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        let url = `${apiBaseUrl}/api/ads/list`
        const params = new URLSearchParams()

        if (accountId) {
          params.append("account_id", accountId)
        }
        if (campaignId && campaignId !== "all") {
          params.append("campaign_id", campaignId)
        }
        if (adSetId && adSetId !== "all") {
          params.append("adset_id", adSetId)
        }
        if (status && status !== "all") {
          params.append("status", status)
        }

        if (params.toString()) {
          url += `?${params.toString()}`
        }

        const response = await fetch(url)

        if (!response.ok) {
          throw new Error("広告情報の取得に失敗しました")
        }

        const data = await response.json()
        let adsData = data.ads || []

        // 検索語でフィルタリング
        if (searchTerm) {
          const term = searchTerm.toLowerCase()
          adsData = adsData.filter((ad: any) => ad.ad_name.toLowerCase().includes(term))
        }

        setAds(adsData)

        // キャンペーンとアドセットのリストを更新
        const uniqueCampaigns = Array.from(new Set(adsData.map((ad: any) => ad.campaign_id))).map((id) => {
          const ad = adsData.find((ad: any) => ad.campaign_id === id)
          return { id: ad.campaign_id, name: ad.campaign_name }
        })
        setCampaigns(uniqueCampaigns)

        const uniqueAdSets = Array.from(new Set(adsData.map((ad: any) => ad.adset_id))).map((id) => {
          const ad = adsData.find((ad: any) => ad.adset_id === id)
          return { id: ad.adset_id, name: ad.adset_name }
        })
        setAdSets(uniqueAdSets)
      }
    } catch (err: any) {
      console.error("広告取得エラー:", err)
      setError(err instanceof Error ? err.message : "広告情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchAds()
  }, [mode, accountId, campaignId, adSetId, status, searchTerm, metrics])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return (
          <Badge variant="default" className="bg-green-500">
            アクティブ
          </Badge>
        )
      case "PAUSED":
        return <Badge variant="secondary">一時停止</Badge>
      case "COMPLETED":
        return (
          <Badge variant="default" className="bg-blue-500">
            完了
          </Badge>
        )
      case "DELETED":
        return <Badge variant="destructive">削除済み</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>広告一覧</CardTitle>
          <CardDescription>登録されている広告情報の一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" size="sm" asChild>
            <Link href={accountId ? `/ads/details/new?account_id=${accountId}` : "/ads/details/new"}>
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchAds} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* フィルターエリア - showFiltersがtrueの場合のみ表示 */}
        {showFilters && (
          <div className="bg-muted/30 p-4 rounded-md mb-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">キャンペーン</label>
                <Select value={campaignId} onValueChange={setCampaignId}>
                  <SelectTrigger>
                    <SelectValue placeholder="すべてのキャンペーン" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">すべてのキャンペーン</SelectItem>
                    {campaigns.map((campaign) => (
                      <SelectItem key={campaign.id} value={campaign.id}>
                        {campaign.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">広告セット</label>
                <Select value={adSetId} onValueChange={setAdSetId}>
                  <SelectTrigger>
                    <SelectValue placeholder="すべての広告セット" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">すべての広告セット</SelectItem>
                    {adSets.map((adSet) => (
                      <SelectItem key={adSet.id} value={adSet.id}>
                        {adSet.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">ステータス</label>
                <Select value={status} onValueChange={setStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="すべてのステータス" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">すべてのステータス</SelectItem>
                    <SelectItem value="ACTIVE">アクティブ</SelectItem>
                    <SelectItem value="PAUSED">一時停止</SelectItem>
                    <SelectItem value="COMPLETED">完了</SelectItem>
                    <SelectItem value="DELETED">削除済み</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">検索</label>
                <Input placeholder="広告名で検索" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
              </div>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : ads.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            広告情報がありません。新しい広告を登録するか、フィルター条件を変更してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>広告名</TableHead>
                  <TableHead>キャンペーン</TableHead>
                  <TableHead>広告セット</TableHead>
                  <TableHead>ステータス</TableHead>
                  <TableHead>作成日</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ads.map((ad) => (
                  <TableRow key={ad.ad_id}>
                    <TableCell className="font-medium">{ad.ad_name}</TableCell>
                    <TableCell>{ad.campaign_name}</TableCell>
                    <TableCell>{ad.adset_name}</TableCell>
                    <TableCell>{getStatusBadge(ad.status)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3 text-muted-foreground" />
                        <span>{formatDate(ad.created_at)}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/details/${ad.ad_id}`}>
                            <Eye className="h-4 w-4" />
                            <span className="sr-only">詳細</span>
                          </Link>
                        </Button>
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/ads/details/${ad.ad_id}/edit`}>
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">編集</span>
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
