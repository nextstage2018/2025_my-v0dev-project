"use client"

import { useState, useEffect } from "react"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Plus, Search, Download } from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"
import { ja } from "date-fns/locale"
import DatabaseModeSelector from "./database-mode-selector"
import { Input } from "@/components/ui/input"

type IdMapping = {
  adaccount_id: string
  campaign_id: string
  adset_id: string
  ad_id: string
  internal_campaign_id: string
  internal_adset_id: string
  internal_ad_id: string
  created_at: string
  updated_at: string
}

export default function IdMappingList() {
  const { mode } = useDatabase()
  const [mappings, setMappings] = useState<IdMapping[]>([])
  const [filteredMappings, setFilteredMappings] = useState<IdMapping[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState("")

  const fetchMappings = async () => {
    setIsLoading(true)
    setError(null)

    try {
      if (mode === "local") {
        // ローカルストレージからIDマッピング一覧を取得
        const localMappings = LocalStorage.getIdMappings()
        setMappings(localMappings)
        setFilteredMappings(localMappings)
      } else if (mode === "mock-api") {
        // モックAPIからIDマッピング一覧を取得
        const response = await fetch(`/api/mock/id-mapping/list`)

        if (!response.ok) {
          throw new Error("IDマッピング情報の取得に失敗しました")
        }

        const data = await response.json()
        setMappings(data.mappings || [])
        setFilteredMappings(data.mappings || [])
      } else {
        // 実際のBigQuery APIからIDマッピング一覧を取得
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/id-mapping/list`)

        if (!response.ok) {
          throw new Error("IDマッピング情報の取得に失敗しました")
        }

        const data = await response.json()
        setMappings(data.mappings || [])
        setFilteredMappings(data.mappings || [])
      }
    } catch (err: any) {
      console.error("IDマッピング取得エラー:", err)
      setError(err instanceof Error ? err.message : "IDマッピング情報の取得中にエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchMappings()
  }, [mode])

  // 検索フィルタリング
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredMappings(mappings)
      return
    }

    const term = searchTerm.toLowerCase()
    const filtered = mappings.filter(
      (mapping) =>
        mapping.adaccount_id.toLowerCase().includes(term) ||
        mapping.campaign_id.toLowerCase().includes(term) ||
        mapping.adset_id.toLowerCase().includes(term) ||
        mapping.ad_id.toLowerCase().includes(term) ||
        mapping.internal_campaign_id.toLowerCase().includes(term) ||
        mapping.internal_adset_id.toLowerCase().includes(term) ||
        mapping.internal_ad_id.toLowerCase().includes(term),
    )
    setFilteredMappings(filtered)
  }, [searchTerm, mappings])

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "yyyy年MM月dd日 HH:mm", { locale: ja })
    } catch (e) {
      return "日付不明"
    }
  }

  const handleExport = () => {
    try {
      // マッピングデータをJSON形式に変換
      const jsonData = JSON.stringify(mappings, null, 2)

      // Blobを作成
      const blob = new Blob([jsonData], { type: "application/json" })

      // ダウンロードリンクを作成
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `id-mappings-${new Date().toISOString().split("T")[0]}.json`

      // リンクをクリックしてダウンロード
      document.body.appendChild(link)
      link.click()

      // クリーンアップ
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error("エクスポートエラー:", err)
      setError("IDマッピングのエクスポートに失敗しました")
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>IDマッピング一覧</CardTitle>
          <CardDescription>外部広告プラットフォームと内部システム間のIDマッピング一覧です</CardDescription>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-1" />
            エクスポート
          </Button>
          <Button variant="default" size="sm" asChild>
            <Link href="/system/id-mapping/new">
              <Plus className="h-4 w-4 mr-1" />
              新規作成
            </Link>
          </Button>
          <DatabaseModeSelector />
          <Button onClick={fetchMappings} variant="outline" size="sm">
            {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "更新"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="flex mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="IDで検索..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : filteredMappings.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            IDマッピング情報がありません。新しいIDマッピングを登録してください。
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>アカウントID</TableHead>
                  <TableHead>外部キャンペーンID</TableHead>
                  <TableHead>内部キャンペーンID</TableHead>
                  <TableHead>外部広告ID</TableHead>
                  <TableHead>内部広告ID</TableHead>
                  <TableHead>更新日時</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMappings.map((mapping, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-mono text-xs">{mapping.adaccount_id}</TableCell>
                    <TableCell className="font-mono text-xs">{mapping.campaign_id}</TableCell>
                    <TableCell className="font-mono text-xs">{mapping.internal_campaign_id}</TableCell>
                    <TableCell className="font-mono text-xs">{mapping.ad_id}</TableCell>
                    <TableCell className="font-mono text-xs">{mapping.internal_ad_id}</TableCell>
                    <TableCell>{formatDate(mapping.updated_at)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
