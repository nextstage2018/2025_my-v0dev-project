"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle } from "lucide-react"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useDatabase } from "@/contexts/database-context"
import * as LocalStorage from "@/lib/local-storage"
import DatabaseModeSelector from "./database-mode-selector"

// ユーザー情報のバリデーションスキーマ
const userSchema = z.object({
  user_name: z.string().min(1, "ユーザー名は必須です"),
  email: z.string().email("有効なメールアドレスを入力してください"),
  user_role: z.enum(["admin", "operator"], {
    required_error: "ユーザー役割は必須です",
  }),
  department: z.string().optional(),
})

type UserFormValues = z.infer<typeof userSchema>

export default function UserForm() {
  const { mode } = useDatabase()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [userId, setUserId] = useState<string | null>(null)

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      user_name: "",
      email: "",
      user_role: "operator",
      department: "",
    },
  })

  const onSubmit = async (data: UserFormValues) => {
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      let newUserId: string

      if (mode === "local") {
        // ローカルストレージモード
        const users = LocalStorage.getUsers()
        const userIds = users.map((user) => user.user_id)
        newUserId = LocalStorage.generateUserId(userIds)

        const userData = {
          user_id: newUserId,
          user_name: data.user_name,
          email: data.email,
          user_role: data.user_role,
          department: data.department || undefined,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        LocalStorage.saveUser(userData)
        setUserId(newUserId)
        setSuccess(`ユーザー「${data.user_name}」を登録しました。`)
      } else if (mode === "mock-api") {
        // モックAPIモード
        const response = await fetch(`/api/mock/users/list`)
        const usersData = await response.json()
        const userIds = usersData.users.map((user: any) => user.user_id)
        newUserId = LocalStorage.generateUserId(userIds)

        const response2 = await fetch(`/api/mock/users/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            user_id: newUserId,
            user_name: data.user_name,
            email: data.email,
            user_role: data.user_role,
            department: data.department || null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "ユーザー情報の登録に失敗しました")
        }

        const result = await response2.json()
        setUserId(newUserId)
        setSuccess(`ユーザー「${data.user_name}」を登録しました。`)
      } else {
        // 実際のBigQuery APIモード
        const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
        const response = await fetch(`${apiBaseUrl}/api/users/list`)
        const usersData = await response.json()
        const userIds = usersData.users.map((user: any) => user.user_id)
        newUserId = LocalStorage.generateUserId(userIds)

        const response2 = await fetch(`${apiBaseUrl}/api/users/create`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            user_id: newUserId,
            user_name: data.user_name,
            email: data.email,
            user_role: data.user_role,
            department: data.department || null,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          }),
        })

        if (!response2.ok) {
          const errorData = await response2.json()
          throw new Error(errorData.error || "ユーザー情報の登録に失敗しました")
        }

        const result = await response2.json()
        setUserId(newUserId)
        setSuccess(`ユーザー「${data.user_name}」を登録しました。`)
      }

      form.reset()
    } catch (err: any) {
      console.error("ユーザー登録エラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>ユーザー登録</CardTitle>
          <CardDescription>システムを利用するユーザーの基本情報を登録します。</CardDescription>
        </div>
        <DatabaseModeSelector />
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="bg-green-50 border-green-500 text-green-700">
                <CheckCircle className="h-4 w-4 mr-2" />
                <AlertDescription>{success}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="user_name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ユーザー名</FormLabel>
                  <FormControl>
                    <Input placeholder="山田 太郎" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>メールアドレス</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="example@company.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="user_role"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ユーザー役割</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="役割を選択" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="admin">管理者</SelectItem>
                      <SelectItem value="operator">運用者</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="department"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>所属部署（任意）</FormLabel>
                  <FormControl>
                    <Input placeholder="マーケティング部" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>

          <CardFooter>
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  登録中...
                </>
              ) : (
                "ユーザーを登録"
              )}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  )
}
