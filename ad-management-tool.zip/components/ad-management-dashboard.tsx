"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AdAccountSelector from "@/components/ad-account-selector"
import AdList from "@/components/ad-list"
import CampaignList from "@/components/campaign-list"
import AdSetList from "@/components/ad-set-list"
import CreateHierarchyButton from "@/components/create-hierarchy-button"
import MetricsSelector from "@/components/metrics-selector"

export default function AdManagementDashboard() {
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null)
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(["impressions", "clicks", "conversions"])

  return (
    <div className="space-y-6">
      {/* 広告アカウント選択エリア */}
      <div className="bg-white p-4 rounded-lg border shadow-sm">
        <AdAccountSelector onAccountSelect={setSelectedAccountId} />
      </div>

      {/* 新規作成ボタンとメトリクス選択 */}
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <CreateHierarchyButton accountId={selectedAccountId} />
        <MetricsSelector selectedMetrics={selectedMetrics} onMetricsChange={setSelectedMetrics} />
      </div>

      {/* タブ切替による階層別一覧表示 */}
      <Tabs defaultValue="campaigns" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="campaigns">キャンペーン</TabsTrigger>
          <TabsTrigger value="adsets">広告セット</TabsTrigger>
          <TabsTrigger value="ads">広告</TabsTrigger>
        </TabsList>

        <TabsContent value="campaigns">
          <CampaignList accountId={selectedAccountId} showFilters={true} metrics={selectedMetrics} />
        </TabsContent>

        <TabsContent value="adsets">
          <AdSetList accountId={selectedAccountId} showFilters={true} metrics={selectedMetrics} />
        </TabsContent>

        <TabsContent value="ads">
          <AdList accountId={selectedAccountId} showFilters={true} metrics={selectedMetrics} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
