"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import * as LocalStorage from "@/lib/local-storage"

type DatabaseMode = "local" | "api" | "mock-api"

interface DatabaseContextType {
  mode: DatabaseMode
  setMode: (mode: DatabaseMode) => void
  isInitialized: boolean
}

const DatabaseContext = createContext<DatabaseContextType | undefined>(undefined)

export function DatabaseProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<DatabaseMode>("mock-api") // デフォルトをモックAPIに変更
  const [isInitialized, setIsInitialized] = useState(false)

  useEffect(() => {
    // ローカルストレージからモード設定を読み込む
    const savedMode = localStorage.getItem("database_mode")
    if (savedMode && (savedMode === "local" || savedMode === "api" || savedMode === "mock-api")) {
      setMode(savedMode as DatabaseMode)
    }

    // ローカルストレージモードの場合、データベースを初期化
    if (mode === "local") {
      LocalStorage.initializeLocalDatabase()
    }

    setIsInitialized(true)
  }, [])

  // モード変更時にローカルストレージに保存
  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem("database_mode", mode)

      // ローカルストレージモードに切り替えた場合、データベースを初期化
      if (mode === "local") {
        LocalStorage.initializeLocalDatabase()
      }
    }
  }, [mode, isInitialized])

  return <DatabaseContext.Provider value={{ mode, setMode, isInitialized }}>{children}</DatabaseContext.Provider>
}

export function useDatabase() {
  const context = useContext(DatabaseContext)
  if (context === undefined) {
    throw new Error("useDatabase must be used within a DatabaseProvider")
  }
  return context
}
