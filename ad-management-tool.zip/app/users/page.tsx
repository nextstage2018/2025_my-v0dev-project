import type { Metadata } from "next"
import UserList from "@/components/user-list"

export const metadata: Metadata = {
  title: "ユーザー一覧 | 広告運用ツール",
  description: "広告運用ツールのユーザー一覧ページです",
}

export default function UsersPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">ユーザー一覧</h1>
      <UserList />
    </div>
  )
}
