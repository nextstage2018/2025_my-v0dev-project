import type { Metadata } from "next"
import DriveFolderList from "@/components/drive-folder-list"

export const metadata: Metadata = {
  title: "広告画像管理 | 広告運用ツール",
  description: "広告運用ツールの広告画像管理ページです",
}

export default function CreativePage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">広告画像管理</h1>
      <DriveFolderList />
    </div>
  )
}
