import type { Metadata } from "next"
import AdManagementDashboard from "@/components/ad-management-dashboard"

export const metadata: Metadata = {
  title: "広告管理 | 広告運用ツール",
  description: "広告運用ツールの広告管理ページです",
}

export default function AdsDetailsPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">広告管理</h1>
      <AdManagementDashboard />
    </div>
  )
}
