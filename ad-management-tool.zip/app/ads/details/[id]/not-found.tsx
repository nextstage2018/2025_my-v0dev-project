import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function NotFound() {
  return (
    <div className="container mx-auto py-8 text-center">
      <h2 className="text-2xl font-bold mb-4">ページが見つかりません</h2>
      <p className="mb-6">お探しの広告は存在しないか、削除された可能性があります。</p>
      <Link href="/ads/details">
        <Button>広告一覧に戻る</Button>
      </Link>
    </div>
  )
}
