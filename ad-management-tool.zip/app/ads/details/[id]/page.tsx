import type { Metadata } from "next"
import AdDetailPageClient from "./AdDetailPageClient"

type Props = {
  params: { id: string }
}

export const metadata: Metadata = {
  title: "広告詳細 | 広告運用ツール",
  description: "広告運用ツールの広告詳細ページです",
}

export default function AdDetailPage({ params }: Props) {
  return <AdDetailPageClient params={params} />
}
