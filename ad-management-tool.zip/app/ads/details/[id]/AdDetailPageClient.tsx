"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Pencil } from "lucide-react"
import AdDetail from "@/components/ad-detail"
import { notFound } from "next/navigation"
import * as LocalStorage from "@/lib/local-storage"
import OperationLogDisplay from "@/components/operation-log-display"

type Props = {
  params: { id: string }
}

export default function AdDetailPageClient({ params }: Props) {
  // "new"というIDの場合は404を返す
  if (params.id === "new") {
    return notFound()
  }

  // 広告が存在するか確認
  const ad = LocalStorage.getAdById(params.id)
  if (!ad) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link href="/ads/details">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">広告詳細</h1>
        </div>
        <Link href={`/ads/details/${params.id}/edit`}>
          <Button>
            <Pencil className="h-4 w-4 mr-2" />
            編集
          </Button>
        </Link>
      </div>
      <AdDetail adId={params.id} />
      <OperationLogDisplay adId={params.id} />
    </div>
  )
}
