import type { Metadata } from "next"
import { notFound } from "next/navigation"
import CampaignDetailPageClient from "./CampaignDetailPageClient"
import * as LocalStorage from "@/lib/local-storage"

type Props = {
  params: { id: string }
}

export const metadata: Metadata = {
  title: "キャンペーン詳細 | 広告運用ツール",
  description: "広告運用ツールのキャンペーン詳細ページです",
}

export default function CampaignDetailPage({ params }: Props) {
  // "new"というIDの場合は404を返す
  if (params.id === "new") {
    return notFound()
  }

  // 広告セットが存在するか確認
  const campaign = LocalStorage.getCampaignById(params.id)
  if (!campaign) {
    return notFound()
  }

  return <CampaignDetailPageClient params={params} />
}
