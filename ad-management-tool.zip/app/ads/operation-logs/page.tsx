import type { Metadata } from "next"
import OperationLogList from "@/components/operation-log-list"

export const metadata: Metadata = {
  title: "運用ログ管理 | 広告運用ツール",
  description: "広告運用ツールの運用ログ管理ページです",
}

export default function OperationLogsPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">運用ログ管理</h1>
      <OperationLogList />
    </div>
  )
}
