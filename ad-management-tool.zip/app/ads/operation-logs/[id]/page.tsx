import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import OperationLogDetail from "@/components/operation-log-detail"
import { notFound } from "next/navigation"
import * as LocalStorage from "@/lib/local-storage"

export const metadata: Metadata = {
  title: "運用ログ詳細 | 広告運用ツール",
  description: "広告運用ツールの運用ログ詳細ページです",
}

export default function OperationLogDetailPage({ params }: { params: { id: string } }) {
  // 運用ログが存在するか確認
  const operationLog = LocalStorage.getOperationLogById(params.id)
  if (!operationLog) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/ads/operation-logs">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">運用ログ詳細</h1>
      </div>
      <OperationLogDetail operationId={params.id} />
    </div>
  )
}
