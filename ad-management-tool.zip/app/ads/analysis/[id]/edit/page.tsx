import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import AnalysisForm from "@/components/analysis-form"
import { notFound } from "next/navigation"
import * as LocalStorage from "@/lib/local-storage"

export const metadata: Metadata = {
  title: "広告検証設定編集 | 広告運用ツール",
  description: "広告運用ツールの広告検証設定編集ページです",
}

export default function EditAnalysisPage({ params }: { params: { id: string } }) {
  // "new"というIDの場合は404を返す
  if (params.id === "new") {
    return notFound()
  }

  // 広告検証設定が存在するか確認
  const analysis = LocalStorage.getAnalysisById(params.id)
  if (!analysis) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href={`/ads/analysis/${params.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">広告検証設定編集</h1>
      </div>
      <AnalysisForm analysisId={params.id} />
    </div>
  )
}
