import type { Metadata } from "next"
import AnalysisList from "@/components/analysis-list"

export const metadata: Metadata = {
  title: "広告検証設定 | 広告運用ツール",
  description: "広告運用ツールの広告検証設定ページです",
}

export default function AnalysisPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">広告検証設定</h1>
      <AnalysisList />
    </div>
  )
}
