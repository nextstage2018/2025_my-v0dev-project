import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import AnalysisForm from "@/components/analysis-form"

export const metadata: Metadata = {
  title: "広告検証設定作成 | 広告運用ツール",
  description: "広告運用ツールの広告検証設定作成ページです",
}

export default function NewAnalysisPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/ads/analysis">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">広告検証設定作成</h1>
      </div>
      <AnalysisForm />
    </div>
  )
}
