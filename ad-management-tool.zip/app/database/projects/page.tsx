import type { Metadata } from "next"
import ProjectFormWithMock from "@/components/project-form-with-mock"

export const metadata: Metadata = {
  title: "プロジェクト登録 | 広告運用ツール",
  description: "広告運用ツールのプロジェクト登録ページです",
}

export default function ProjectPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">プロジェクト登録</h1>
      <ProjectFormWithMock />
    </div>
  )
}
