import type { Metadata } from "next"
import ClientFormWithMock from "@/components/client-form-with-mock"

export const metadata: Metadata = {
  title: "クライアント登録 | 広告運用ツール",
  description: "広告運用ツールのクライアント登録ページです",
}

export default function ClientPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">クライアント登録</h1>
      <ClientFormWithMock />
    </div>
  )
}
