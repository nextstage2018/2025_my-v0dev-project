import type { Metadata } from "next"
import ClientList from "@/components/client-list"
import ProjectList from "@/components/project-list"
import CampaignList from "@/components/campaign-list"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "データ一覧 | 広告運用ツール",
  description: "広告運用ツールのデータ一覧ページです",
}

export default function ListPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">データ一覧</h1>

      <Tabs defaultValue="clients" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="clients">クライアント</TabsTrigger>
          <TabsTrigger value="projects">プロジェクト</TabsTrigger>
          <TabsTrigger value="campaigns">キャンペーン</TabsTrigger>
        </TabsList>
        <TabsContent value="clients">
          <ClientList />
        </TabsContent>
        <TabsContent value="projects">
          <ProjectList />
        </TabsContent>
        <TabsContent value="campaigns">
          <CampaignList />
        </TabsContent>
      </Tabs>
    </div>
  )
}
