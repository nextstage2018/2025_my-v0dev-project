import type { Metadata } from "next"
import CampaignFormWithMock from "@/components/campaign-form-with-mock"

export const metadata: Metadata = {
  title: "キャンペーン登録 | 広告運用ツール",
  description: "広告運用ツールのキャンペーン登録ページです",
}

export default function CampaignPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">キャンペーン登録</h1>
      <CampaignFormWithMock />
    </div>
  )
}
