import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Database, Users, BarChart3, LayoutGrid, ImageIcon, ClipboardList } from "lucide-react"

export default function Home() {
  return (
    <main className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">広告運用ツール</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              クライアント管理
            </CardTitle>
            <CardDescription>広告主（クライアント）の基本情報を管理します</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              企業名、連絡先、契約情報などのクライアント情報を登録・編集できます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/pj/clients" className="w-full">
              <Button className="w-full">クライアント登録</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              プロジェクト管理
            </CardTitle>
            <CardDescription>広告運用プロジェクトを管理します</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              案件の実施条件、メンバー管理、目標管理などのプロジェクト情報を登録・編集できます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/pj/projects" className="w-full">
              <Button className="w-full">プロジェクト登録</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              キャンペーン管理
            </CardTitle>
            <CardDescription>広告キャンペーンを管理します</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              キャンペーンの基本情報、広告目的、予算、期間などの情報を登録・編集できます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/ads/campaigns" className="w-full">
              <Button className="w-full">キャンペーン登録</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <LayoutGrid className="h-5 w-5" />
              広告セット管理
            </CardTitle>
            <CardDescription>広告セットを管理します</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              広告セットの予算、ターゲティング、スケジュールなどの情報を登録・編集できます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/ads/adsets" className="w-full">
              <Button className="w-full">広告セット登録</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ImageIcon className="h-5 w-5" />
              広告管理
            </CardTitle>
            <CardDescription>広告を管理します</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              広告のクリエイティブ、テキスト、リンク先URLなどの情報を登録・編集できます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/ads/ads" className="w-full">
              <Button className="w-full">広告登録</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ClipboardList className="h-5 w-5" />
              レポート
            </CardTitle>
            <CardDescription>広告レポート</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              広告の表示回数、クリック数、コンバージョン数などのレポートを表示します。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/reports" className="w-full">
              <Button className="w-full">レポート</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}
