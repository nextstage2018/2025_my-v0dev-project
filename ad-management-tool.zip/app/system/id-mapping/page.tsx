import type { Metadata } from "next"
import IdMappingList from "@/components/id-mapping-list"

export const metadata: Metadata = {
  title: "IDマッピング | 広告運用ツール",
  description: "広告運用ツールのIDマッピング管理ページです",
}

export default function IdMappingPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">IDマッピング管理</h1>
      <p className="text-muted-foreground mb-8">
        外部広告プラットフォームのIDと内部システムのIDのマッピングを管理します。これにより、外部APIとの連携や広告データの同期が可能になります。
      </p>
      <IdMappingList />
    </div>
  )
}
