import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import IdMappingForm from "@/components/id-mapping-form"

export const metadata: Metadata = {
  title: "IDマッピング登録 | 広告運用ツール",
  description: "広告運用ツールのIDマッピング登録ページです",
}

export default function NewIdMappingPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/system/id-mapping">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">IDマッピング登録</h1>
      </div>
      <IdMappingForm />
    </div>
  )
}
