import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import UserForm from "@/components/user-form"

export const metadata: Metadata = {
  title: "ユーザー登録 | 広告運用ツール",
  description: "広告運用ツールのユーザー登録ページです",
}

export default function NewUserPage() {
  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/system/users">
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">ユーザー登録</h1>
      </div>
      <UserForm />
    </div>
  )
}
