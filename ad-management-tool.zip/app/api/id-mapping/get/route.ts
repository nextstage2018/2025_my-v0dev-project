import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const adId = searchParams.get("ad_id")
    const internalAdId = searchParams.get("internal_ad_id")

    if (!adId && !internalAdId) {
      return NextResponse.json({ error: "ad_idまたはinternal_ad_idが必要です" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // IDマッピングを取得するクエリ
    let query
    if (adId) {
      query = `
        SELECT *
        FROM \`${projectId}.${datasetId}.dim_id_mapping\`
        WHERE ad_id = '${adId}'
        LIMIT 1
      `
    } else {
      query = `
        SELECT *
        FROM \`${projectId}.${datasetId}.dim_id_mapping\`
        WHERE internal_ad_id = '${internalAdId}'
        LIMIT 1
      `
    }

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    if (rows.length === 0) {
      return NextResponse.json({ error: "指定されたIDのマッピングが見つかりません" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      mapping: rows[0],
    })
  } catch (error) {
    console.error("IDマッピング取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
