import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // IDマッピング一覧を取得するクエリ
    const query = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_id_mapping\`
      ORDER BY created_at DESC
    `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      mappings: rows,
    })
  } catch (error) {
    console.error("IDマッピング一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
