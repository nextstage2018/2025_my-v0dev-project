import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.adaccount_id ||
      !data.campaign_id ||
      !data.adset_id ||
      !data.ad_id ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // データの挿入
    const dataset = bigquery.dataset(datasetId)
    const table = dataset.table("dim_id_mapping")

    // 既存のマッピングを確認
    const query = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_id_mapping\`
      WHERE ad_id = '${data.ad_id}'
      LIMIT 1
    `

    const [rows] = await bigquery.query({ query })

    if (rows.length > 0) {
      // 既存のマッピングを更新
      const updateQuery = `
        UPDATE \`${projectId}.${datasetId}.dim_id_mapping\`
        SET 
          adaccount_id = '${data.adaccount_id}',
          campaign_id = '${data.campaign_id}',
          adset_id = '${data.adset_id}',
          internal_campaign_id = '${data.internal_campaign_id}',
          internal_adset_id = '${data.internal_adset_id}',
          internal_ad_id = '${data.internal_ad_id}',
          updated_at = CURRENT_TIMESTAMP()
        WHERE ad_id = '${data.ad_id}'
      `
      await bigquery.query({ query: updateQuery })
    } else {
      // 新しいマッピングを挿入
      await table.insert([
        {
          ...data,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
    }

    return NextResponse.json({
      success: true,
      message: "IDマッピング情報が登録されました",
    })
  } catch (error) {
    console.error("IDマッピング登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
