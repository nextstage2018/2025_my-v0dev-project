import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.ad_id || !data.status) {
      return NextResponse.json({ error: "ad_idとstatusは必須です" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 広告が存在するか確認
    const checkQuery = `
      SELECT ad_id
      FROM \`${projectId}.${datasetId}.dim_ad\`
      WHERE ad_id = '${data.ad_id}'
    `
    const [checkRows] = await bigquery.query({ query: checkQuery })

    if (checkRows.length === 0) {
      return NextResponse.json({ error: "指定されたIDの広告が見つかりません" }, { status: 404 })
    }

    // ステータス更新クエリ
    const updateQuery = `
      UPDATE \`${projectId}.${datasetId}.dim_ad\`
      SET status = '${data.status}',
          updated_at = CURRENT_TIMESTAMP(),
          status_reason = ${data.reason ? `'${data.reason}'` : "NULL"}
      WHERE ad_id = '${data.ad_id}'
    `
    await bigquery.query({ query: updateQuery })

    // 運用ログの記録
    const operationLogData = {
      operation_id: `op_${Date.now()}`,
      operation_type: "ステータス変更",
      operation_status: "完了",
      operation_message: `広告ID: ${data.ad_id}のステータスを${data.status}に変更しました`,
      executed_by: data.user_id || "system",
      operation_timestamp: new Date().toISOString(),
      ad_id: data.ad_id,
      status_before: checkRows[0].status,
      status_after: data.status,
      reason: data.reason || null,
    }

    const logTable = bigquery.dataset(datasetId).table("dim_operation_log")
    await logTable.insert([operationLogData])

    return NextResponse.json({
      success: true,
      message: "広告ステータスが更新されました",
      ad_id: data.ad_id,
      status: data.status,
    })
  } catch (error) {
    console.error("広告ステータス更新エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
