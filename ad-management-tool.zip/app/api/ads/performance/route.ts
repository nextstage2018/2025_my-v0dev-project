import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // クエリパラメータの取得
    const searchParams = request.nextUrl.searchParams
    const adId = searchParams.get("ad_id")
    const metrics = searchParams.get("metrics") || "impressions,clicks,conversions,ctr,cpc,cpa"
    const startDate =
      searchParams.get("start_date") || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
    const endDate = searchParams.get("end_date") || new Date().toISOString().split("T")[0]
    const granularity = searchParams.get("granularity") || "day"

    if (!adId) {
      return NextResponse.json({ error: "ad_idが必要です" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 粒度に応じたグループ化
    let timeGrouping = ""
    if (granularity === "day") {
      timeGrouping = "DATE(date)"
    } else if (granularity === "week") {
      timeGrouping = "DATE_TRUNC(date, WEEK)"
    } else if (granularity === "month") {
      timeGrouping = "DATE_TRUNC(date, MONTH)"
    } else {
      return NextResponse.json(
        { error: "無効な粒度です。day, week, monthのいずれかを指定してください" },
        { status: 400 },
      )
    }

    // パフォーマンスデータを取得するクエリ
    const query = `
      SELECT 
        ${timeGrouping} as date,
        SUM(impressions) as impressions,
        SUM(clicks) as clicks,
        SUM(conversions) as conversions,
        SUM(spend) as spend,
        SAFE_DIVIDE(SUM(clicks), SUM(impressions)) as ctr,
        SAFE_DIVIDE(SUM(spend), SUM(clicks)) as cpc,
        SAFE_DIVIDE(SUM(spend), SUM(conversions)) as cpa
      FROM \`${projectId}.${datasetId}.fact_ad_performance\`
      WHERE ad_id = '${adId}'
        AND date BETWEEN '${startDate}' AND '${endDate}'
      GROUP BY date
      ORDER BY date ASC
    `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    if (rows.length === 0) {
      return NextResponse.json({
        success: true,
        performance: [],
        message: "指定された期間のパフォーマンスデータがありません",
      })
    }

    // 指定されたメトリクスのみを返す
    const metricsList = metrics.split(",")
    const filteredData = rows.map((row) => {
      const filteredRow: any = { date: row.date }
      metricsList.forEach((metric) => {
        if (row[metric] !== undefined) {
          filteredRow[metric] = row[metric]
        }
      })
      return filteredRow
    })

    return NextResponse.json({
      success: true,
      performance: filteredData,
      metrics: metricsList,
      period: {
        start_date: startDate,
        end_date: endDate,
        granularity,
      },
    })
  } catch (error) {
    console.error("広告パフォーマンス取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
