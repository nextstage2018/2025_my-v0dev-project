import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // クエリパラメータの取得
    const searchParams = request.nextUrl.searchParams
    const adId = searchParams.get("ad_id")

    if (!adId) {
      return NextResponse.json({ error: "ad_idが必要です" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 広告詳細を取得するクエリ
    const query = `
      SELECT a.*, c.campaign_name, as.adset_name,
             cr.creative_url, cr.creative_type, cr.creative_text
      FROM \`${projectId}.${datasetId}.dim_ad\` a
      LEFT JOIN \`${projectId}.${datasetId}.dim_campaign\` c ON a.campaign_id = c.campaign_id
      LEFT JOIN \`${projectId}.${datasetId}.dim_adset\` as ON a.adset_id = as.adset_id
      LEFT JOIN \`${projectId}.${datasetId}.dim_creative\` cr ON a.creative_id = cr.creative_id
      WHERE a.ad_id = '${adId}'
    `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    if (rows.length === 0) {
      return NextResponse.json({ error: "指定されたIDの広告が見つかりません" }, { status: 404 })
    }

    // ターゲティング情報を取得
    const targetingQuery = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_targeting\`
      WHERE ad_id = '${adId}'
    `
    const [targetingRows] = await bigquery.query({ query: targetingQuery })

    // パフォーマンス指標を取得
    const performanceQuery = `
      SELECT *
      FROM \`${projectId}.${datasetId}.fact_ad_performance\`
      WHERE ad_id = '${adId}'
      ORDER BY date DESC
      LIMIT 30
    `
    const [performanceRows] = await bigquery.query({ query: performanceQuery })

    return NextResponse.json({
      success: true,
      ad: rows[0],
      targeting: targetingRows[0] || null,
      performance: performanceRows || [],
    })
  } catch (error) {
    console.error("広告詳細取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
