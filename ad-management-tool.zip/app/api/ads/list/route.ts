import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // クエリパラメータの取得
    const searchParams = request.nextUrl.searchParams
    const campaignId = searchParams.get("campaign_id")
    const adsetId = searchParams.get("adset_id")
    const status = searchParams.get("status")
    const startDate = searchParams.get("start_date")
    const endDate = searchParams.get("end_date")
    const page = Number.parseInt(searchParams.get("page") || "1", 10)
    const limit = Number.parseInt(searchParams.get("limit") || "10", 10)
    const offset = (page - 1) * limit

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 広告一覧を取得するクエリを構築
    let query = `
      SELECT a.*, c.campaign_name, as.adset_name
      FROM \`${projectId}.${datasetId}.dim_ad\` a
      LEFT JOIN \`${projectId}.${datasetId}.dim_campaign\` c ON a.campaign_id = c.campaign_id
      LEFT JOIN \`${projectId}.${datasetId}.dim_adset\` as ON a.adset_id = as.adset_id
      WHERE 1=1
    `

    // フィルタリング条件を追加
    if (campaignId) {
      query += ` AND a.campaign_id = '${campaignId}'`
    }
    if (adsetId) {
      query += ` AND a.adset_id = '${adsetId}'`
    }
    if (status) {
      query += ` AND a.status = '${status}'`
    }
    if (startDate) {
      query += ` AND a.created_at >= '${startDate}'`
    }
    if (endDate) {
      query += ` AND a.created_at <= '${endDate}'`
    }

    // 総件数を取得するクエリ
    const countQuery = `SELECT COUNT(*) as total FROM (${query})`
    const [countRows] = await bigquery.query({ query: countQuery })
    const totalCount = countRows[0].total

    // ページネーション
    query += ` ORDER BY a.created_at DESC LIMIT ${limit} OFFSET ${offset}`

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      ads: rows,
      pagination: {
        total: totalCount,
        page,
        limit,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("広告一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
