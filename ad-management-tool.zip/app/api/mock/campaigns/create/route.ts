import { NextResponse } from "next/server"
import { mockCampaigns } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.campaign_id ||
      !data.project_id ||
      !data.campaign_name ||
      !data.objective ||
      !data.status ||
      !data.start_date
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const campaignData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のキャンペーンを確認
    const existingIndex = mockCampaigns.findIndex((campaign) => campaign.campaign_id === campaignData.campaign_id)
    if (existingIndex >= 0) {
      mockCampaigns[existingIndex] = campaignData
    } else {
      mockCampaigns.push(campaignData)
    }

    return NextResponse.json({
      success: true,
      message: "キャンペーン情報が登録されました",
      campaign_id: campaignData.campaign_id,
    })
  } catch (error) {
    console.error("キャンペーン登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
