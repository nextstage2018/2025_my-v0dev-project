import { NextResponse } from "next/server"
import { mockCampaigns, mockProjects, mockClients } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    // クエリパラメータからプロジェクトIDを取得（オプション）
    const url = new URL(request.url)
    const projectId = url.searchParams.get("project_id")

    // キャンペーン一覧にプロジェクト名とクライアント名を追加
    let filteredCampaigns = mockCampaigns
    if (projectId) {
      filteredCampaigns = mockCampaigns.filter((campaign) => campaign.project_id === projectId)
    }

    const campaignsWithDetails = filteredCampaigns.map((campaign) => {
      const project = mockProjects.find((p) => p.project_id === campaign.project_id)
      const client = project ? mockClients.find((c) => c.client_id === project.client_id) : undefined

      return {
        ...campaign,
        project_name: project?.project_name || "不明なプロジェクト",
        client_id: project?.client_id,
        client_name: client?.client_name || "不明なクライアント",
      }
    })

    return NextResponse.json({
      success: true,
      campaigns: campaignsWithDetails,
    })
  } catch (error) {
    console.error("キャンペーン一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
