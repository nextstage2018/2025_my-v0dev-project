import { NextResponse } from "next/server"
import { mockAnalyses } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const projectId = url.searchParams.get("project_id")
    const campaignId = url.searchParams.get("campaign_id")
    const adsetId = url.searchParams.get("adset_id")
    const adId = url.searchParams.get("ad_id")
    const creativeItemId = url.searchParams.get("creative_item_id")

    let filteredAnalyses = [...mockAnalyses]

    // フィルタリング
    if (projectId) {
      filteredAnalyses = filteredAnalyses.filter((analysis) => analysis.internal_project_id === projectId)
    }
    if (campaignId) {
      filteredAnalyses = filteredAnalyses.filter((analysis) => analysis.internal_campaign_id === campaignId)
    }
    if (adsetId) {
      filteredAnalyses = filteredAnalyses.filter((analysis) => analysis.internal_adset_id === adsetId)
    }
    if (adId) {
      filteredAnalyses = filteredAnalyses.filter((analysis) => analysis.internal_ad_id === adId)
    }
    if (creativeItemId) {
      filteredAnalyses = filteredAnalyses.filter((analysis) => analysis.creative_item_id === creativeItemId)
    }

    return NextResponse.json({
      success: true,
      analyses: filteredAnalyses,
    })
  } catch (error) {
    console.error("広告検証設定一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
