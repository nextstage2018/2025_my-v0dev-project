import { NextResponse } from "next/server"
import { mockAnalyses } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.analysis_id ||
      !data.analysis_date ||
      !data.account_id ||
      !data.internal_project_id ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id ||
      !data.creative_item_id ||
      !data.appeal_target ||
      !data.emphasis_theme ||
      !data.appeal_content ||
      !data.design_structure ||
      !data.target_date ||
      !data.goal_event ||
      data.goal_value === undefined
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const analysisData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存の分析を確認
    const existingIndex = mockAnalyses.findIndex((analysis) => analysis.analysis_id === analysisData.analysis_id)
    if (existingIndex >= 0) {
      mockAnalyses[existingIndex] = analysisData
    } else {
      mockAnalyses.push(analysisData)
    }

    return NextResponse.json({
      success: true,
      message: "広告検証設定が登録されました",
      analysis_id: analysisData.analysis_id,
    })
  } catch (error) {
    console.error("広告検証設定登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
