import { NextResponse } from "next/server"
import { mockAnalyses } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const analysisId = url.searchParams.get("analysis_id")

    if (!analysisId) {
      return NextResponse.json({ error: "analysis_idが必要です" }, { status: 400 })
    }

    const analysis = mockAnalyses.find((a) => a.analysis_id === analysisId)

    if (!analysis) {
      return NextResponse.json({ error: "指定されたIDの広告検証設定が見つかりません" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      analysis,
    })
  } catch (error) {
    console.error("広告検証設定取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
