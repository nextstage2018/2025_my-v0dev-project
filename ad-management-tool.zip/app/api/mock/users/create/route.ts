import { NextResponse } from "next/server"
import { mockUsers } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.user_id || !data.user_name || !data.email || !data.user_role) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const userData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のユーザーを確認
    const existingIndex = mockUsers.findIndex((user) => user.user_id === userData.user_id)
    if (existingIndex >= 0) {
      mockUsers[existingIndex] = userData
    } else {
      mockUsers.push(userData)
    }

    return NextResponse.json({
      success: true,
      message: "ユーザー情報が登録されました",
      user_id: userData.user_id,
    })
  } catch (error) {
    console.error("ユーザー登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
