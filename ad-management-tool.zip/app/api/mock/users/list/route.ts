import { NextResponse } from "next/server"
import { mockUsers } from "@/lib/mock-store"

export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      users: mockUsers,
    })
  } catch (error) {
    console.error("ユーザー一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
