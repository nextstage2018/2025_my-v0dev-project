import { NextResponse } from "next/server"
import { mockIdMappings } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.adaccount_id ||
      !data.campaign_id ||
      !data.adset_id ||
      !data.ad_id ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const mappingData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のマッピングを確認（広告IDで検索）
    const existingIndex = mockIdMappings.findIndex((mapping) => mapping.ad_id === mappingData.ad_id)
    if (existingIndex >= 0) {
      mockIdMappings[existingIndex] = mappingData
    } else {
      mockIdMappings.push(mappingData)
    }

    return NextResponse.json({
      success: true,
      message: "IDマッピング情報が登録されました",
    })
  } catch (error) {
    console.error("IDマッピング登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
