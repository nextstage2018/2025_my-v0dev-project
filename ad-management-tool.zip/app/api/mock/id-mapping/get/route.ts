import { NextResponse } from "next/server"
import { mockIdMappings } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const adId = url.searchParams.get("ad_id")
    const internalAdId = url.searchParams.get("internal_ad_id")

    if (!adId && !internalAdId) {
      return NextResponse.json({ error: "ad_idまたはinternal_ad_idが必要です" }, { status: 400 })
    }

    let mapping
    if (adId) {
      mapping = mockIdMappings.find((m) => m.ad_id === adId)
    } else if (internalAdId) {
      mapping = mockIdMappings.find((m) => m.internal_ad_id === internalAdId)
    }

    if (!mapping) {
      return NextResponse.json({ error: "指定されたIDのマッピングが見つかりません" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      mapping,
    })
  } catch (error) {
    console.error("IDマッピング取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
