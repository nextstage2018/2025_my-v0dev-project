import { NextResponse } from "next/server"
import { mockIdMappings } from "@/lib/mock-store"

export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      mappings: mockIdMappings,
    })
  } catch (error) {
    console.error("IDマッピング一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
