import { NextResponse } from "next/server"
import { mockClients } from "@/lib/mock-store"

export async function GET() {
  try {
    return NextResponse.json({
      success: true,
      clients: mockClients,
    })
  } catch (error) {
    console.error("クライアント一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
