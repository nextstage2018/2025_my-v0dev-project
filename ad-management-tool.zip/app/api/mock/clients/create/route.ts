import { NextResponse } from "next/server"
import { mockClients } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.client_id || !data.client_name || !data.contact_person || !data.email) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const clientData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のクライアントを確認
    const existingIndex = mockClients.findIndex((client) => client.client_id === clientData.client_id)
    if (existingIndex >= 0) {
      mockClients[existingIndex] = clientData
    } else {
      mockClients.push(clientData)
    }

    return NextResponse.json({
      success: true,
      message: "クライアント情報が登録されました",
      client_id: clientData.client_id,
    })
  } catch (error) {
    console.error("クライアント登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
