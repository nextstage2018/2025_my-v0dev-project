import { NextResponse } from "next/server"
import { mockAds, mockCreatives, mockTargeting, mockAdPerformance } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const adId = url.searchParams.get("ad_id")

    if (!adId) {
      return NextResponse.json({ error: "ad_idが必要です" }, { status: 400 })
    }

    // 広告を検索
    const ad = mockAds.find((ad) => ad.ad_id === adId)
    if (!ad) {
      return NextResponse.json({ error: "指定されたIDの広告が見つかりません" }, { status: 404 })
    }

    // クリエイティブ情報を取得
    const creative = mockCreatives.find((creative) => creative.creative_id === ad.creative_id) || null

    // ターゲティング情報を取得
    const targeting = mockTargeting.find((targeting) => targeting.ad_id === adId) || null

    // パフォーマンス指標を取得
    const performance = mockAdPerformance
      .filter((perf) => perf.ad_id === adId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 30)

    return NextResponse.json({
      success: true,
      ad: { ...ad, creative },
      targeting,
      performance,
    })
  } catch (error) {
    console.error("広告詳細取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
