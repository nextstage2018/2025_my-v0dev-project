import { NextResponse } from "next/server"
import { mockAdPerformance } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const adId = url.searchParams.get("ad_id")
    const metrics = url.searchParams.get("metrics") || "impressions,clicks,conversions,ctr,cpc,cpa"
    const startDate =
      url.searchParams.get("start_date") || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0]
    const endDate = url.searchParams.get("end_date") || new Date().toISOString().split("T")[0]
    const granularity = url.searchParams.get("granularity") || "day"

    if (!adId) {
      return NextResponse.json({ error: "ad_idが必要です" }, { status: 400 })
    }

    // パフォーマンスデータをフィルタリング
    const filteredPerformance = mockAdPerformance.filter(
      (perf) =>
        perf.ad_id === adId && new Date(perf.date) >= new Date(startDate) && new Date(perf.date) <= new Date(endDate),
    )

    // データがない場合
    if (filteredPerformance.length === 0) {
      return NextResponse.json({
        success: true,
        performance: [],
        message: "指定された期間のパフォーマンスデータがありません",
      })
    }

    // 粒度に応じたグループ化
    const groupedData: any = {}

    filteredPerformance.forEach((perf) => {
      let groupKey
      const date = new Date(perf.date)

      if (granularity === "day") {
        groupKey = perf.date
      } else if (granularity === "week") {
        // 週の始めの日付を取得
        const dayOfWeek = date.getDay()
        const diff = date.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1) // 月曜日を週の始めとする
        const startOfWeek = new Date(date.setDate(diff))
        groupKey = startOfWeek.toISOString().split("T")[0]
      } else if (granularity === "month") {
        groupKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-01`
      } else {
        throw new Error("無効な粒度です")
      }

      if (!groupedData[groupKey]) {
        groupedData[groupKey] = {
          date: groupKey,
          impressions: 0,
          clicks: 0,
          conversions: 0,
          spend: 0,
        }
      }

      groupedData[groupKey].impressions += perf.impressions
      groupedData[groupKey].clicks += perf.clicks
      groupedData[groupKey].conversions += perf.conversions
      groupedData[groupKey].spend += perf.spend
    })

    // 計算指標を追加
    Object.values(groupedData).forEach((data: any) => {
      data.ctr = data.impressions > 0 ? data.clicks / data.impressions : 0
      data.cpc = data.clicks > 0 ? data.spend / data.clicks : 0
      data.cpa = data.conversions > 0 ? data.spend / data.conversions : 0
    })

    // 日付でソート
    const sortedData = Object.values(groupedData).sort(
      (a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime(),
    )

    // 指定されたメトリクスのみを返す
    const metricsList = metrics.split(",")
    const filteredData = sortedData.map((row: any) => {
      const filteredRow: any = { date: row.date }
      metricsList.forEach((metric) => {
        if (row[metric] !== undefined) {
          filteredRow[metric] = row[metric]
        }
      })
      return filteredRow
    })

    return NextResponse.json({
      success: true,
      performance: filteredData,
      metrics: metricsList,
      period: {
        start_date: startDate,
        end_date: endDate,
        granularity,
      },
    })
  } catch (error) {
    console.error("広告パフォーマンス取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
