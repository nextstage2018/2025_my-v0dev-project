import { NextResponse } from "next/server"
import { mockAds } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const campaignId = url.searchParams.get("campaign_id")
    const adsetId = url.searchParams.get("adset_id")
    const status = url.searchParams.get("status")
    const startDate = url.searchParams.get("start_date")
    const endDate = url.searchParams.get("end_date")
    const page = Number.parseInt(url.searchParams.get("page") || "1", 10)
    const limit = Number.parseInt(url.searchParams.get("limit") || "10", 10)
    const offset = (page - 1) * limit

    // フィルタリング
    let filteredAds = [...mockAds]

    if (campaignId) {
      filteredAds = filteredAds.filter((ad) => ad.campaign_id === campaignId)
    }
    if (adsetId) {
      filteredAds = filteredAds.filter((ad) => ad.adset_id === adsetId)
    }
    if (status) {
      filteredAds = filteredAds.filter((ad) => ad.status === status)
    }
    if (startDate) {
      filteredAds = filteredAds.filter((ad) => new Date(ad.created_at) >= new Date(startDate))
    }
    if (endDate) {
      filteredAds = filteredAds.filter((ad) => new Date(ad.created_at) <= new Date(endDate))
    }

    // 総件数
    const totalCount = filteredAds.length

    // ページネーション
    filteredAds = filteredAds.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      ads: filteredAds,
      pagination: {
        total: totalCount,
        page,
        limit,
        pages: Math.ceil(totalCount / limit),
      },
    })
  } catch (error) {
    console.error("広告一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
