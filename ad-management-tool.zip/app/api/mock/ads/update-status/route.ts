import { NextResponse } from "next/server"
import { mockAds, mockOperationLogs } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.ad_id || !data.status) {
      return NextResponse.json({ error: "ad_idとstatusは必須です" }, { status: 400 })
    }

    // 広告を検索
    const adIndex = mockAds.findIndex((ad) => ad.ad_id === data.ad_id)
    if (adIndex === -1) {
      return NextResponse.json({ error: "指定されたIDの広告が見つかりません" }, { status: 404 })
    }

    // 現在のステータスを保存
    const oldStatus = mockAds[adIndex].status

    // ステータスを更新
    mockAds[adIndex] = {
      ...mockAds[adIndex],
      status: data.status,
      status_reason: data.reason || null,
      updated_at: new Date().toISOString(),
    }

    // 運用ログを記録
    const operationLog = {
      operation_id: `op_${Date.now()}`,
      operation_type: "ステータス変更",
      operation_status: "完了",
      operation_message: `広告ID: ${data.ad_id}のステータスを${data.status}に変更しました`,
      executed_by: data.user_id || "system",
      operation_timestamp: new Date().toISOString(),
      ad_id: data.ad_id,
      status_before: oldStatus,
      status_after: data.status,
      reason: data.reason || null,
    }
    mockOperationLogs.push(operationLog)

    return NextResponse.json({
      success: true,
      message: "広告ステータスが更新されました",
      ad_id: data.ad_id,
      status: data.status,
    })
  } catch (error) {
    console.error("広告ステータス更新エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
