import { NextResponse } from "next/server"
import { mockDriveFolders } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.folder_id ||
      !data.internal_project_id ||
      !data.folder_url ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id ||
      !data.account_id ||
      !data.campaign_id ||
      !data.adset_id ||
      !data.ad_id ||
      !data.file_type ||
      !data.creative_item_id ||
      !data.creative_item_name
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const folderData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のフォルダを確認
    const existingIndex = mockDriveFolders.findIndex((folder) => folder.folder_id === folderData.folder_id)
    if (existingIndex >= 0) {
      mockDriveFolders[existingIndex] = folderData
    } else {
      mockDriveFolders.push(folderData)
    }

    return NextResponse.json({
      success: true,
      message: "Google Driveフォルダ情報が登録されました",
      folder_id: folderData.folder_id,
    })
  } catch (error) {
    console.error("Google Driveフォルダ登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
