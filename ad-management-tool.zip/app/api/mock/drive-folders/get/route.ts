import { NextResponse } from "next/server"
import { mockDriveFolders } from "@/lib/mock-store"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const folderId = url.searchParams.get("folder_id")

    if (!folderId) {
      return NextResponse.json({ error: "folder_idが必要です" }, { status: 400 })
    }

    const folder = mockDriveFolders.find((f) => f.folder_id === folderId)

    if (!folder) {
      return NextResponse.json({ error: "指定されたIDのフォルダが見つかりません" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      folder,
    })
  } catch (error) {
    console.error("Google Driveフォルダ取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
