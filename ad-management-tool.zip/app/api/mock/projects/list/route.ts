import { NextResponse } from "next/server"
import { mockProjects, mockClients } from "@/lib/mock-store"

export async function GET() {
  try {
    // プロジェクト一覧にクライアント名を追加
    const projectsWithClientName = mockProjects.map((project) => {
      const client = mockClients.find((c) => c.client_id === project.client_id)
      return {
        ...project,
        client_name: client?.client_name || "不明なクライアント",
      }
    })

    return NextResponse.json({
      success: true,
      projects: projectsWithClientName,
    })
  } catch (error) {
    console.error("プロジェクト一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
