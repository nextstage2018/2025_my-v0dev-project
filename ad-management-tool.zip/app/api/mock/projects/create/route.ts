import { NextResponse } from "next/server"
import { mockProjects } from "@/lib/mock-store"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.project_id || !data.client_id || !data.project_name || !data.start_date || !data.status) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // タイムスタンプの追加
    const now = new Date().toISOString()
    const projectData = {
      ...data,
      created_at: data.created_at || now,
      updated_at: now,
    }

    // 既存のプロジェクトを確認
    const existingIndex = mockProjects.findIndex((project) => project.project_id === projectData.project_id)
    if (existingIndex >= 0) {
      mockProjects[existingIndex] = projectData
    } else {
      mockProjects.push(projectData)
    }

    return NextResponse.json({
      success: true,
      message: "プロジェクト情報が登録されました",
      project_id: projectData.project_id,
    })
  } catch (error) {
    console.error("プロジェクト登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
