import { NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET() {
  try {
    // 環境変数の取得
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID
    const region = process.env.BIGQUERY_REGION || "asia-northeast1"
    const keyFilename = process.env.GOOGLE_APPLICATION_CREDENTIALS

    // 環境変数のチェック
    if (!projectId || !datasetId || !keyFilename) {
      return NextResponse.json(
        {
          success: false,
          error: "環境変数が正しく設定されていません",
          envVars: {
            projectId: projectId ? "設定済み" : "未設定",
            datasetId: datasetId ? "設定済み" : "未設定",
            region: region,
            keyFilename: keyFilename ? "設定済み" : "未設定",
          },
        },
        { status: 500 },
      )
    }

    // BigQueryクライアントの初期化
    const bigquery = new BigQuery({
      projectId,
      keyFilename,
    })

    // 接続テスト1: データセットの存在確認
    const [datasets] = await bigquery.getDatasets()
    const datasetExists = datasets.some((dataset) => dataset.id === datasetId)

    if (!datasetExists) {
      return NextResponse.json(
        {
          success: false,
          error: `データセット '${datasetId}' が存在しません`,
          datasets: datasets.map((dataset) => dataset.id),
        },
        { status: 404 },
      )
    }

    // 接続テスト2: 簡単なクエリの実行
    const testQuery = `SELECT 1 as test`
    const [testRows] = await bigquery.query({ query: testQuery })

    // 接続テスト3: テーブル一覧の取得
    const dataset = bigquery.dataset(datasetId)
    const [tables] = await dataset.getTables()
    const tableList = tables.map((table) => table.id)

    // テーブル作成テスト
    const testTableId = "connection_test_table"
    const testTableSchema = [
      { name: "id", type: "STRING", mode: "REQUIRED" },
      { name: "name", type: "STRING", mode: "REQUIRED" },
      { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
    ]

    // テーブルが存在するか確認
    const testTable = dataset.table(testTableId)
    const [tableExists] = await testTable.exists()

    let tableCreationResult = null
    if (!tableExists) {
      // テーブルが存在しない場合は作成
      const options = {
        schema: testTableSchema,
        location: region,
      }

      const [table] = await dataset.createTable(testTableId, options)
      tableCreationResult = {
        created: true,
        tableId: table.id,
        message: `テーブル '${testTableId}' を作成しました`,
      }
    } else {
      tableCreationResult = {
        created: false,
        tableId: testTableId,
        message: `テーブル '${testTableId}' は既に存在します`,
      }
    }

    // テストデータの挿入
    const testData = {
      id: `test_${Date.now()}`,
      name: "接続テスト",
      created_at: new Date().toISOString(),
    }

    await testTable.insert([testData])

    // テストデータの確認
    const verifyQuery = `
      SELECT * 
      FROM \`${projectId}.${datasetId}.${testTableId}\`
      WHERE id = '${testData.id}'
      LIMIT 1
    `
    const [verifyRows] = await bigquery.query({ query: verifyQuery })

    return NextResponse.json({
      success: true,
      message: "BigQueryへの接続テストに成功しました",
      details: {
        projectId,
        datasetId,
        region,
        testQuery: {
          query: testQuery,
          result: testRows,
        },
        tables: tableList,
        tableCreation: tableCreationResult,
        dataInsertion: {
          inserted: testData,
          verified: verifyRows.length > 0,
          retrievedData: verifyRows,
        },
      },
    })
  } catch (error) {
    console.error("BigQuery接続テストエラー:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "不明なエラーが発生しました",
        stack: error instanceof Error ? error.stack : null,
      },
      { status: 500 },
    )
  }
}
