import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.analysis_id ||
      !data.analysis_date ||
      !data.account_id ||
      !data.internal_project_id ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id ||
      !data.creative_item_id ||
      !data.appeal_target ||
      !data.emphasis_theme ||
      !data.appeal_content ||
      !data.design_structure ||
      !data.target_date ||
      !data.goal_event ||
      data.goal_value === undefined
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // データの挿入
    const dataset = bigquery.dataset(datasetId)
    const table = dataset.table("dim_analysis")

    // 既存の分析を確認
    const query = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_analysis\`
      WHERE analysis_id = '${data.analysis_id}'
      LIMIT 1
    `

    const [rows] = await bigquery.query({ query })

    if (rows.length > 0) {
      // 既存の分析を更新
      const updateQuery = `
        UPDATE \`${projectId}.${datasetId}.dim_analysis\`
        SET 
          analysis_date = '${data.analysis_date}',
          account_id = '${data.account_id}',
          internal_project_id = '${data.internal_project_id}',
          internal_campaign_id = '${data.internal_campaign_id}',
          internal_adset_id = '${data.internal_adset_id}',
          internal_ad_id = '${data.internal_ad_id}',
          creative_item_id = '${data.creative_item_id}',
          appeal_target = '${data.appeal_target}',
          emphasis_theme = '${data.emphasis_theme}',
          appeal_content = '${data.appeal_content}',
          design_structure = '${data.design_structure}',
          target_date = '${data.target_date}',
          goal_event = '${data.goal_event}',
          goal_value = ${data.goal_value},
          updated_at = CURRENT_TIMESTAMP()
        WHERE analysis_id = '${data.analysis_id}'
      `
      await bigquery.query({ query: updateQuery })
    } else {
      // 新しい分析を挿入
      await table.insert([
        {
          ...data,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
    }

    return NextResponse.json({
      success: true,
      message: "広告検証設定が登録されました",
      analysis_id: data.analysis_id,
    })
  } catch (error) {
    console.error("広告検証設定登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
