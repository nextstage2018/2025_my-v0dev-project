import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const projectId = searchParams.get("project_id")
    const campaignId = searchParams.get("campaign_id")
    const adsetId = searchParams.get("adset_id")
    const adId = searchParams.get("ad_id")
    const creativeItemId = searchParams.get("creative_item_id")

    // BigQueryクライアントの初期化
    const bqProjectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!bqProjectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId: bqProjectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 広告検証設定一覧を取得するクエリ
    let query = `
      SELECT *
      FROM \`${bqProjectId}.${datasetId}.dim_analysis\`
      WHERE 1=1
    `

    // フィルタリング条件を追加
    if (projectId) {
      query += ` AND internal_project_id = '${projectId}'`
    }
    if (campaignId) {
      query += ` AND internal_campaign_id = '${campaignId}'`
    }
    if (adsetId) {
      query += ` AND internal_adset_id = '${adsetId}'`
    }
    if (adId) {
      query += ` AND internal_ad_id = '${adId}'`
    }
    if (creativeItemId) {
      query += ` AND creative_item_id = '${creativeItemId}'`
    }

    query += ` ORDER BY analysis_date DESC`

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      analyses: rows,
    })
  } catch (error) {
    console.error("広告検証設定一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
