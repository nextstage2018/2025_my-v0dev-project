import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const analysisId = searchParams.get("analysis_id")

    if (!analysisId) {
      return NextResponse.json({ error: "analysis_idが必要です" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // 広告検証設定を取得するクエリ
    const query = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_analysis\`
      WHERE analysis_id = '${analysisId}'
      LIMIT 1
    `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    if (rows.length === 0) {
      return NextResponse.json({ error: "指定されたIDの広告検証設定が見つかりません" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      analysis: rows[0],
    })
  } catch (error) {
    console.error("広告検証設定取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
