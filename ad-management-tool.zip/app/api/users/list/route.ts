import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // ユーザー一覧を取得するクエリ
    const query = `
     SELECT user_id, user_name, email, user_role, department, created_at, updated_at
     FROM \`${projectId}.${datasetId}.dim_user\`
     ORDER BY created_at DESC
   `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      users: rows,
    })
  } catch (error) {
    console.error("ユーザー一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
