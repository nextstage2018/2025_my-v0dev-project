import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (
      !data.folder_id ||
      !data.internal_project_id ||
      !data.folder_url ||
      !data.internal_campaign_id ||
      !data.internal_adset_id ||
      !data.internal_ad_id ||
      !data.account_id ||
      !data.campaign_id ||
      !data.adset_id ||
      !data.ad_id ||
      !data.file_type ||
      !data.creative_item_id ||
      !data.creative_item_name
    ) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // データの挿入
    const dataset = bigquery.dataset(datasetId)
    const table = dataset.table("dim_drive_folders")

    // 既存のフォルダを確認
    const query = `
      SELECT *
      FROM \`${projectId}.${datasetId}.dim_drive_folders\`
      WHERE folder_id = '${data.folder_id}'
      LIMIT 1
    `

    const [rows] = await bigquery.query({ query })

    if (rows.length > 0) {
      // 既存のフォルダを更新
      const updateQuery = `
        UPDATE \`${projectId}.${datasetId}.dim_drive_folders\`
        SET 
          internal_project_id = '${data.internal_project_id}',
          folder_url = '${data.folder_url}',
          internal_campaign_id = '${data.internal_campaign_id}',
          internal_adset_id = '${data.internal_adset_id}',
          internal_ad_id = '${data.internal_ad_id}',
          account_id = '${data.account_id}',
          campaign_id = '${data.campaign_id}',
          adset_id = '${data.adset_id}',
          ad_id = '${data.ad_id}',
          file_type = '${data.file_type}',
          creative_item_id = '${data.creative_item_id}',
          creative_item_name = '${data.creative_item_name}',
          additional_info = ${data.additional_info ? `'${data.additional_info}'` : "NULL"},
          updated_at = CURRENT_TIMESTAMP()
        WHERE folder_id = '${data.folder_id}'
      `
      await bigquery.query({ query: updateQuery })
    } else {
      // 新しいフォルダを挿入
      await table.insert([
        {
          ...data,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
    }

    return NextResponse.json({
      success: true,
      message: "Google Driveフォルダ情報が登録されました",
      folder_id: data.folder_id,
    })
  } catch (error) {
    console.error("Google Driveフォルダ登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
