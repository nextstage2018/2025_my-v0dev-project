import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 必須フィールドの検証
    if (!data.client_id || !data.client_name || !data.contact_person || !data.email) {
      return NextResponse.json({ error: "必須フィールドが不足しています" }, { status: 400 })
    }

    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // データの挿入
    const dataset = bigquery.dataset(datasetId)
    const table = dataset.table("dim_client")

    await table.insert([data])

    return NextResponse.json({
      success: true,
      message: "クライアント情報が登録されました",
      client_id: data.client_id,
    })
  } catch (error) {
    console.error("クライアント登録エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
