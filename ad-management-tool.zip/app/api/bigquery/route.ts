import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

// BigQueryクライアントの初期化
const getBigQueryClient = () => {
  try {
    // 環境変数からBigQuery接続情報を取得
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const keyFilename = process.env.GOOGLE_APPLICATION_CREDENTIALS

    if (!projectId || !keyFilename) {
      throw new Error("BigQuery接続情報が設定されていません")
    }

    return new BigQuery({
      projectId,
      keyFilename,
    })
  } catch (error) {
    console.error("BigQueryクライアント初期化エラー:", error)
    throw error
  }
}

// テーブル作成関数
const createTableIfNotExists = async (datasetId: string, tableId: string, schema: any[]) => {
  const bigquery = getBigQueryClient()
  const dataset = bigquery.dataset(datasetId)
  const table = dataset.table(tableId)

  try {
    // テーブルが存在するか確認
    const [exists] = await table.exists()

    if (!exists) {
      // テーブルが存在しない場合は作成
      const options = {
        schema: schema,
        location: process.env.BIGQUERY_REGION || "asia-northeast1",
      }

      await dataset.createTable(tableId, options)
      console.log(`テーブル ${tableId} を作成しました`)
    } else {
      console.log(`テーブル ${tableId} は既に存在します`)
    }

    return table
  } catch (error) {
    console.error(`テーブル ${tableId} の作成中にエラーが発生しました:`, error)
    throw error
  }
}

// クライアントテーブルのスキーマ
const clientSchema = [
  { name: "client_id", type: "STRING", mode: "REQUIRED" },
  { name: "client_name", type: "STRING", mode: "REQUIRED" },
  { name: "contact_person", type: "STRING", mode: "REQUIRED" },
  { name: "email", type: "STRING", mode: "REQUIRED" },
  { name: "phone", type: "STRING", mode: "NULLABLE" },
  { name: "contract_details", type: "STRING", mode: "NULLABLE" },
  { name: "notes", type: "STRING", mode: "NULLABLE" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// プロジェクトテーブルのスキーマ
const projectSchema = [
  { name: "project_id", type: "STRING", mode: "REQUIRED" },
  { name: "client_id", type: "STRING", mode: "REQUIRED" },
  { name: "project_name", type: "STRING", mode: "REQUIRED" },
  { name: "description", type: "STRING", mode: "NULLABLE" },
  { name: "start_date", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "end_date", type: "TIMESTAMP", mode: "NULLABLE" },
  { name: "budget", type: "STRING", mode: "NULLABLE" },
  { name: "team_members", type: "STRING", mode: "NULLABLE" },
  { name: "goals", type: "STRING", mode: "NULLABLE" },
  { name: "status", type: "STRING", mode: "REQUIRED" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// キャンペーンテーブルのスキーマ
const campaignSchema = [
  { name: "campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "project_id", type: "STRING", mode: "REQUIRED" },
  { name: "campaign_name", type: "STRING", mode: "REQUIRED" },
  { name: "objective", type: "STRING", mode: "REQUIRED" },
  { name: "status", type: "STRING", mode: "REQUIRED" },
  { name: "start_date", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "end_date", type: "TIMESTAMP", mode: "NULLABLE" },
  { name: "daily_budget", type: "STRING", mode: "NULLABLE" },
  { name: "total_budget", type: "STRING", mode: "NULLABLE" },
  { name: "description", type: "STRING", mode: "NULLABLE" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// ユーザーテーブルのスキーマ
const userSchema = [
  { name: "user_id", type: "STRING", mode: "REQUIRED" },
  { name: "user_name", type: "STRING", mode: "REQUIRED" },
  { name: "email", type: "STRING", mode: "REQUIRED" },
  { name: "user_role", type: "STRING", mode: "REQUIRED" },
  { name: "department", type: "STRING", mode: "NULLABLE" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// IDマッピングテーブルのスキーマを追加
const idMappingSchema = [
  { name: "adaccount_id", type: "STRING", mode: "REQUIRED" },
  { name: "campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// Google Driveフォルダテーブルのスキーマを追加
const driveFoldersSchema = [
  { name: "folder_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_project_id", type: "STRING", mode: "REQUIRED" },
  { name: "folder_url", type: "STRING", mode: "REQUIRED" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "additional_info", type: "STRING", mode: "NULLABLE" },
  { name: "internal_campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "account_id", type: "STRING", mode: "REQUIRED" },
  { name: "campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "file_type", type: "STRING", mode: "REQUIRED" },
  { name: "creative_item_id", type: "STRING", mode: "REQUIRED" },
  { name: "creative_item_name", type: "STRING", mode: "REQUIRED" },
]

// 広告検証設定テーブルのスキーマを追加
const analysisSchema = [
  { name: "analysis_id", type: "STRING", mode: "REQUIRED" },
  { name: "analysis_date", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "account_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_project_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "creative_item_id", type: "STRING", mode: "REQUIRED" },
  { name: "appeal_target", type: "STRING", mode: "REQUIRED" },
  { name: "emphasis_theme", type: "STRING", mode: "REQUIRED" },
  { name: "appeal_content", type: "STRING", mode: "REQUIRED" },
  { name: "design_structure", type: "STRING", mode: "REQUIRED" },
  { name: "target_date", type: "TIMESTAMP", mode: "NULLABLE" },
  { name: "goal_event", type: "STRING", mode: "REQUIRED" },
  { name: "goal_value", type: "STRING", mode: "REQUIRED" },
  { name: "created_at", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "updated_at", type: "TIMESTAMP", mode: "REQUIRED" },
]

// 運用ログテーブルのスキーマを追加
const operationLogSchema = [
  { name: "operation_id", type: "STRING", mode: "REQUIRED" },
  { name: "operation_type", type: "STRING", mode: "REQUIRED" },
  { name: "operation_status", type: "STRING", mode: "REQUIRED" },
  { name: "operation_message", type: "STRING", mode: "NULLABLE" },
  { name: "executed_by", type: "STRING", mode: "NULLABLE" },
  { name: "operation_timestamp", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "error_code", type: "STRING", mode: "NULLABLE" },
  { name: "error_details", type: "STRING", mode: "NULLABLE" },
  { name: "additional_info", type: "STRING", mode: "NULLABLE" },
  { name: "account_id", type: "STRING", mode: "REQUIRED" },
  { name: "campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_project_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_ad_id", type: "STRING", mode: "REQUIRED" },
]

// 時間管理用テーブルのスキーマを追加
const timeManagementSchema = [
  { name: "operation_id", type: "STRING", mode: "REQUIRED" },
  { name: "operation_type", type: "STRING", mode: "REQUIRED" },
  { name: "operation_status", type: "STRING", mode: "REQUIRED" },
  { name: "operation_message", type: "STRING", mode: "NULLABLE" },
  { name: "executed_by", type: "STRING", mode: "NULLABLE" },
  { name: "operation_timestamp", type: "TIMESTAMP", mode: "REQUIRED" },
  { name: "error_code", type: "STRING", mode: "NULLABLE" },
  { name: "error_details", type: "STRING", mode: "NULLABLE" },
  { name: "additional_info", type: "STRING", mode: "NULLABLE" },
  { name: "account_id", type: "STRING", mode: "REQUIRED" },
  { name: "campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "ad_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_project_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_campaign_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_adset_id", type: "STRING", mode: "REQUIRED" },
  { name: "internal_ad_id", type: "STRING", mode: "REQUIRED" },
]

// テーブル初期化関数
export async function initializeTables() {
  try {
    const datasetId = process.env.BIGQUERY_DATASET_ID
    if (!datasetId) {
      throw new Error("データセットIDが設定されていません")
    }

    // 各テーブルの初期化
    await createTableIfNotExists(datasetId, "dim_client", clientSchema)
    await createTableIfNotExists(datasetId, "dim_project", projectSchema)
    await createTableIfNotExists(datasetId, "dim_campaign", campaignSchema)
    await createTableIfNotExists(datasetId, "dim_user", userSchema)
    await createTableIfNotExists(datasetId, "dim_id_mapping", idMappingSchema)
    await createTableIfNotExists(datasetId, "dim_drive_folders", driveFoldersSchema)
    await createTableIfNotExists(datasetId, "dim_analysis", analysisSchema)
    await createTableIfNotExists(datasetId, "dim_operation_log", operationLogSchema)
    await createTableIfNotExists(datasetId, "dim_time_management", timeManagementSchema)

    return true
  } catch (error) {
    console.error("テーブル初期化エラー:", error)
    throw error
  }
}

// APIルート: テーブル初期化
export async function GET(request: NextRequest) {
  try {
    await initializeTables()
    return NextResponse.json({ success: true, message: "テーブルが初期化されました" })
  } catch (error) {
    console.error("API処理エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
