import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // クエリパラメータからプロジェクトIDを取得（オプション）
    const searchParams = request.nextUrl.searchParams
    const projectId = searchParams.get("project_id")

    // BigQueryクライアントの初期化
    const bqProjectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!bqProjectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId: bqProjectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // キャンペーン一覧を取得するクエリ
    let query = `
      SELECT c.campaign_id, c.campaign_name, c.project_id, c.objective, c.status,
             p.project_name, cl.client_id, cl.client_name
      FROM \`${bqProjectId}.${datasetId}.dim_campaign\` c
      LEFT JOIN \`${bqProjectId}.${datasetId}.dim_project\` p
      ON c.project_id = p.project_id
      LEFT JOIN \`${bqProjectId}.${datasetId}.dim_client\` cl
      ON p.client_id = cl.client_id
    `

    // プロジェクトIDが指定されている場合はフィルタリング
    if (projectId) {
      query += ` WHERE c.project_id = '${projectId}'`
    }

    query += ` ORDER BY c.created_at DESC`

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      campaigns: rows,
    })
  } catch (error) {
    console.error("キャンペーン一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
