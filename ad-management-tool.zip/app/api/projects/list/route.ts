import { type NextRequest, NextResponse } from "next/server"
import { BigQuery } from "@google-cloud/bigquery"

export async function GET(request: NextRequest) {
  try {
    // BigQueryクライアントの初期化
    const projectId = process.env.BIGQUERY_PROJECT_ID
    const datasetId = process.env.BIGQUERY_DATASET_ID

    if (!projectId || !datasetId) {
      return NextResponse.json({ error: "BigQuery接続情報が設定されていません" }, { status: 500 })
    }

    const bigquery = new BigQuery({
      projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    // プロジェクト一覧を取得するクエリ（クライアント情報も結合）
    const query = `
      SELECT p.project_id, p.project_name, p.client_id, c.client_name
      FROM \`${projectId}.${datasetId}.dim_project\` p
      LEFT JOIN \`${projectId}.${datasetId}.dim_client\` c
      ON p.client_id = c.client_id
      ORDER BY p.created_at DESC
    `

    // クエリの実行
    const [rows] = await bigquery.query({ query })

    return NextResponse.json({
      success: true,
      projects: rows,
    })
  } catch (error) {
    console.error("プロジェクト一覧取得エラー:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "不明なエラーが発生しました" },
      { status: 500 },
    )
  }
}
