"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export default function BigQueryTestPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const runConnectionTest = async () => {
    setIsLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch("/api/bigquery-test")
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "接続テスト中にエラーが発生しました")
      }

      setResult(data)
    } catch (err) {
      console.error("接続テストエラー:", err)
      setError(err instanceof Error ? err.message : "不明なエラーが発生しました")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">BigQuery接続テスト</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>接続テスト実行</CardTitle>
          <CardDescription>BigQueryへの接続をテストします</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">このテストでは以下の項目を確認します：</p>
          <ul className="list-disc pl-5 space-y-1 text-sm">
            <li>環境変数の設定状況</li>
            <li>BigQueryクライアントの初期化</li>
            <li>データセットへのアクセス</li>
            <li>テストクエリの実行</li>
            <li>テストテーブルの作成</li>
            <li>テストデータの挿入と取得</li>
          </ul>
        </CardContent>
        <CardFooter>
          <Button onClick={runConnectionTest} disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                テスト実行中...
              </>
            ) : (
              "接続テストを実行"
            )}
          </Button>
        </CardFooter>
      </Card>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {result && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {result.success ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
              テスト結果
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-medium">{result.message}</h3>
                {result.error && <p className="text-red-500 mt-1">{result.error}</p>}
              </div>

              {result.success && (
                <>
                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">環境設定</h4>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="font-medium">プロジェクトID:</div>
                      <div>{result.details.projectId}</div>
                      <div className="font-medium">データセットID:</div>
                      <div>{result.details.datasetId}</div>
                      <div className="font-medium">リージョン:</div>
                      <div>{result.details.region}</div>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">テストクエリ</h4>
                    <pre className="bg-gray-100 p-2 rounded text-sm overflow-x-auto">
                      {result.details.testQuery.query}
                    </pre>
                    <div className="mt-2">
                      <span className="font-medium">結果:</span> {JSON.stringify(result.details.testQuery.result)}
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">テーブル一覧</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                      {result.details.tables.map((table: string) => (
                        <li key={table}>{table}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">テーブル作成テスト</h4>
                    <div className="text-sm">
                      <p>
                        <span className="font-medium">テーブルID:</span> {result.details.tableCreation.tableId}
                      </p>
                      <p>
                        <span className="font-medium">ステータス:</span> {result.details.tableCreation.message}
                      </p>
                    </div>
                  </div>

                  <div className="border rounded-md p-4">
                    <h4 className="font-medium mb-2">データ挿入テスト</h4>
                    <div className="text-sm">
                      <p>
                        <span className="font-medium">挿入データ:</span>{" "}
                        {JSON.stringify(result.details.dataInsertion.inserted)}
                      </p>
                      <p>
                        <span className="font-medium">検証結果:</span>{" "}
                        {result.details.dataInsertion.verified ? "成功" : "失敗"}
                      </p>
                      {result.details.dataInsertion.retrievedData && (
                        <div className="mt-2">
                          <span className="font-medium">取得データ:</span>
                          <pre className="bg-gray-100 p-2 rounded mt-1 overflow-x-auto">
                            {JSON.stringify(result.details.dataInsertion.retrievedData, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  </div>
                </>
              )}

              {!result.success && result.envVars && (
                <div className="border rounded-md p-4">
                  <h4 className="font-medium mb-2">環境変数の状態</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="font-medium">プロジェクトID:</div>
                    <div>{result.envVars.projectId}</div>
                    <div className="font-medium">データセットID:</div>
                    <div>{result.envVars.datasetId}</div>
                    <div className="font-medium">リージョン:</div>
                    <div>{result.envVars.region}</div>
                    <div className="font-medium">認証情報:</div>
                    <div>{result.envVars.keyFilename}</div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
