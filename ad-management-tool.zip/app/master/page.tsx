import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Database, Layers } from "lucide-react"

export default function MasterPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">マスタデータ管理</h1>
      <p className="text-muted-foreground mb-8">
        広告運用に必要なマスタデータを管理します。業界カテゴリやメディア情報を登録・編集できます。
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-5 w-5" />
              業界マスタ管理
            </CardTitle>
            <CardDescription>業界カテゴリの登録・編集を行います</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              業界の大カテゴリ、中カテゴリを管理します。プロジェクト登録時に選択肢として表示されます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/master/industry" className="w-full">
              <Button className="w-full">業界マスタ管理へ</Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              メディアマスタ管理
            </CardTitle>
            <CardDescription>メディア情報の登録・編集を行います</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              広告配信メディアの情報を管理します。メディアタイプやメディア名を登録し、プロジェクト登録時に選択肢として表示されます。
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/master/media" className="w-full">
              <Button className="w-full">メディアマスタ管理へ</Button>
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
