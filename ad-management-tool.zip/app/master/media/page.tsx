"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, Plus, Trash2, Edit, Save } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { MEDIA_TYPES, type MediaType } from "@/lib/master-data-types"
import { getMediaTypes, saveMediaTypes } from "@/lib/master-storage"
import { Badge } from "@/components/ui/badge"

export default function MediaMasterPage() {
  const [mediaList, setMediaList] = useState<MediaType[]>([])
  const [newMediaId, setNewMediaId] = useState("")
  const [newMediaType, setNewMediaType] = useState("")
  const [newMediaName, setNewMediaName] = useState("")
  const [newMediaDescription, setNewMediaDescription] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [editingMedia, setEditingMedia] = useState<string | null>(null)
  const [editForm, setEditForm] = useState<MediaType | null>(null)

  // 初期データの読み込み
  useEffect(() => {
    const storedMedia = getMediaTypes()
    if (storedMedia.length > 0) {
      setMediaList(storedMedia)
    } else {
      setMediaList(MEDIA_TYPES)
      saveMediaTypes(MEDIA_TYPES)
    }
  }, [])

  // データが変更されたらローカルストレージに保存
  useEffect(() => {
    if (mediaList.length > 0) {
      saveMediaTypes(mediaList)
    }
  }, [mediaList])

  // 利用可能なメディアタイプの一覧を取得
  const uniqueMediaTypes = [...new Set(mediaList.map((media) => media.media_type))].sort()

  // メディアの追加
  const addMedia = () => {
    if (!newMediaId || !newMediaType || !newMediaName) {
      setError("メディアID、タイプ、名前は必須です")
      return
    }

    if (mediaList.some((media) => media.media_id === newMediaId)) {
      setError("そのメディアIDは既に使用されています")
      return
    }

    const newMedia: MediaType = {
      media_id: newMediaId,
      media_type: newMediaType,
      media_name: newMediaName,
      description: newMediaDescription || undefined,
    }

    setMediaList([...mediaList, newMedia])
    setNewMediaId("")
    setNewMediaType("")
    setNewMediaName("")
    setNewMediaDescription("")
    setSuccess("メディアを追加しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // メディアの削除
  const deleteMedia = (id: string) => {
    setMediaList(mediaList.filter((media) => media.media_id !== id))
    setSuccess("メディアを削除しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // 編集モードの開始
  const startEdit = (media: MediaType) => {
    setEditingMedia(media.media_id)
    setEditForm({ ...media })
  }

  // 編集の保存
  const saveEdit = () => {
    if (!editForm) return

    if (!editForm.media_id || !editForm.media_type || !editForm.media_name) {
      setError("メディアID、タイプ、名前は必須です")
      return
    }

    const updatedMediaList = mediaList.map((media) => {
      if (media.media_id === editingMedia) {
        return editForm
      }
      return media
    })

    setMediaList(updatedMediaList)
    setEditingMedia(null)
    setEditForm(null)
    setSuccess("メディア情報を更新しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // 編集のキャンセル
  const cancelEdit = () => {
    setEditingMedia(null)
    setEditForm(null)
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">メディアマスタ管理</h1>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 border-green-500 text-green-700 mb-4">
          <CheckCircle className="h-4 w-4 mr-2" />
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {/* メディア追加フォーム */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>メディア追加</CardTitle>
          <CardDescription>新しいメディア情報を追加します</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">メディアID</label>
              <Input placeholder="例: fb" value={newMediaId} onChange={(e) => setNewMediaId(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">メディアタイプ</label>
              <Input
                placeholder="例: SNS"
                value={newMediaType}
                onChange={(e) => setNewMediaType(e.target.value)}
                list="media-types"
              />
              <datalist id="media-types">
                {uniqueMediaTypes.map((type) => (
                  <option key={type} value={type} />
                ))}
              </datalist>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">メディア名</label>
            <Input placeholder="例: Facebook" value={newMediaName} onChange={(e) => setNewMediaName(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">説明（任意）</label>
            <Textarea
              placeholder="メディアの説明"
              value={newMediaDescription}
              onChange={(e) => setNewMediaDescription(e.target.value)}
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={addMedia} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            メディアを追加
          </Button>
        </CardFooter>
      </Card>

      {/* メディア一覧 */}
      <Card>
        <CardHeader>
          <CardTitle>メディア一覧</CardTitle>
          <CardDescription>登録されているメディアの一覧です</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>メディアID</TableHead>
                <TableHead>タイプ</TableHead>
                <TableHead>メディア名</TableHead>
                <TableHead>説明</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mediaList.map((media) => (
                <TableRow key={media.media_id}>
                  {editingMedia === media.media_id ? (
                    <>
                      <TableCell>
                        <Input
                          value={editForm?.media_id || ""}
                          onChange={(e) => setEditForm({ ...editForm!, media_id: e.target.value })}
                          className="w-full"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          value={editForm?.media_type || ""}
                          onChange={(e) => setEditForm({ ...editForm!, media_type: e.target.value })}
                          className="w-full"
                          list="edit-media-types"
                        />
                        <datalist id="edit-media-types">
                          {uniqueMediaTypes.map((type) => (
                            <option key={type} value={type} />
                          ))}
                        </datalist>
                      </TableCell>
                      <TableCell>
                        <Input
                          value={editForm?.media_name || ""}
                          onChange={(e) => setEditForm({ ...editForm!, media_name: e.target.value })}
                          className="w-full"
                        />
                      </TableCell>
                      <TableCell>
                        <Textarea
                          value={editForm?.description || ""}
                          onChange={(e) => setEditForm({ ...editForm!, description: e.target.value })}
                          className="w-full"
                        />
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={saveEdit}>
                            <Save className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={cancelEdit}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </>
                  ) : (
                    <>
                      <TableCell>{media.media_id}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{media.media_type}</Badge>
                      </TableCell>
                      <TableCell>{media.media_name}</TableCell>
                      <TableCell>{media.description || "-"}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => startEdit(media)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => deleteMedia(media.media_id)}>
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
