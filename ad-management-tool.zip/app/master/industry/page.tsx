"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, Plus, Trash2, Edit, Save } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { INDUSTRY_CATEGORIES, type IndustryCategory } from "@/lib/master-data-types"
import { getIndustryCategories, saveIndustryCategories } from "@/lib/master-storage"

export default function IndustryMasterPage() {
  const [industries, setIndustries] = useState<IndustryCategory[]>([])
  const [newMainCategory, setNewMainCategory] = useState("")
  const [newMainCategoryId, setNewMainCategoryId] = useState("")
  const [newSubCategory, setNewSubCategory] = useState("")
  const [newSubCategoryId, setNewSubCategoryId] = useState("")
  const [selectedMainCategory, setSelectedMainCategory] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [editingMainCategory, setEditingMainCategory] = useState<string | null>(null)
  const [editingSubCategory, setEditingSubCategory] = useState<string | null>(null)
  const [editValue, setEditValue] = useState("")

  // 初期データの読み込み
  useEffect(() => {
    const storedCategories = getIndustryCategories()
    if (storedCategories.length > 0) {
      setIndustries(storedCategories)
    } else {
      setIndustries(INDUSTRY_CATEGORIES)
      saveIndustryCategories(INDUSTRY_CATEGORIES)
    }
  }, [])

  // データが変更されたらローカルストレージに保存
  useEffect(() => {
    if (industries.length > 0) {
      saveIndustryCategories(industries)
    }
  }, [industries])

  // メインカテゴリの追加
  const addMainCategory = () => {
    if (!newMainCategory || !newMainCategoryId) {
      setError("カテゴリ名とIDを入力してください")
      return
    }

    if (industries.some((cat) => cat.id === newMainCategoryId)) {
      setError("そのIDは既に使用されています")
      return
    }

    setIndustries([
      ...industries,
      {
        id: newMainCategoryId,
        main_category: newMainCategory,
        sub_categories: [],
      },
    ])

    setNewMainCategory("")
    setNewMainCategoryId("")
    setSuccess("業界カテゴリを追加しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // サブカテゴリの追加
  const addSubCategory = () => {
    if (!selectedMainCategory) {
      setError("メインカテゴリを選択してください")
      return
    }

    if (!newSubCategory || !newSubCategoryId) {
      setError("サブカテゴリ名とIDを入力してください")
      return
    }

    const updatedIndustries = industries.map((cat) => {
      if (cat.id === selectedMainCategory) {
        // 既存のサブカテゴリIDと重複チェック
        if (cat.sub_categories.some((sub) => sub.id === newSubCategoryId)) {
          setError("そのIDは既に使用されています")
          return cat
        }

        return {
          ...cat,
          sub_categories: [
            ...cat.sub_categories,
            {
              id: newSubCategoryId,
              name: newSubCategory,
            },
          ],
        }
      }
      return cat
    })

    if (!error) {
      setIndustries(updatedIndustries)
      setNewSubCategory("")
      setNewSubCategoryId("")
      setSuccess("サブカテゴリを追加しました")
      setTimeout(() => setSuccess(null), 3000)
    }
  }

  // メインカテゴリの削除
  const deleteMainCategory = (id: string) => {
    setIndustries(industries.filter((cat) => cat.id !== id))
    if (selectedMainCategory === id) {
      setSelectedMainCategory(null)
    }
    setSuccess("業界カテゴリを削除しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // サブカテゴリの削除
  const deleteSubCategory = (mainId: string, subId: string) => {
    const updatedIndustries = industries.map((cat) => {
      if (cat.id === mainId) {
        return {
          ...cat,
          sub_categories: cat.sub_categories.filter((sub) => sub.id !== subId),
        }
      }
      return cat
    })

    setIndustries(updatedIndustries)
    setSuccess("サブカテゴリを削除しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // 編集モードの開始（メインカテゴリ）
  const startEditMainCategory = (id: string, name: string) => {
    setEditingMainCategory(id)
    setEditValue(name)
  }

  // 編集モードの開始（サブカテゴリ）
  const startEditSubCategory = (mainId: string, subId: string, name: string) => {
    setEditingSubCategory(`${mainId}_${subId}`)
    setEditValue(name)
  }

  // 編集の保存（メインカテゴリ）
  const saveMainCategoryEdit = (id: string) => {
    const updatedIndustries = industries.map((cat) => {
      if (cat.id === id) {
        return {
          ...cat,
          main_category: editValue,
        }
      }
      return cat
    })

    setIndustries(updatedIndustries)
    setEditingMainCategory(null)
    setEditValue("")
    setSuccess("業界カテゴリを更新しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  // 編集の保存（サブカテゴリ）
  const saveSubCategoryEdit = (mainId: string, subId: string) => {
    const updatedIndustries = industries.map((cat) => {
      if (cat.id === mainId) {
        return {
          ...cat,
          sub_categories: cat.sub_categories.map((sub) => {
            if (sub.id === subId) {
              return {
                ...sub,
                name: editValue,
              }
            }
            return sub
          }),
        }
      }
      return cat
    })

    setIndustries(updatedIndustries)
    setEditingSubCategory(null)
    setEditValue("")
    setSuccess("サブカテゴリを更新しました")
    setTimeout(() => setSuccess(null), 3000)
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">業界マスタ管理</h1>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 border-green-500 text-green-700 mb-4">
          <CheckCircle className="h-4 w-4 mr-2" />
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* メインカテゴリ追加フォーム */}
        <Card>
          <CardHeader>
            <CardTitle>業界カテゴリ（大）追加</CardTitle>
            <CardDescription>新しい業界カテゴリを追加します</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">カテゴリID</label>
                <Input
                  placeholder="例: retail"
                  value={newMainCategoryId}
                  onChange={(e) => setNewMainCategoryId(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">カテゴリ名</label>
                <Input
                  placeholder="例: 小売業"
                  value={newMainCategory}
                  onChange={(e) => setNewMainCategory(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={addMainCategory} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              カテゴリを追加
            </Button>
          </CardFooter>
        </Card>

        {/* サブカテゴリ追加フォーム */}
        <Card>
          <CardHeader>
            <CardTitle>業界カテゴリ（中）追加</CardTitle>
            <CardDescription>選択したカテゴリにサブカテゴリを追加します</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">メインカテゴリ</label>
                <select
                  className="w-full border border-gray-300 rounded-md p-2"
                  value={selectedMainCategory || ""}
                  onChange={(e) => setSelectedMainCategory(e.target.value)}
                >
                  <option value="">選択してください</option>
                  {industries.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.main_category}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">サブカテゴリID</label>
                <Input
                  placeholder="例: retail_fashion"
                  value={newSubCategoryId}
                  onChange={(e) => setNewSubCategoryId(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">サブカテゴリ名</label>
                <Input
                  placeholder="例: ファッション"
                  value={newSubCategory}
                  onChange={(e) => setNewSubCategory(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={addSubCategory} className="w-full" disabled={!selectedMainCategory}>
              <Plus className="h-4 w-4 mr-2" />
              サブカテゴリを追加
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* 業界カテゴリ一覧 */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>業界カテゴリ一覧</CardTitle>
          <CardDescription>登録されている業界カテゴリの一覧です</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>カテゴリID</TableHead>
                <TableHead>カテゴリ名</TableHead>
                <TableHead>サブカテゴリ数</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {industries.map((category) => (
                <TableRow key={category.id}>
                  <TableCell>{category.id}</TableCell>
                  <TableCell>
                    {editingMainCategory === category.id ? (
                      <Input value={editValue} onChange={(e) => setEditValue(e.target.value)} className="w-full" />
                    ) : (
                      category.main_category
                    )}
                  </TableCell>
                  <TableCell>{category.sub_categories.length}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      {editingMainCategory === category.id ? (
                        <Button variant="ghost" size="sm" onClick={() => saveMainCategoryEdit(category.id)}>
                          <Save className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => startEditMainCategory(category.id, category.main_category)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="ghost" size="sm" onClick={() => deleteMainCategory(category.id)}>
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* サブカテゴリ一覧 */}
      {selectedMainCategory && (
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>
              サブカテゴリ一覧: {industries.find((cat) => cat.id === selectedMainCategory)?.main_category}
            </CardTitle>
            <CardDescription>選択したカテゴリのサブカテゴリ一覧です</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>サブカテゴリID</TableHead>
                  <TableHead>サブカテゴリ名</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {industries
                  .find((cat) => cat.id === selectedMainCategory)
                  ?.sub_categories.map((subCategory) => (
                    <TableRow key={subCategory.id}>
                      <TableCell>{subCategory.id}</TableCell>
                      <TableCell>
                        {editingSubCategory === `${selectedMainCategory}_${subCategory.id}` ? (
                          <Input value={editValue} onChange={(e) => setEditValue(e.target.value)} className="w-full" />
                        ) : (
                          subCategory.name
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {editingSubCategory === `${selectedMainCategory}_${subCategory.id}` ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => saveSubCategoryEdit(selectedMainCategory, subCategory.id)}
                            >
                              <Save className="h-4 w-4" />
                            </Button>
                          ) : (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                startEditSubCategory(selectedMainCategory, subCategory.id, subCategory.name)
                              }
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteSubCategory(selectedMainCategory, subCategory.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
