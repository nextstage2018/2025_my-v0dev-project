import type React from "react"
export default function NewAdSetLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
