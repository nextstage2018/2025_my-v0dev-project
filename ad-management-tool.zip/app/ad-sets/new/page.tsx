"use client"

import { useEffect } from "react"
import AdSetForm from "@/components/ad-set-form"

export default function NewAdSetPage() {
  // コンポーネントがマウントされたことを確認するためのログ
  useEffect(() => {
    console.log("NewAdSetPage component mounted")
  }, [])

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">広告セット新規作成</h1>
      <AdSetForm />
    </div>
  )
}
