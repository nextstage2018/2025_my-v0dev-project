import type { Metadata } from "next"
import AdSetList from "@/components/ad-set-list"

export const metadata: Metadata = {
  title: "広告セット一覧 | 広告運用ツール",
  description: "広告運用ツールの広告セット一覧ページです",
}

export default function AdSetsPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">広告セット一覧</h1>
      <AdSetList />
    </div>
  )
}
