import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import AdSetForm from "@/components/ad-set-form"
import { notFound } from "next/navigation"
import * as LocalStorage from "@/lib/local-storage"

export const metadata: Metadata = {
  title: "広告セット編集 | 広告運用ツール",
  description: "広告運用ツールの広告セット編集ページです",
}

export default function EditAdSetPage({ params }: { params: { id: string } }) {
  // "new"というIDの場合は404を返す
  if (params.id === "new") {
    return notFound()
  }

  // 広告セットが存在するか確認
  const adSet = LocalStorage.getAdSetById(params.id)
  if (!adSet) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href={`/ad-sets/${params.id}`}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">広告セット編集</h1>
      </div>
      <AdSetForm adSetId={params.id} />
    </div>
  )
}
