import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Pencil } from "lucide-react"
import AdSetDetail from "@/components/ad-set-detail"
import { notFound } from "next/navigation"
import * as LocalStorage from "@/lib/local-storage"

export const metadata: Metadata = {
  title: "広告セット詳細 | 広告運用ツール",
  description: "広告運用ツールの広告セット詳細ページです",
}

export default function AdSetDetailPage({ params }: { params: { id: string } }) {
  // "new"というIDの場合は404を返す（リダイレクトではなく）
  if (params.id === "new") {
    return notFound()
  }

  // 広告セットが存在するか確認
  const adSet = LocalStorage.getAdSetById(params.id)
  if (!adSet) {
    return notFound()
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Link href="/ad-sets">
            <Button variant="outline" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">広告セット詳細</h1>
        </div>
        <Link href={`/ad-sets/${params.id}/edit`}>
          <Button>
            <Pencil className="h-4 w-4 mr-2" />
            編集
          </Button>
        </Link>
      </div>
      <AdSetDetail adSetId={params.id} />
    </div>
  )
}
