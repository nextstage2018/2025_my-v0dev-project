import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { DatabaseProvider } from "@/contexts/database-context"
import { MasterDataInitializer } from "@/components/master-data-initializer"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "広告運用ツール",
  description: "広告運用を効率化するためのツール",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ja">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <DatabaseProvider>
            <MasterDataInitializer />
            {children}
          </DatabaseProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'