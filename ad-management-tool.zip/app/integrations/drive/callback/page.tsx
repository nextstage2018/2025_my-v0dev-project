"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Loader2, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { useDatabase } from "@/contexts/database-context"

export default function DriveCallbackPage() {
  const searchParams = useSearchParams()
  const code = searchParams.get("code")
  const error = searchParams.get("error")
  const { mode } = useDatabase()

  const [isProcessing, setIsProcessing] = useState(false)
  const [processError, setProcessError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    const processAuthCode = async () => {
      if (!code) return

      setIsProcessing(true)
      setProcessError(null)

      try {
        // APIエンドポイントの準備
        let url: string
        if (mode === "local" || mode === "mock-api") {
          url = `/api/mock/integrations/drive/callback`
        } else {
          const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || ""
          url = `${apiBaseUrl}/api/integrations/drive/callback`
        }

        // 認証コードを処理するリクエスト
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ code }),
        })

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "認証コードの処理に失敗しました")
        }

        const result = await response.json()
        setSuccess(true)
      } catch (err) {
        console.error("認証コード処理エラー:", err)
        setProcessError(err instanceof Error ? err.message : "不明なエラーが発生しました")
      } finally {
        setIsProcessing(false)
      }
    }

    processAuthCode()
  }, [code, mode])

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Google Drive連携コールバック</h1>

      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>認証結果</CardTitle>
          <CardDescription>Google Drive連携の認証結果を表示します</CardDescription>
        </CardHeader>
        <CardContent>
          {isProcessing ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mb-4" />
              <p>認証コードを処理中...</p>
            </div>
          ) : error ? (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4 mr-2" />
              <AlertDescription>認証がキャンセルされたか、エラーが発生しました: {error}</AlertDescription>
            </Alert>
          ) : processError ? (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4 mr-2" />
              <AlertDescription>{processError}</AlertDescription>
            </Alert>
          ) : success ? (
            <Alert className="bg-green-50 border-green-500 text-green-700">
              <CheckCircle className="h-4 w-4 mr-2" />
              <AlertDescription>
                Google Driveとの連携が完了しました。これで広告クリエイティブをGoogle Driveに保存できるようになりました。
              </AlertDescription>
            </Alert>
          ) : (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4 mr-2" />
              <AlertDescription>認証コードが見つかりません。もう一度連携設定をやり直してください。</AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Link href="/integrations/drive">
            <Button>連携設定ページに戻る</Button>
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
