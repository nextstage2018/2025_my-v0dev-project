import type { Metadata } from "next"
import DriveIntegrationForm from "@/components/drive-integration-form"

export const metadata: Metadata = {
  title: "Google Drive連携 | 広告運用ツール",
  description: "広告運用ツールのGoogle Drive連携設定ページです",
}

export default function DriveIntegrationPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Google Drive連携</h1>
      <p className="text-muted-foreground mb-8">
        広告クリエイティブを保存・管理するためのGoogle Drive連携を設定します。連携を行うには、Google Cloud
        Platformでプロジェクトを作成し、OAuth同意画面とクライアントIDを設定する必要があります。
      </p>
      <DriveIntegrationForm />
    </div>
  )
}
